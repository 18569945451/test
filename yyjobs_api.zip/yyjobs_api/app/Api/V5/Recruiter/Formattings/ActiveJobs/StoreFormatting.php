<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/2
 * Time: 13:29
 */

namespace App\Api\V5\Recruiter\Formattings\ActiveJobs;

use App\Api\V5\Recruiter\Entities\Employer;
use App\Api\V5\Recruiter\Entities\Industry;
use Carbon\Carbon;
use Illuminate\Http\Request;

class StoreFormatting
{
    public function format(Request $request)
    {
        $recruiter = auth('recruiter')->user();

        $data['job_employer_admin_id']     = $request->job_employer_admin_id;
        $data['job_employer_company_name'] = $this->employerName($request->job_employer_admin_id);
        $data['job_recruiter_admin_id']    = $recruiter->id;
        $data['job_recruiter_admin_name']  = $recruiter->name;
        $data['job_title']                 = $request->job_title;
        $data['job_contact_name']          = $request->job_contact_name;
        $data['job_contact_no']            = $request->job_contact_no;
        $data['job_hour_rate']             = $request->job_hour_rate;
        $data['job_start_date']            = Carbon::parse($request->job_start_date)->getTimestamp();
        $data['job_end_date']              = Carbon::parse($request->job_end_date)->getTimestamp();
        $data['job_need_people_count']     = $request->job_need_people_count;
        $data['job_image']                 = $this->jobImageUrl($request->job_image_url,$request->file('job_image_file'));
        $data['job_address']               = $request->job_address;
        $data['job_zip']                   = $request->job_zip;
        $data['job_latitude']              = $request->job_latitude;
        $data['job_longitude']             = $request->job_longitude;
        $data['job_description']           = $request->job_description;
        $data['job_requirements']          = $request->job_requirements ?? '';
        $data['job_post']                  = $request->job_post ?? '';
        $data['job_people_nationality']    = $request->job_people_nationality ? $this->nationality($request->job_people_nationality) : '';
        $data['job_people_age']            = $request->job_people_age ?? '';
        $data['job_people_language']       = $request->job_people_language ? strtolower($request->job_people_language) : '';
        $data['job_industry_id']           = $request->job_industry_id;
        $data['job_industry_name']         = $this->industry($request->job_industry_id);
        $data['job_people_sex']            = $request->job_people_sex ?? 0;
        $data['job_note']                  = $request->job_note ?? '';
        $data['job_status']                = 4;
        $data['job_add_time']              = Carbon::now()->getTimestamp();

        return $data;
    }

    /**
     * @param $industryID
     *
     * @return mixed
     */
    private function industry($industryID)
    {
        $industry = Industry::find($industryID,['industry_name']);
        return $industry->industry_name;
    }

    /**
     * @param $url
     * @param $file
     *
     * @return string
     */
    private function jobImageUrl($url,$file)
    {
        if ($file){
            return generateFileUrl($file->store(generateFilePath()));
        }
        return $url;
    }

    /**
     * 首字母大写
     *
     * @param $nationality
     *
     * @return mixed
     */
    private function nationality($nationality)
    {
        $arr = explode(',', $nationality);
        foreach ($arr as $key => $item) {
            $arr[$key] = ucfirst($item);
        }

        return implode(',', $arr);
    }

    /**
     * @param $adminID
     *
     * @return mixed
     */
    private function employerName($adminID)
    {
        $employer = Employer::where('e_admin_id', $adminID)->first(['e_company_name']);

        return $employer->e_company_name;
    }
}