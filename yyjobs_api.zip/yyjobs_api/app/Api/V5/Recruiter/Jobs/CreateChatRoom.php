<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/22
 * Time: 15:22
 */

namespace App\Api\V5\Recruiter\Jobs;

use App\Api\V1\Services\TimApi;
use App\Api\V5\Recruiter\Entities\ChatRoom;
use App\Api\V5\Recruiter\Entities\Job;
use App\Api\V5\Recruiter\Services\ChatRoomService;
use App\Api\V5\Recruiter\Services\JobService;
use App\Api\V5\Recruiter\Services\ScheduleService;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;

class CreateChatRoom implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $jobID;
    private $timeOut = 86400;

    /**
     * Create a new job instance.
     * @param $jobID
     */
    public function __construct($jobID)
    {
        $this->jobID = $jobID;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try{
            $job = Job::find($this->jobID);
            if ($job->job_end_date < (time() - $this->timeOut)){
                return ;
            }

            $room = (new JobService())->getRoom($this->jobID);

            //没有创建过聊天室
            if (!$room){
                //应该加入到聊天室里的人
                $users = (new ScheduleService())->getSendUsers($this->jobID,$job->job_recruiter_admin_id);
                //聊天室名称(08/22 12:00~18:00 Wanda Huabe)
                $roomName = $this->generateChatRoomName($job);

                //创建聊天室的响应
                $chatRoomResponse = (new TimApi())->createRoom($users,$roomName);
                if ($chatRoomResponse->ErrorCode != 0 || $chatRoomResponse->ActionStatus != 'OK'){
                    Log::error("Tim_Error ".$chatRoomResponse->ErrorInfo);
                    return;
                }

                $roomID = $chatRoomResponse->GroupId;

                //同步聊天室工作与用户
                (new ChatRoomService())->syncRoom($chatRoomResponse->GroupId,$roomName,$this->jobID,$users);
            }else{
                //应该加入到聊天室里的人
                $users = (new ScheduleService())->getSendUsers($this->jobID,$job->job_recruiter_admin_id);

                //现在聊天室里的人
                $roomUsers = $room->users()->get(['user_id']);

                //需要新增的人员
                $needAddUsers = $this->newUsers($users,$roomUsers->toArray());
                if (!$needAddUsers){
                    return;
                }

                //添加聊天室人员的响应
                $chatRoomResponse = (new TimApi())->addRoomUsers($needAddUsers,$room->group_id);
                if ($chatRoomResponse->ErrorCode != 0 || $chatRoomResponse->ActionStatus != 'OK'){
                    Log::error("Tim_Error ".$chatRoomResponse->ErrorInfo);
                    return;
                }

                $roomID = $room->group_id;

                //同步聊天室工作与用户
                (new ChatRoomService())->syncRoomUser($room,$needAddUsers);
            }

            $sendRoomMessageResponse = (new TimApi())->sendRoomMessage($roomID);
            if ($sendRoomMessageResponse->ErrorCode != 0 || $sendRoomMessageResponse->ActionStatus != 'OK'){
                Log::error("Tim_Error ".$sendRoomMessageResponse->ErrorInfo);
                return;
            }

        }catch (\Exception $e){
            Log::error($e->getFile().' '.$e->getLine().' '.$e->getMessage());
        }
    }

    /**
     * 生成聊天室名字
     * @param $job
     *
     * @return string
     */
    private function generateChatRoomName($job)
    {
        return Carbon::createFromTimestamp($job->job_start_date)->format("m/d H:i").
               '~'.
               Carbon::createFromTimestamp($job->job_end_date)->format("H:i").
               ' '.
               substr($job->job_employer_company_name,0,11);
    }

    /**
     * 需要新增的人员
     * @param $sendUsers
     * @param $roomUsers
     * @return array
     */
    private function newUsers($sendUsers,$roomUsers)
    {
        $roomUsers = array_column($roomUsers,'user_id');
        return array_values(array_diff($sendUsers,$roomUsers));
    }
}
