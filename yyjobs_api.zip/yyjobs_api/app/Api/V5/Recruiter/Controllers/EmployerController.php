<?php


namespace App\Api\V5\Recruiter\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V5\Recruiter\Services\EmployerService;
use App\Api\V5\Recruiter\Requests\Employer\DetailRequest;
use Prettus\Validator\Exceptions\ValidatorException;
class EmployerController extends Controller
{
    public $service;

    public function __construct()
    {
        $this->service = new EmployerService();
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/employer/index",
     *   tags={"employer"},
     *   summary="employer 列表",
     *   description="employer 列表",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页 默认 1",  required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数 默认 10",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(Request $request)
    {
        try{
            $data = $this->service->employerList($request);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/employer/detail",
     *   tags={"employer"},
     *   summary="employer detail",
     *   description="employer detail",
     *   operationId="detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_id",type="integer",  description="employer_id",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */

    public function detail(DetailRequest $request)
    {
        try{
            $data = $this->service->employerDetail($request->employer_id);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }



}