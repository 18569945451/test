<?php
namespace App\Api\V5\Recruiter\Controllers;

use App\Api\V5\Recruiter\Requests\ActiveJobs\LatelyRequest;
use App\Api\V5\Recruiter\Requests\ActiveJobs\StoreRequest;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V5\Recruiter\Services\JobService;
use App\Api\V5\Recruiter\Requests\ActiveJobs\IndexRequest;
use App\Api\V5\Recruiter\Requests\ActiveJobs\detailRequest;
use App\Api\V5\Recruiter\Requests\ActiveJobs\CoordinatesRequest;
use App\Api\V5\Recruiter\Requests\ActiveJobs\RequisitionsRequest;
class ActiveJobsController extends Controller
{
    public $service;

    public function __construct()
    {
        $this->service = new JobService();
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/active-jobs/index",
     *   tags={"active jobs"},
     *   summary="active jobs list",
     *   description="active jobs list",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页 默认 1",  required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数 默认 10",  required=false),
     *   @SWG\Parameter(in="query",  name="date",type="string",  description="选择的日期，默认所有，参数格式2019-07-31",  required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="按employer name 搜索",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(IndexRequest $request)
    {
        try{
            $data = $this->service->jobList($request);
            return apiReturn($data);

        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/active-jobs/detail",
     *   tags={"active jobs"},
     *   summary="active jobs copy",
     *   description="active jobs copy",
     *   operationId="copy",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="job_id",type="integer",  description="copy的job id",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(detailRequest $request)
    {
        try{
            $data = $this->service->jobDetail($request->job_id);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }


    /**
     * @SWG\Get(path="/index.php/api/recruiter/active-jobs/coordinates",
     *   tags={"active jobs"},
     *   summary="active jobs get coordinates",
     *   description="active jobs get coordinates",
     *   operationId="coordinates",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="postal_code",type="integer",  description="邮政编码",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function coordinates(CoordinatesRequest $request)
    {
        try{
            $data = $this->service->getCoordinates($request->postal_code);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/active-jobs/store",
     *   tags={"active jobs"},
     *   summary="active jobs 保存",
     *   description="active jobs 保存",
     *   operationId="store",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="labour_request_id",type="integer",  description="工作请求ID",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_employer_admin_id",type="integer",  description="employer",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_title",type="string",  description="工作标题",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_contact_name",type="string",  description="工作联系人",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_contact_no",type="string",  description="联系人手机号",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_hour_rate",type="string",  description="时薪",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_start_date",type="string",  description="工作开始时间",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_end_date",type="string",  description="工作结束时间",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_need_people_count",type="integer",  description="工作需要的人数",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_image_url",type="string",  description="工作图片地址",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_image_file",type="file",  description="工作图片文件",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_address",type="string",  description="工作地址",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_zip",type="string",  description="邮编",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_latitude",type="string",  description="地址纬度",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_longitude",type="string",  description="地址经度",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_description",type="string",  description="工作描述",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_requirements",type="string",  description="工作具体要求(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_post",type="string",  description="工作职位",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_people_nationality",type="string",  description="工作人员的国籍(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_people_age",type="string",  description="工作人员的年龄段(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_people_language",type="string",  description="工作人员的语言(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_industry_id",type="integer",  description="工作所属行业ID",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_people_sex",type="integer",  description="工作要求的性别（0：不限，1：男，2：女）默认0",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_note",type="string",  description="工作备忘(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function store(StoreRequest $request)
    {
        try{
            $data = $this->service->store($request);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/active-jobs/update",
     *   tags={"active jobs"},
     *   summary="active jobs 更新",
     *   description="active jobs 更新",
     *   operationId="update",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="job_id",type="integer",  description="工作ID",  required=true),
     *   @SWG\Parameter(in="formData",  name="labour_request_id",type="integer",  description="工作请求ID",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_employer_admin_id",type="integer",  description="employer",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_title",type="string",  description="工作标题",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_contact_name",type="string",  description="工作联系人",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_contact_no",type="string",  description="联系人手机号",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_hour_rate",type="string",  description="时薪",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_start_date",type="string",  description="工作开始时间",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_end_date",type="string",  description="工作结束时间",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_need_people_count",type="integer",  description="工作需要的人数",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_image_url",type="string",  description="工作图片地址",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_image_file",type="file",  description="工作图片文件",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_address",type="string",  description="工作地址",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_zip",type="string",  description="邮编",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_latitude",type="string",  description="地址纬度",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_longitude",type="string",  description="地址经度",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_description",type="string",  description="工作描述",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_requirements",type="string",  description="工作具体要求(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_post",type="string",  description="工作职位",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_people_nationality",type="string",  description="工作人员的国籍(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_people_age",type="string",  description="工作人员的年龄段(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_people_language",type="string",  description="工作人员的语言(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_industry_id",type="integer",  description="工作所属行业ID",  required=true),
     *   @SWG\Parameter(in="formData",  name="job_people_sex",type="integer",  description="工作要求的性别（0：不限，1：男，2：女）默认0",  required=false),
     *   @SWG\Parameter(in="formData",  name="job_note",type="string",  description="工作备忘(默认为空字符串)",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function update(StoreRequest $request)
    {
        try{
            $data = $this->service->update($request);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }


    /**
     * @SWG\Get(path="/index.php/api/recruiter/active-jobs/requisitions",
     *   tags={"active jobs"},
     *   summary="active jobs labour_requisitions",
     *   description="active jobs labour_requisitions",
     *   operationId="coordinates",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_id",type="integer",  description="employer Id",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function requisitions(RequisitionsRequest $request)
    {
        try{
            $data = $this->service->getLabourRequisitions($request->employer_id);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/active-jobs/lately",
     *   tags={"active jobs"},
     *   summary="lately active jobs",
     *   description="lately active jobs",
     *   operationId="lately",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="integer",  description="employer Admin Id",  required=true),
     *   @SWG\Parameter(in="query",  name="job_title",type="string",  description="job title",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function lately(LatelyRequest $request)
    {
        $data = $this->service->lately($request->employer_admin_id,$request->job_title);
        return apiReturn($data);
    }

}