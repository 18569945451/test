<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:10
 */

namespace App\Api\V5\Recruiter\Controllers;

use App\Api\V5\Recruiter\Requests\LabourRequest\ApproveAllRequest;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Exceptions\ApiValidatorException;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V5\Recruiter\Services\LabourRequestService;
use App\Api\V5\Recruiter\Requests\LabourRequest\WeekRequest;
use App\Api\V5\Recruiter\Requests\LabourRequest\IndexRequest;
use App\Api\V5\Recruiter\Requests\LabourRequest\UpdateRequest;

class LabourRequestController extends Controller
{
    public $service;

    public function __construct()
    {
        $this->service = new LabourRequestService();
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/labour-request/index",
     *   tags={"labour-request"},
     *   summary="labour-request 列表",
     *   description="labour-request 列表",
     *   operationId="index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="day",type="string",  description="2019-07-30 日期（默认今天）", required=false),
     *   @SWG\Parameter(in="query",  name="status",  type="string",  enum={"pending","approve","reject"}, description="状态【pending,approve,reject】",  required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页 默认 1",  required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数 默认 5",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(IndexRequest $request)
    {
        try{
            $data = $this->service->requisitionList($request);
            return apiReturn($data);
        }catch (ApiValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/labour-request/week",
     *   tags={"labour-request"},
     *   summary="此周是否有pending的labour-request",
     *   description="此周是否有pending的labour-request",
     *   operationId="week",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="day",type="string",  description="2019-07-16 日期（默认今天，如果需要看上周的，则需要传一个上周的某一天日期）", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function week(WeekRequest $request)
    {
        try{
            $day = $request->input('day') ? Carbon::parse($request->day) : Carbon::today();
            $data = $this->service->week($day);
            return apiReturn($data);
        }catch (ApiValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/labour-request/detail",
     *   tags={"labour-request"},
     *   summary="labour-request 详情",
     *   description="labour-request 详情",
     *   operationId="detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="id",type="integer", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(Request $request)
    {
        try{
            $data = $this->service->requisitionDetail($request->id);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/labour-request/update",
     *   tags={"labour-request"},
     *   summary="labour-request 修改状态",
     *   description="labour-request 修改状态",
     *   operationId="update",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="id",type="integer", required=true),
     *   @SWG\Parameter(in="formData",  name="status",  type="string",  enum={"approve","reject"}, description="状态【pending,approve,reject】",  required=true),
     *   @SWG\Parameter(in="formData",  name="reject_reason",  type="string", description="拒绝原因",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function update(UpdateRequest $request)
    {
        try{
            $data = $this->service->requisitionUpdate($request);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/labour-request/approve/all",
     *   tags={"labour-request"},
     *   summary="labour-request 批准指定日期所有pending的",
     *   description="labour-request 批准指定日期所有pending的",
     *   operationId="approve/all",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="day",type="string", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function approveAll(ApproveAllRequest $request)
    {
        try{
            $data = $this->service->approveAll($request->day);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }
}