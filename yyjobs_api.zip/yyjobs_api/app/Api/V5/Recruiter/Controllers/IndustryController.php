<?php
namespace App\Api\V5\Recruiter\Controllers;

use App\Http\Controllers\Controller;
use App\Api\V5\Recruiter\Services\IndustryService;
use Prettus\Validator\Exceptions\ValidatorException;
use Illuminate\Http\Request;
class IndustryController extends Controller
{
    public $service;

    public function __construct()
    {
        $this->service = new IndustryService();
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/industry/index",
     *   tags={"industry"},
     *   summary="industry list",
     *   description="industry list",
     *   operationId="industry",
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index()
    {
        try{
            $data = $this->service->industryList();
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

}