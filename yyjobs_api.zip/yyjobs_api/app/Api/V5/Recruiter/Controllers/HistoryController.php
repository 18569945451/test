<?php
namespace App\Api\V5\Recruiter\Controllers;

use App\Api\V5\Recruiter\Requests\History\AddStaffRequest;
use App\Api\V5\Recruiter\Services\ScheduleService;
use App\Http\Controllers\Controller;
use App\Api\V5\Recruiter\Requests\History\DetailRequest;
use App\Api\V5\Recruiter\Requests\History\IndexRequest;
use App\Api\V5\Recruiter\Services\History\HistoryService;
use App\Api\V5\Recruiter\Services\History\HistoryScheduleService;
use Prettus\Validator\Exceptions\ValidatorException;

class HistoryController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/recruiter/history/index",
     *   tags={"history"},
     *   summary="history list",
     *   description="history list",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页 默认 1",  required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数 默认 10",  required=false),
     *   @SWG\Parameter(in="query",  name="date",type="string",  description="选择的日期，默认所有，参数格式2019-07-31",  required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="按employer name搜索",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(IndexRequest $request)
    {
        $data = (new HistoryService())->historyList($request);
        return apiReturn($data);
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/history/detail",
     *   tags={"history"},
     *   summary="history detail",
     *   description="history detail",
     *   operationId="history_detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="job_id",type="integer",  description="工作ID",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(DetailRequest $request)
    {
        try{
            $data = (new HistoryScheduleService())->detailList($request->job_id);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/history/staff/add",
     *   tags={"history"},
     *   summary="history 添加员工",
     *   description="history 添加员工",
     *   operationId="history_add_staff",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="job_id",type="integer",  description="工作ID",  required=true),
     *   @SWG\Parameter(in="query",  name="member_id",type="integer",  description="员工ID",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function addStaff(AddStaffRequest $request)
    {
        try{
            $data = (new ScheduleService())->addStaff($request->job_id,$request->member_id,true);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

}