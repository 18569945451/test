<?php


namespace App\Api\V5\Recruiter\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Api\V5\Recruiter\Requests\Notifications\DestroyRequest;
use App\Api\V5\Recruiter\Requests\Notifications\ReadRequest;
use App\Api\V5\Recruiter\Services\NotificationsService;
use Prettus\Validator\Exceptions\ValidatorException;

class NotificationsController extends Controller
{

    public $service;

    public function __construct()
    {
        $this->service = new NotificationsService();
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/notifications/index",
     *   tags={"notifications"},
     *   summary="notifications list",
     *   description="notifications list",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页 默认 1",  required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数 默认 10",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(Request $request)
    {
        $data = $this->service->notificationsList($request);
        return apiReturn($data);
    }


    /**
     * @SWG\Post(path="/index.php/api/recruiter/notifications/destroy",
     *   tags={"notifications"},
     *   summary="notifications destroy 单个删除",
     *   description="notifications destroy",
     *   operationId="destroy",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="id",type="integer",  description="",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function destroy(DestroyRequest $request)
    {
        try{
            $this->service->destroy($request->id);
            return apiReturn([]);
        }catch(ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }


    /**
     * @SWG\Post(path="/index.php/api/recruiter/notifications/destroy/all",
     *   tags={"notifications"},
     *   summary="notifications destroy all 全部删除",
     *   description="notifications destroy all",
     *   operationId="destroy_all",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
     public function destroyAll()
     {
         $recruiterID = auth('recruiter')->user()->id;
         $this->service->model->where('admin_id', $recruiterID)->delete();
         return apiReturn([]);
     }



    /**
     * @SWG\Post(path="/index.php/api/recruiter/notifications/read",
     *   tags={"notifications"},
     *   summary="notifications read 单个读取",
     *   description="notifications read",
     *   operationId="read",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="id",type="integer",  description="",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function read(ReadRequest $request)
    {
        try{
            $this->service->read($request->id);
            return apiReturn([]);
        }catch(ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }


    /**
     * @SWG\Post(path="/index.php/api/recruiter/notifications/read/all",
     *   tags={"notifications"},
     *   summary="notifications read all 阅读所有",
     *   description="notifications read all",
     *   operationId="read_all",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function readAll()
    {
        $recruiterID = auth('recruiter')->user()->id;
        $this->service->model->where('admin_id', $recruiterID)->update(array('is_read'=> 1));
        return apiReturn([]);
    }


}