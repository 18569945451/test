<?php


namespace App\Api\V5\Recruiter\Controllers;

use App\Api\V5\Recruiter\Requests\Member\NricRequest;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V5\Recruiter\Services\MemberService;
use App\Api\V5\Recruiter\Requests\Member\InfoRequest;
use App\Api\V5\Recruiter\Requests\Member\UpdateRequest;
class MemberController extends Controller
{
    public $service;

    public function __construct()
    {
        $this->service = new MemberService();
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/staff/info",
     *   tags={"staff"},
     *   summary="staff detail",
     *   description="staff detail",
     *   operationId="detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="member_id",type="integer",  description="staff 的 member_id",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function info(InfoRequest $request)
    {
        try{
            $data = $this->service->staffInfo($request->member_id);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }


    /**
     * @SWG\Post(path="/index.php/api/recruiter/staff/update",
     *   tags={"staff"},
     *   summary="update staff",
     *   description="update staff",
     *   operationId="update",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="member_id",type="integer",  description="staff 的 member_id",  required=true),
     *   @SWG\Parameter(in="formData",  name="member_name",type="string",  description="staff 的 名字",  required=false),
     *   @SWG\Parameter(in="formData",  name="member_sex",type="string",  description="1:男 2:女",  required=false),
     *   @SWG\Parameter(in="formData",  name="member_mobile",type="string",  description="包含区号如+6598344719",  required=false),
     *   @SWG\Parameter(in="formData",  name="member_birthday",type="string",  description="如2019-08-05",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */

    public function update(UpdateRequest $request)
    {
        $data = [];
        try{
            $this->service->updateStaffInfo($request);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/staff/nric",
     *   tags={"staff"},
     *   summary="staff 根据nric或者mobile找员工",
     *   description="staff 根据nric找员工",
     *   operationId="nric",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="nric",type="string",  description="",  required=false),
     *   @SWG\Parameter(in="query",  name="member_mobile",type="string",  description="用户手机号",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function nric(NricRequest $request)
    {
        try{
            $data = $this->service->findByNricOrMobile($request->nric, $request->member_mobile);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

}