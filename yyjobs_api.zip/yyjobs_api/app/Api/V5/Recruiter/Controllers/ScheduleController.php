<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/9
 * Time: 10:14
 */

namespace App\Api\V5\Recruiter\Controllers;

use App\Api\V5\Recruiter\Requests\Schedule\AddStaffRequest;
use App\Http\Controllers\Controller;
use App\Exceptions\ApiValidatorException;
use App\Api\V5\Recruiter\Services\ScheduleService;
use App\Api\V5\Recruiter\Requests\Schedule\SendRequest;
use App\Api\V5\Recruiter\Requests\Schedule\IndexRequest;
use App\Api\V5\Recruiter\Requests\Schedule\StatusRequest;
use App\Api\V5\Recruiter\Requests\Schedule\SendAllRequest;
use Prettus\Validator\Exceptions\ValidatorException;

class ScheduleController extends Controller
{
    public $service;

    public function __construct()
    {
        $this->service = new ScheduleService();
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/schedules/index",
     *   tags={"schedules"},
     *   summary="schedules 列表(attendance 列表)",
     *   description="schedules 列表",
     *   operationId="schedules_index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="job_id",type="integer",  description="",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(IndexRequest $request)
    {
        try{
            $data = $this->service->scheduleList($request->job_id);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/schedules/send",
     *   tags={"schedules"},
     *   summary="schedules send ",
     *   description="schedules send",
     *   operationId="schedules_send",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="s_id[0]",type="integer",  description="",  required=true),
     *   @SWG\Parameter(in="query",  name="s_id[1]",type="integer",  description="",  required=false),
     *   @SWG\Parameter(in="query",  name="s_id[2]",type="integer",  description="",  required=false),
     *   @SWG\Parameter(in="query",  name="s_id[3]",type="integer",  description="",  required=false),
     *   @SWG\Parameter(in="query",  name="s_id[4]",type="integer",  description="",  required=false),
     *   @SWG\Parameter(in="query",  name="s_id[5]",type="integer",  description="",  required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function send(SendRequest $request)
    {
        try{
            $data = $this->service->sendToEmployer($request->input('s_id'));
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/schedules/send/all",
     *   tags={"schedules"},
     *   summary="schedules send all",
     *   description="schedules send all",
     *   operationId="schedules_send_all",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="job_id",type="integer",  description="",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function sendAll(SendAllRequest $request)
    {
        try{
            $data = $this->service->sendAllToEmployer($request->input('job_id'));
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/schedules/status",
     *   tags={"schedules"},
     *   summary="schedules 修改状态",
     *   description="schedules 修改状态",
     *   operationId="schedules_status",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="s_id",type="integer",  description="",  required=true),
     *   @SWG\Parameter(in="query",  name="status",type="integer",  enum={"2","3"}, description="状态【2:approve,3:reject】",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function status(StatusRequest $request)
    {
        try{
            $data = $this->service->status($request->s_id,$request->status);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/schedules/staff/add",
     *   tags={"schedules"},
     *   summary="schedules 添加员工",
     *   description="schedules 添加员工",
     *   operationId="schedules_add_staff",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="job_id",type="integer",  description="工作ID",  required=true),
     *   @SWG\Parameter(in="query",  name="member_id",type="integer",  description="员工ID",  required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function addStaff(AddStaffRequest $request)
    {
        try{
            $data = $this->service->addStaff($request->job_id,$request->member_id);
            return apiReturn($data);
        }catch (ValidatorException $exception){
            return apiReturn([],403,$exception->getMessageBag()->first());
        }
    }
}