<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 18:08
 */

namespace App\Api\V5\Recruiter\Transformers\LabourRequest;


use Carbon\Carbon;
use Illuminate\Support\Collection;

class IndexTransformer
{
    public function transform(Collection $collection)
    {
        //return $collection->toArray();
        $data = [];
        foreach ($collection as $key => $item) {
            $data[$key]['id']            = $item->id;
            $data[$key]['job_date']      = Carbon::parse($item->job_start)->toDateString();
            $data[$key]['start_time']    = Carbon::parse($item->job_start)->format('H:i');
            $data[$key]['end_time']      = Carbon::parse($item->job_end)->format('H:i');
            $data[$key]['request_time']  = $item->add_time;
            $data[$key]['employer_id']   = $item->employer->e_admin_id;
            $data[$key]['employer_name'] = $item->employer->e_company_name;
            $data[$key]['employer_logo'] = $item->employer->e_company_logo;
            $data[$key]['posted']        = !!$item->job_id;
            $data[$key]['status']        = ucfirst($item->status);
        }

        return $data;
    }
}