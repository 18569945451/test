<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/31
 * Time: 13:46
 */

namespace App\Api\V5\Recruiter\Transformers\LabourRequest;

use Carbon\Carbon;

class DetailTransformer
{
    public function transform($item)
    {
        return [
            'id'            => $item->id,
            'admin_id'      => $item->employer_admin_id,
            'start_time'    => Carbon::parse($item->job_start)->toDateTimeString(),
            'end_time'      => Carbon::parse($item->job_end)->toDateTimeString(),
            'employer_name' => $item->adminUser->name,
            'title'         => $item->job_title,
            'need_number'   => $item->need_num,
            'status'        => ucfirst($item->status),
            'posted'        => $item->job_id ? true : false,
            'remark'        => $item->remark->remark ?? '',
            'signature'     => $item->remark->signature ?? '',
            'reject_reason' => $item->reject_reason ?? '',
        ];
    }
}