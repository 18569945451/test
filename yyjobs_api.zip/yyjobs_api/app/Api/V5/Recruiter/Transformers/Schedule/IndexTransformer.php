<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/9
 * Time: 10:56
 */

namespace App\Api\V5\Recruiter\Transformers\Schedule;

use Carbon\Carbon;
use Illuminate\Support\Collection;

class IndexTransformer
{
    public function transform(Collection $collection,$job)
    {
        $data = [];

        $data['job']['employer_name'] = $job->job_employer_company_name;
        $data['job']['start_time']    = Carbon::createFromTimestamp($job->job_start_date)->format("Y-m-d H:i:s");
        $data['job']['end_time']      = Carbon::createFromTimestamp($job->job_end_date)->format("Y-m-d H:i:s");
        $data['job']['date_time']     = Carbon::createFromTimestamp($job->job_start_date)->format("d M Y (H:i").
                                        Carbon::createFromTimestamp($job->job_end_date)->format("-H:i)");

        foreach ($collection as $key => $item) {
            $data['members'][$key]['s_id']             = $item->s_id;
            $data['members'][$key]['job_id']           = $item->job_id;
            $data['members'][$key]['checkin_time']     = $item->checkin_time ? Carbon::createFromTimestamp($item->checkin_time)->format('H:i') : 0;
            $data['members'][$key]['checkout_time']    = $item->checkout_time ? Carbon::createFromTimestamp($item->checkout_time)->format('H:i') : 0;
            $data['members'][$key]['is_send']          = $item->is_send ? true : false;
            $data['members'][$key]['work_status']      = $item::$workStatusMap[$item->work_status];
            $data['members'][$key]['hourly_rate']      = $item->adjusted_hourly_rate ? $item->adjusted_hourly_rate : $item->member->member_salary_rate;
            $data['members'][$key]['member']['id']     = $item->member->member_id;
            $data['members'][$key]['member']['name']   = $item->member->member_name;
            $data['members'][$key]['member']['nric']   = strtoupper($item->member->member_nric);
            $data['members'][$key]['member']['avatar'] = $item->member->member_avatar;
            $data['members'][$key]['member']['phone']  = $item->member->member_mobile;
        }

        return $data;
    }
}