<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/30
 * Time: 17:31
 */

namespace App\Api\V5\Recruiter\Transformers\Employer;

class DetailTransformer
{
    public function transform($item)
    {
        return [
            'employer_id' => $item->e_id,
            'admin_id'    => $item->e_admin_id,
            'contact_no'  => $item->e_contact_no,
            'name'        => $item->e_company_name,
            'logo'        => $item->e_company_logo,
            'email'       => $item->e_email,
            'description' => $item->e_company_description ?? '',
            'industry'    => $item->industry->industry_name
        ];
    }
}