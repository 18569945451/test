<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/30
 * Time: 17:31
 */

namespace App\Api\V5\Recruiter\Transformers\Employer;

use Illuminate\Support\Collection;

class IndexTransformer
{
    public function transform(Collection $collection)
    {
        //return $collection->toArray();
        $data = [];
        foreach ($collection as $key => $item) {
            $data[$key]['employer_id'] = $item->e_id;
            $data[$key]['admin_id']    = $item->e_admin_id;
            $data[$key]['contact_no']  = $item->e_contact_no;
            $data[$key]['name']        = $item->e_company_name;
            $data[$key]['logo']        = $item->e_company_logo;
            $data[$key]['email']       = $item->e_email;
        }

        return $data;
    }
}