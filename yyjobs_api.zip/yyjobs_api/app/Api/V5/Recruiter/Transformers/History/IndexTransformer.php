<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/30
 * Time: 17:31
 */

namespace App\Api\V5\Recruiter\Transformers\History;

use Illuminate\Support\Collection;
use Carbon\Carbon;
class IndexTransformer
{
    public function transform(Collection $collection)
    {
        $data     = [];
        $stateArr = [1=> 'Pending', 2=>'Sent', 3=>'Revised'];
        foreach ($collection as $key => $item) {
            $data[$key]['job_id']                   = $item->job_id;
            $data[$key]['employer_id']              = $item->job_employer_admin_id;
            $data[$key]['employer_name']            = $item->job_employer_company_name;
            $data[$key]['job_title']                = $item->job_title;
            $data[$key]['date']                     = Carbon::createFromTimestamp($item->job_start_date)->format('Y-m-d');
            $data[$key]['start_time']               = Carbon::createFromTimestamp($item->job_start_date)->format('H:i');
            $data[$key]['end_time']                 = Carbon::createFromTimestamp($item->job_end_date)->format('H:i');
            $data[$key]['job_image']                = $item->job_image;
            $data[$key]['job_need_people_count']    = $item->job_need_people_count;
            $data[$key]['apply_jobs_num']           = $item->schedules_count ? $item->schedules_count : 0;
            $data[$key]['state']                    = isset($stateArr[$item->employer_status]) ? $stateArr[$item->employer_status] :'';
        }

        return $data;
    }
}