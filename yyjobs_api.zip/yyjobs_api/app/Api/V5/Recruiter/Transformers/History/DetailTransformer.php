<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/13
 * Time: 14:49
 */

namespace App\Api\V5\Recruiter\Transformers\History;

use Carbon\Carbon;

class DetailTransformer
{
    public function transform(array $collection,$job)
    {
        $jobData['employer_name'] = $job->job_employer_company_name;
        $jobData['date_time']     = Carbon::createFromTimestamp($job->job_start_date)->format("d M Y (H:i").
                                    Carbon::createFromTimestamp($job->job_end_date)->format("-H:i)");
        $jobData['start_time']    = Carbon::createFromTimestamp($job->job_start_date)->format("Y-m-d H:i:s");
        $jobData['end_time']      = Carbon::createFromTimestamp($job->job_end_date)->format("Y-m-d H:i:s");
        $jobData['need_count']    = $job->job_need_people_count;
        $jobData['applied_count'] = $job->schedules()->applied()->count();

        $members = [];
        foreach ($collection as $key => $value) {
            $hourlyRate = $value['adjusted_hourly_rate'] ? $value['adjusted_hourly_rate'] : $value['member']['member_salary_rate'];
            unset($value['member']['member_salary_rate']);

            $members[$key]['s_id']          = $value['s_id'];
            $members[$key]['member_id']     = $value['member_id'];
            $members[$key]['checkin_time']  = $value['checkin_time'] ? Carbon::createFromTimestamp($value['checkin_time'])->format("H:i") : '';
            $members[$key]['checkout_time'] = $value['checkout_time'] ? Carbon::createFromTimestamp($value['checkout_time'])->format("H:i") : '';
            $members[$key]['hours']         = $value['minutes'] / 60;
            $members[$key]['hourly_rate']   = $hourlyRate;
            $members[$key]['remark']        = $value['employer_remark'] ?? '';
            $members[$key]['member']        = $value['member'];

            if (!isset($value['child'])){
                $members[$key]['child'] = [];
                continue;
            }

            foreach ($value['child'] as $k => $v) {
                $hourlyRate = $v['adjusted_hourly_rate'] ? $v['adjusted_hourly_rate'] : $v['member']['member_salary_rate'];
                unset($v['member']['member_salary_rate']);

                $members[$key]['child'][$k]['s_id']          = $v['s_id'];
                $members[$key]['child'][$k]['member_id']     = $v['member_id'];
                $members[$key]['child'][$k]['checkin_time']  = $v['checkin_time']
                                                               ? Carbon::createFromTimestamp($v['checkin_time'])->format("H:i")
                                                               : '';
                $members[$key]['child'][$k]['checkout_time'] = $v['checkout_time']
                                                               ? Carbon::createFromTimestamp($v['checkout_time'])->format("H:i")
                                                               : '';
                $members[$key]['child'][$k]['hours']         = $v['minutes'] / 60;
                $members[$key]['child'][$k]['hourly_rate']   = $hourlyRate;
                $members[$key]['child'][$k]['revise_time']   = Carbon::createFromTimestamp($v['update_time'])->format('M d Y H:i');
                $members[$key]['child'][$k]['member']        = $v['member'];
            }
        }
        return ['job'=>$jobData,'members'=>array_values($members)];
    }
}