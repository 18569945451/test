<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/30
 * Time: 17:41
 */

namespace App\Api\V5\Recruiter\Transformers\Member;

use Carbon\Carbon;

class DetailTransformer
{
    public function transform($item)
    {
        return [
            'member_id'   => $item->member_id,
            'name'        => $item->member_name,
            'sex'         => $item->member_sex == 1 ? 'Male' : 'Female',
            'nric'        => $item->member_nric,
            'avatar'      => $item->member_avatar,
            'mobile'      => $item->member_mobile,
            'salary_rate' => $item->member_salary_rate,
            'birthday'    => Carbon::createFromTimestamp($item->member_birthday)->toDateString(),
        ];
    }
}