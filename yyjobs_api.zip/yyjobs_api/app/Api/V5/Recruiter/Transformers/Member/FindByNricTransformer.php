<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/12
 * Time: 17:09
 */

namespace App\Api\V5\Recruiter\Transformers\Member;

class FindByNricTransformer
{
    public function transform($item)
    {
        return [
            'member_id'     => $item->member_id,
            'member_name'   => $item->member_name,
            'member_sex'    => $item->member_sex == 1 ? 'Male' : 'Female',
            'member_avatar' => $item->member_avatar,
            'member_nric'   => $item->member_nric,
            'member_mobile' => $item->member_mobile
        ];
    }
}