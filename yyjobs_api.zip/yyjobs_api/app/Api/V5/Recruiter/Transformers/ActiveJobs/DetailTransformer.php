<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/30
 * Time: 17:31
 */

namespace App\Api\V5\Recruiter\Transformers\ActiveJobs;

use Carbon\Carbon;
class DetailTransformer
{
    public function transform($list)
    {
        $data = [];
        $sexArr = ['', 'Male', 'Female'];
        $data['job_id']                   = $list->job_id;
        $data['job_title']                = $list->job_title;
        $data['job_contact_name']         = $list->job_contact_name;
        $data['job_contact_no']           = $list->job_contact_no;
        $data['job_hour_rate']            = $list->job_hour_rate;
        $data['job_start_date']           = Carbon::createFromTimestamp($list->job_start_date)->toDateTimeString();
        $data['job_end_date']             = Carbon::createFromTimestamp($list->job_end_date)->toDateTimeString();
        $data['job_need_people_count']    = $list->job_need_people_count ? $list->job_need_people_count : 0;
        $data['job_address']              = $list->job_address;
        $data['job_zip']                  = $list->job_zip;
        $data['job_latitude']             = $list->job_latitude;
        $data['job_longitude']            = $list->job_longitude;
        $data['job_description']          = $list->job_description;
        $data['job_requirements']         = $list->job_requirements;
        $data['job_post']                 = $list->job_post ? $list->job_post :'';
        $data['job_people_nationality']   = $list->job_people_nationality ? $list->job_people_nationality : '';
        $data['job_people_age']           = array_filter(explode(',',$list->job_people_age));
        $data['job_people_language']      = array_filter(explode(',',$list->job_people_language));
        $data['job_people_sex']           = isset($sexArr[$list->job_people_sex]) ? $sexArr[$list->job_people_sex] : '';
        $data['job_industry_id']          = $list->job_industry_id;
        $data['job_note']                 = $list->job_note;
        $data['employer_id']              = $list->job_employer_admin_id;
        $data['employer_name']            = isset($list->employer) ? $list->employer->name : '';
        $data['industry_name']            = isset($list->industry) ? $list->industry->industry_name : '';
        $data['job_image']                = $list->job_image;

        return $data;
    }
}