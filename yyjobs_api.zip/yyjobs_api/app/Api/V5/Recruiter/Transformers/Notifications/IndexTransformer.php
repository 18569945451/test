<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/30
 * Time: 17:31
 */

namespace App\Api\V5\Recruiter\Transformers\Notifications;

use Illuminate\Support\Collection;
use Carbon\Carbon;
class IndexTransformer
{
    public function transform(Collection $collection)
    {
        $data = [];
        foreach ($collection as $key => $item) {
            $data[$key]['id']      = $item->id;
            $data[$key]['type']    = $item->type;
            $data[$key]['title']   = $item->title;
            $data[$key]['content'] = $item->content;
            $data[$key]['data']    = json_decode($item->data);
            $data[$key]['is_read'] = $item->is_read;
            $data[$key]['time']    = Carbon::createFromTimestamp($item->time)->format('M d,Y H:i');
        }

        return $data;
    }
}