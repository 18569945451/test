<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:11
 */

namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\Admin;
use App\Api\V5\Recruiter\Entities\LabourRequisition;
use App\Api\V5\Recruiter\Entities\Job;
use App\Api\V5\Recruiter\Formattings\ActiveJobs\StoreFormatting;
use App\Api\V5\Recruiter\Transformers\ActiveJobs\IndexTransformer;
use App\Api\V5\Recruiter\Transformers\ActiveJobs\DetailTransformer;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;
use Carbon\Carbon;

class JobService
{
    public $model;

    public function __construct()
    {
        $this->model = new Job();
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function jobList($request)
    {
        $keyword     = request('keyword');
        $date        = request('date') ? Carbon::parse(request('date')) : '';

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model
                    ->where('employer_status', 1)
                    ->when($keyword, function($query) use($keyword){
                        return $query->where('job_employer_company_name', 'like', "%$keyword%");
                    })
                    ->when($date, function($q) use($date){
                        $dayBetween  = [$date->getTimestamp(), $date->addDay()->getTimestamp()];
                        return $q->whereBetween('job_start_date',$dayBetween);
                    },function ($query){
                        return $query->where('job_end_date','>',time());
                    })
                    ->whereIn('job_employer_admin_id', Admin::hasEmployer())
                    ->where('job_status',4)
                    ->withCount(['schedules'=>function($query){
                        return $query->where('parent_id',0)->whereIn('work_status',[2, 5, 6, 8, 11]);
                    }]);

        $data['count']     = $condition->count();
        $data['curPage']   = $curPage;
        $data['pageSize']  = $pageSize;
        $data['countPage'] = ceil($data['count'] / $pageSize);

        $dataList          = $condition->orderBy('job_start_date','ASC')->orderBy('job_employer_company_name','ASC')->offset($offset)->limit($pageSize)->get(['job_id', 'job_title', 'job_start_date', 'job_end_date', 'job_image', 'job_need_people_count','job_employer_admin_id','job_employer_company_name']);
        $data['list']      = (new IndexTransformer())->transform($dataList);


        return $data;
    }

    public function jobDetail($jobId)
    {
        $jobDetail           = $this->model->with(['employer', 'industry'])->find($jobId);
        $data['jobs']        = (new DetailTransformer())->transform($jobDetail);
        return $data;
    }

    /**
     * @param $postalCode
     *
     * @return mixed
     * @throws ValidatorException
     */
    public function getCoordinates($postalCode)
    {
        try {
            $http        = new Client(['defaults' => ['verify' => false]]);
            $response    = $http->get('https://maps.googleapis.com/maps/api/geocode/json'.'?components=postal_code:'.$postalCode.'&key='.env('GOOGLE_MAP_KEY'));
            $result      = json_decode((string)$response->getBody(), true);
            if(!isset($result['results']) || !$result['results']){
                throw new ValidatorException(new MessageBag(['postal_code'=>['No result found']]));
            }
            $data['lng'] = $result['results'][0]['geometry']['location']['lng'];
            $data['lat'] = $result['results'][0]['geometry']['location']['lat'];

            return $data;
        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                throw new ValidatorException(new MessageBag(['postal_code'=>['Unable to get lat and lng']]));
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return mixed
     */
    public function store(Request $request)
    {
        $data = (new StoreFormatting())->format($request);

        $job = $this->model->create($data);

        if ($request->labour_request_id){
            (new LabourRequestService())->linkJob($request->labour_request_id,$job->job_id);
        }

        return $job;
    }

    /**
     * @param Request $request
     *
     * @return mixed
     */
    public function update(Request $request)
    {
        $data = (new StoreFormatting())->format($request);

        return $this->model->where('job_id',$request->job_id)->update($data);
    }


    public function getLabourRequisitions($employerId)
    {
        return LabourRequisition::where('employer_admin_id', $employerId)->where('job_id', '=', 0)->where('status', 'approve')->orderBy('id','desc')->get();
    }

    /**相关的最近工作
     * @param $employerAdminID
     * @param $title
     *
     * @return null
     */
    public function lately($employerAdminID, $title)
    {
        $job = $this->model->where('job_employer_admin_id',$employerAdminID)->where('job_title',$title)->orderBy('job_id','DESC')->first();
        if ($job){
            $data['jobs']        = (new DetailTransformer())->transform($job);
            return $data;
        }
        return null;
    }

    /**
     * 获取聊天室(是否创建了聊天室)
     * @param $jobID
     *
     * @return
     */
    public function getRoom($jobID)
    {
        $job = $this->model->with('rooms')->find($jobID);
        if (count($job->rooms)){
            return $job->rooms[0];
        }
        return null;
    }


}