<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:11
 */

namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\Industry;

class IndustryService
{
    public $model;

    public function __construct()
    {
        $this->model = new Industry();
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function industryList()
    {
        return $this->model->all();
    }



}