<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/9
 * Time: 10:24
 */

namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\Admin;
use App\Api\V5\Recruiter\Entities\Job;
use App\Api\V5\Recruiter\Entities\Member;
use App\Api\V5\Recruiter\Entities\Schedule;
use App\Api\V5\Recruiter\Jobs\CreateChatRoom;
use App\Api\V5\Recruiter\Transformers\Schedule\IndexTransformer;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;

class ScheduleService
{
    public $model;

    public function __construct()
    {
        $this->model = new Schedule();
    }

    /**
     * @param $jobID
     *
     * @return array
     */
    public function scheduleList($jobID)
    {
        $users = $this->model->with(['member','job'])->onlyJob($jobID)
                    ->whereHas('job',$this->jobRestrict())
                    ->onlyParent()->applied()->orderBy('s_id','DESC')->get();
        $job = Job::find($jobID,['job_id','job_employer_company_name','job_start_date','job_end_date']);
        return  (new IndexTransformer())->transform($users,$job);
    }

    /**
     * @param array $schedulesID
     *
     * @return mixed
     */
    public function sendToEmployer(array $schedulesID)
    {
        $schedule   = $this->model->find($schedulesID[0]);
        $this->model->whereIn('s_id', $schedulesID)->whereHas('job',$this->jobRestrict())->update(['is_send' => 1]);
        CreateChatRoom::dispatch($schedule->job_id)->onQueue("api");
    }

    /**
     * @param int $jobID
     *
     * @return mixed
     */
    public function sendAllToEmployer(int $jobID)
    {
        $res = $this->model->onlyJob($jobID)->whereHas('job',$this->jobRestrict())->update(['is_send' => 1]);
        CreateChatRoom::dispatch($jobID)->onQueue("api");
        return $res;
    }

    /**
     * @param $scheduleID
     * @param $status
     *
     * @return mixed
     */
    public function status($scheduleID,$status)
    {
        $res = $this->model
                    ->where('s_id',$scheduleID)
                    ->whereHas('job',$this->jobRestrict())
                    ->update(['work_status' => $status]);
        if ($status == Schedule::REJECT_REQUEST){
            $schedule = $this->model->with('job')->find($scheduleID);
            (new MemberNotificationsService())->notifyRejected($schedule);
        }
        return $res;
    }

    /**
     * Sql限制回调，限制当前recruiter只能操作自己管理的employer的工作
     * @return \Closure
     */
    private function jobRestrict()
    {
        return function($query){
            return $query->whereIn('job_employer_admin_id',Admin::hasEmployer())->select('job_id');
        };
    }

    /**
     * @param $jobID
     * @param $memberID
     * @param bool $send
     * @return mixed
     * @throws ValidatorException
     */
    public function addStaff($jobID,$memberID,$send = false)
    {
        if ($this->hasMember($jobID,$memberID)){
            throw new ValidatorException(new MessageBag(['The employee is already in the job.']));
        }
        $member = Member::find($memberID,['member_id','member_name']);
        $job    = Job::find($jobID,['job_id','job_start_date','job_end_date']);

        return $this->model->create([
            'member_id'              => $member->member_id,
            'member_name'            => $member->member_name,
            'job_id'                 => $job->job_id,
            'adjusted_checkin_time'  => $job->job_start_date,
            'adjusted_checkout_time' => $job->job_end_date,
            'add_time'               => time(),
            'work_status'            => 2,
            'source'                 => 2,
            'is_send'                => $send ? 1 : 0,
        ]);
    }

    /**
     * @param $jobID
     * @param $memberID
     *
     * @return mixed
     */
    private function hasMember($jobID,$memberID)
    {
        return $this->model->onlyJob($jobID)->where('member_id',$memberID)->count();
    }
    
    public function getSendUsers($jobID,$recruiterID)
    {
        $members = $this->model->onlyJob($jobID)->sent()->onlyParent()->get(['member_id']);
        $users = [];
        $users[] = 'r'.$recruiterID;
        foreach ($members as $member) {
            $users[] = 'm'.$member->member_id;
        }
        return $users;
    }
}