<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/30
 * Time: 15:11
 */

namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\Member;
use App\Api\V5\Recruiter\Transformers\Member\DetailTransformer;
use App\Api\V5\Recruiter\Transformers\Member\FindByNricTransformer;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;

class MemberService
{
    public $model;

    public function __construct()
    {
        $this->model = new Member();
    }

    /**
     * @param $memberID
     *
     * @return array
     * @throws ValidatorException
     */
    public function staffInfo($memberID)
    {
        $member = $this->model->find($memberID,['member_name', 'member_id','member_nric', 'member_sex','member_avatar', 'member_mobile','member_salary_rate','member_birthday']);

        if(!$member){
            throw new ValidatorException(new MessageBag(['id'=>['Not Found']]));
        }

        return (new DetailTransformer())->transform($member);
    }

    /**
     * @param $request
     *
     * @throws ValidatorException
     */
    public function updateStaffInfo($request)
    {
        $updateArr = $request->except(['_token', 'member_id']);
        if(count($updateArr) < 1){
            throw new ValidatorException(new MessageBag(['data'=>['You have not modified anything!']]));
        }

        $memberInfo = $this->model->find($request->member_id);

        if(!$memberInfo) {
            throw new ValidatorException(new MessageBag(['id'=>['Not Found']]));
        }
        if($request->member_birthday){
            $updateArr['member_birthday']  = strtotime($request->member_birthday);
        }

        $this->model->where('member_id', $request->member_id)->update($updateArr);
    }

    /**
     * @param $nric
     *
     * @return mixed
     * @throws ValidatorException
     */
    public function findByNricOrMobile($nric, $mobile)
    {
        if(!$nric && !$mobile) {
            throw new ValidatorException(new MessageBag(['id'=>['Nric or Mobile Must Have One']]));
        }
        $member = $this->model->when($mobile, function($q) use($mobile){
            return $q->where('member_mobile', $mobile);
        })->when($nric, function($q) use($nric){
            return $q->whereMemberNric($nric);
        })
            ->first(['member_id','member_name','member_sex','member_avatar','member_status', 'member_nric', 'member_mobile']);
        if (!$member){
            throw new ValidatorException(new MessageBag(['Not found.']));
        }
        switch ($member->member_status){
            case 5 :
                throw new ValidatorException(new MessageBag(['The employee is an invalid user']));
                break;
            case 4 :
                throw new ValidatorException(new MessageBag(['The employee has been rejected by the administrator']));
                break;
            default:
                return (new FindByNricTransformer())->transform($member);
        }
    }

}