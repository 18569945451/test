<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/30
 * Time: 15:24
 */

namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\Member;
use App\Api\V5\Recruiter\Entities\MemberNotifications;
use App\Api\V5\Recruiter\Entities\Schedule;
use App\Traits\Admin\Jpush;

class MemberNotificationsService
{
    use Jpush;
    public $model;

    public function __construct()
    {
        $this->model = new MemberNotifications();
    }

    /**
     * 通知用户工作被拒绝
     * @param Schedule $schedule
     */
    public function notifyRejected(Schedule $schedule)
    {
        $data = $this->createRejectedNotificationData($schedule);
        $member = Member::find($schedule->member_id,['registration_id']);
        if ($member->registration_id){
            $this->notifyJobScheduleRejected($data,$member->registration_id);
        }

    }

    /**
     * 保存被拒绝的通知数据
     * @param $schedule
     *
     * @return array
     */
    public function createRejectedNotificationData($schedule)
    {
        $data['type'] = 'rejected_job';
        $data['member_id'] = $schedule->member_id;
        $data['title'] = 'Your job application has been rejected by YY Part-time Jobs!';
        $data['content'] = "We are sorry to inform you that your job has been rejected by YY Part-time Jobs!";
        $data['job_id'] = $schedule->job->job_id;
        $data['data'] = json_encode(['job_title'=>$schedule->job->job_title,'job_start_date'=>$schedule->job->job_start_date,'job_address'=>$schedule->job->job_address,'job_hour_rate'=>$schedule->job->job_hour_rate]);
        $data['time'] = time();

        $this->model->insert($data);

        $message = "We are sorry to inform you that your job {$schedule->job->job_title} at {$schedule->job->job_address} on ".date('Y-m-d H:i',$schedule->job->job_start_date)." has been rejected by YY Part-time Jobs!";

        return [
            'content' => $message,
            'data'    => ['msg_type' => $data['type'],'job_id'=>$data['job_id']],
        ];
    }
    
    
}