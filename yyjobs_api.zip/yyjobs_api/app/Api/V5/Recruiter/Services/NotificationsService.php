<?php


namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\RecruiterNotifications;
use App\Api\V5\Recruiter\Transformers\Notifications\IndexTransformer;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;

class NotificationsService
{

    public $model;

    public function __construct()
    {
        $this->model = new RecruiterNotifications();
    }


    public function notificationsList($request)
    {
        $curPage      = $request->input('cur_page', 1);
        $pageSize     = $request->input('page_size', 10);
        $offset       = ($curPage - 1) * $pageSize;
        $recruiterID  = auth('recruiter')->user()->id;

        $condition            = $this->model->where('admin_id', $recruiterID);

        $data['count']        = $condition->count();
        $data['curPage']      = $curPage;
        $data['pageSize']     = $pageSize;
        $data['countPage']    = ceil($data['count'] / $pageSize);

        $dataList             = $condition->orderBy('id','DESC')->offset($offset)->limit($pageSize)->get(['id','type','title', 'content','data', 'is_read', 'time']);
        $data['list']         = (new IndexTransformer())->transform($dataList);
        $data['unread_count'] = $this->model->where('admin_id', $recruiterID)->where('is_read', 0)->count();


        return $data;
    }



    public function destroy($id)
    {
        $recruiterID = auth('recruiter')->user()->id;
        $data = $this->model->where('admin_id', $recruiterID)->whereId($id)->first();
        if(!$data){
            throw new ValidatorException(new MessageBag(['id'=>['Not Found']]));
        }

        $this->model->whereId($id)->delete();
    }


    public function read($id)
    {
        $recruiterID = auth('recruiter')->user()->id;
        $data = $this->model->where('admin_id', $recruiterID)->whereId($id)->first();
        if(!$data){
            throw new ValidatorException(new MessageBag(['id'=>['Not Found']]));
        }
        $this->model->whereId($id)->update(array('is_read'=> 1));
    }
}