<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/22
 * Time: 14:02
 */

namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\ChatRoom;

class ChatRoomService
{
    public $model;

    public function __construct()
    {
        $this->model = new ChatRoom();
    }

    /**
     * 插入聊天室数据到数据库
     * @param $roomGroupID
     * @param $roomName
     *
     * @return mixed
     */
    public function createRoom($roomGroupID, $roomName)
    {
        return $this->model->create(['group_id'=>$roomGroupID,'name'=>$roomName]);
    }

    /**
     * 关联工作与聊天室
     * @param $roomGroupID
     * @param $roomName
     * @param $users
     * @param $jobID
     */
    public function syncRoom($roomGroupID,$roomName, $jobID,$users)
    {
        $room = $this->createRoom($roomGroupID,$roomName);
        $room->jobs()->sync([$jobID]);
        $this->syncRoomUser($room,$users);
    }

    /**
     * 同步聊天室人员
     * @param ChatRoom $room
     * @param          $users
     */
    public function syncRoomUser(ChatRoom $room,$users)
    {
        $userData = [];
        foreach ($users as $key=>$user) {
            $userData[$key]['user_id'] = $user;
        }
        $room->users()->createMany($userData);
    }
}