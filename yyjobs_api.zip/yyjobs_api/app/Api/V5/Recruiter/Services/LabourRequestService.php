<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:11
 */

namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\Admin;
use Carbon\Carbon;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V5\Recruiter\Entities\LabourRequisition;
use App\Api\V5\Recruiter\Transformers\LabourRequest\DetailTransformer;
use App\Api\V5\Recruiter\Transformers\LabourRequest\IndexTransformer;

class LabourRequestService
{
    public $model;

    public function __construct()
    {
        $this->model = new LabourRequisition();
    }

    /**
     * @param Carbon $date
     *
     * @return array
     */
    public function week(Carbon $date)
    {
        $between = [$date->copy()->subDays(6),$date->copy()->addDay()];

        $data = $this->model
            ->whereBetween('add_time',$between)
            ->whereIn('employer_admin_id',Admin::hasEmployer())
            ->where('status','pending')
            ->groupBy('days')
            ->select(\DB::raw("COUNT(*) as total,DATE_FORMAT(add_time,'%Y-%m-%d') AS days"))
            ->get();

        $days = $this->getWeekDays($between[0]);

        foreach ($data as $key=>$value) {
            $days[$value->days] = $value->total;
        }

        $returnData = [];
        $i = 0;
        foreach ($days as $dk => $dv) {
            $returnData[$i]['date']=$dk;
            $returnData[$i]['number']=$dv;
            $i++;
        }

        return $returnData;
    }

    /**
     * @param Carbon $day
     *
     * @return array
     */
    private function getWeekDays(Carbon $day)
    {
        $days = [$day->format('Y-m-d')=>0];
        for ($i = 1; $i < 7; $i++) {
            $days[$day->addDays(1)->format('Y-m-d')] = 0;
        }

        return $days;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function requisitionList($request)
    {
        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 5);
        $status   = $request->input('status');
        $offset   = ($curPage - 1) * $pageSize;

        $dayBetween  = $request->input('day')
                     ? [Carbon::parse($request->input('day')),Carbon::parse($request->input('day'))->addDay()]
                     : [Carbon::today(),Carbon::tomorrow()];

        $condition = $this->model
            ->whereBetween('add_time',$dayBetween)
            ->whereIn('employer_admin_id',Admin::hasEmployer())
            ->when($status,function ($query)use($status){
                return $query->where('status',$status);
            });

        $data['count']     = $condition->count();
        $data['curPage']   = $curPage;
        $data['pageSize']  = $pageSize;
        $data['countPage'] = ceil($data['count'] / $pageSize);

        $dataList = $condition
            ->with(['employer'=>function($query){
                return $query->select(['e_admin_id','e_company_name','e_company_logo']);
            }])
            ->orderBy('job_start','DESC')
            ->offset($offset)
            ->limit($pageSize)
            ->get();

        $data['list'] = (new IndexTransformer())->transform($dataList);

        return $data;
    }

    /**
     * @param $id
     *
     * @return array
     * @throws ValidatorException
     */
    public function requisitionDetail($id)
    {
        $detail = $this->model->whereIn('employer_admin_id',Admin::hasEmployer())->with('remark')->find($id);
        if(!$detail){
            throw new ValidatorException(new MessageBag(['Not Found']));
        }
        return (new DetailTransformer())->transform($detail);
    }

    /**
     * @param $request
     *
     * @return mixed
     * @throws ValidatorException
     */
    public function requisitionUpdate($request)
    {
        $requisition = $this->model->whereIn('employer_admin_id',Admin::hasEmployer())->find($request->id);
        if(!$requisition){
            throw new ValidatorException(new MessageBag(['Not Found']));
        }

        $requisition->status = $request->status;
        $requisition->reject_reason = $request->reject_reason;

        return $requisition->save();
    }

    /**
     * @param $day
     *
     * @return mixed
     */
    public function approveAll($day)
    {
        $dayBetween = [Carbon::parse($day),Carbon::parse($day)->addDay()];

        return $this->model
            ->whereIn('employer_admin_id', Admin::hasEmployer())
            ->whereBetween('add_time', $dayBetween)
            ->where('status', 'pending')
            ->update(['status' => 'approve']);
    }

    /**
     * @param $requisitionID
     * @param $jobID
     *
     * @return mixed
     */
    public function linkJob($requisitionID,$jobID)
    {
        return $this->model->where('id',$requisitionID)->update(['job_id'=>$jobID]);
    }

}