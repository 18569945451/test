<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:11
 */

namespace App\Api\V5\Recruiter\Services;

use App\Api\V5\Recruiter\Entities\Admin;
use App\Api\V5\Recruiter\Entities\Employer;
use App\Api\V5\Recruiter\Transformers\Employer\DetailTransformer;
use App\Api\V5\Recruiter\Transformers\Employer\IndexTransformer;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;
class EmployerService
{
    public $model;

    public function __construct()
    {
        $this->model = new Employer();
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function employerList($request)
    {
        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model->whereIn('e_admin_id',Admin::hasEmployer());

        $data['count']     = $condition->count();
        $data['curPage']   = $curPage;
        $data['pageSize']  = $pageSize;
        $data['countPage'] = ceil($data['count'] / $pageSize);

        $dataList = $condition->orderBy('e_company_name','ASC')->offset($offset)->limit($pageSize)->get(['e_admin_id', 'e_id', 'e_contact_no', 'e_company_name', 'e_company_logo', 'e_email',]);
        $data['list'] = (new IndexTransformer())->transform($dataList);

        return $data;
    }


    /**
     * @param $employerID
     *
     * @return array
     * @throws ValidatorException
     */
    public function employerDetail($employerID)
    {
        $employer = $this->model->with('industry')->find($employerID);

        if (!$employer){
            throw new ValidatorException(new MessageBag(['id'=>['Not Found']]));
        }

        return (new DetailTransformer())->transform($employer);
    }

}