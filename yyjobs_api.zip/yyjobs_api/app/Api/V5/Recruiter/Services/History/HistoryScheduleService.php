<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/13
 * Time: 10:07
 */

namespace App\Api\V5\Recruiter\Services\History;

use App\Api\V5\Recruiter\Entities\Admin;
use App\Api\V5\Recruiter\Entities\Job;
use App\Api\V5\Recruiter\Entities\Schedule;
use App\Api\V5\Recruiter\Transformers\History\DetailTransformer;
use Illuminate\Support\Collection;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;

class HistoryScheduleService
{
    public $model;

    public function __construct()
    {
        $this->model = new Schedule();
    }

    public function detailList($jobID)
    {
        $job = Job::whereIn('job_employer_admin_id',Admin::hasEmployer())->find($jobID,['job_id','job_employer_company_name','job_start_date','job_end_date','job_need_people_count']);
        if (!$job){
            throw new ValidatorException(new MessageBag(['Not Found.']));
        }
        $jobOriginMinutes = ($job->job_end_date - $job->job_start_date) / 60;

        $res = $this->model->whereHas('member')
            ->with(['member'=>function($query){
                return $query->select(['member_id','member_name','member_nric','member_salary_rate','member_avatar','member_mobile']);
            }])
            ->appliedWithChild()
            ->onlyJob($jobID)
            ->orderBy('s_id','asc')->orderBy('parent_id','asc')
            ->get(['s_id','member_id','checkin_time','checkout_time','work_hours','adjusted_work_minutes','extra_work_minutes','adjusted_hourly_rate','update_time','employer_remark','parent_id']);

        $data = $this->reSort($res);

        //如果签到了并且签出了，那么就用工作分钟数 - 这个工作实际分钟数得到+/-分钟数
        //没有子数据直接跳过循环
        //第一条子数据需要跟父数据比较，其它子数据需要跟上一条子数据比较 $k-1
        foreach ($data as $key => $value) {
            $data[$key]['minutes'] = $this->comparison($value,$jobOriginMinutes);
            if (!isset($value['child'])){
                continue;
            }
            foreach ($value['child'] as $k => $v) {
                $preWorkMinutes = $k < 1 ? $value['adjusted_work_minutes'] : $data[$key]['child'][$k-1]['adjusted_work_minutes'];
                $data[$key]['child'][$k]['minutes'] = $this->comparison($v,$preWorkMinutes);
            }
        }

        return (new DetailTransformer())->transform($data,$job);
    }

    /**
     * 父子数据排列
     * @param Collection $schedules
     *
     * @return array
     */
    private function reSort(Collection $schedules)
    {
        $array = array_column($schedules->toArray(), null, 's_id');
        $data  = [];
        foreach ($array as $key => $item) {
            if ($item['parent_id'] == 0) {
                $data[$key] = $item;
            } else {
                $data[$item['parent_id']]['child'][] = $item;
            }
        }

        return $data;
    }

    /**
     * 比较得出+/-分钟数
     * @param array $attributes
     * @param       $preWorkMinutes
     *
     * @return int|mixed
     */
    private function comparison(array $attributes, $preWorkMinutes)
    {
        if ($attributes['checkin_time'] && $attributes['checkout_time']) {
            return $attributes['adjusted_work_minutes'] - $preWorkMinutes;
        }

        return 0;
    }
}