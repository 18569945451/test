<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:11
 */

namespace App\Api\V5\Recruiter\Services\History;

use Carbon\Carbon;
use App\Api\V5\Recruiter\Entities\Admin;
use App\Api\V5\Recruiter\Entities\Job;
use App\Api\V5\Recruiter\Transformers\History\IndexTransformer;

class HistoryService
{
    public $model;

    public function __construct()
    {
        $this->model = new Job();
    }



    /**
     * @param $request
     *
     * @return mixed
     */
    public function historyList($request)
    {
        $keyword     = $request->input('keyword');
        $date        = $request->input('date') ? Carbon::parse($request->input('date')) : '';

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model
            ->when($keyword, function($query) use($keyword){
                return $query->where('job_employer_company_name', 'like', "%$keyword%");
            })
            ->where(function($query)use($date){
                $endTime = $date ? $date->copy()->addDay()->getTimestamp() : time();
                return $query->where(function($query)use($date,$endTime){
                        return $query->when($date,function($subQuery)use($date){
                                        $dayBetween  = [$date->getTimestamp(), $date->addDay()->getTimestamp()];
                                        return $subQuery->whereBetween('job_start_date',$dayBetween);
                                     })
                                     ->where('employer_status','<>',1)
                                     ->where('job_end_date','<',$endTime);
                    })
                    ->orWhere(function ($query)use($date,$endTime){
                        return $query->when($date,function($subQuery)use($date){
                                        $dayBetween  = [$date->getTimestamp(), $date->addDay()->getTimestamp()];
                                        return $subQuery->whereBetween('job_start_date',$dayBetween);
                                     })
                                     ->where('job_end_date','<',$endTime);
                    });
            })
            ->whereIn('job_employer_admin_id', Admin::hasEmployer())
            ->withCount(['schedules'=>function($query){
                return $query->applied();
            }]);

        /*$condition = $this->model
            ->when($keyword, function($query) use($keyword){
                return $query->where('job_title', 'like', "%$keyword%");
            })
            ->when($date, function($q) use($date){
                $dayBetween  = [$date->getTimestamp(), $date->addDay()->getTimestamp()];
                $q->whereBetween('job_start_date',$dayBetween);
            })
            ->whereIn('job_employer_admin_id', Admin::hasEmployer())
            ->withCount(['schedules'=>function($query){
                return $query->applied();
            }]);*/

        $data['count']     = $condition->count();
        $data['curPage']   = $curPage;
        $data['pageSize']  = $pageSize;
        $data['countPage'] = ceil($data['count'] / $pageSize);

        $dataList          = $condition->orderBy('job_start_date','DESC')->orderBy('job_employer_company_name','ASC')->offset($offset)->limit($pageSize)->get(['job_id', 'job_title', 'job_start_date', 'job_end_date', 'job_image', 'job_need_people_count', 'employer_status', 'job_employer_admin_id','job_employer_company_name']);
        $data['list']      = (new IndexTransformer())->transform($dataList);


        return $data;
    }


}