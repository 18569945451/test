<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/13
 * Time: 10:12
 */

namespace App\Api\V5\Recruiter\Requests\History;

use App\Api\V5\Recruiter\Requests\BaseRequest;

class IndexRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'cur_page'  => 'nullable|integer',
            'page_size' => 'nullable|integer',
            'date'      => 'nullable|date',
            'keyword'   => 'nullable|string|max:64',
        ];
    }
}
