<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 17:08
 */

namespace App\Api\V5\Recruiter\Requests\Employer;

use App\Api\V5\Recruiter\Requests\BaseRequest;

class DetailRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'employer_id' => 'required|integer|min:1',
        ];
    }
}
