<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/31
 * Time: 14:12
 */

namespace App\Api\V5\Recruiter\Requests\LabourRequest;

use App\Api\V5\Recruiter\Requests\BaseRequest;

class UpdateRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id'            => 'required|integer|min:1',
            'status'        => 'required|in:approve,reject',
            'reject_reason' => 'nullable|string|max:255',
        ];
    }
}
