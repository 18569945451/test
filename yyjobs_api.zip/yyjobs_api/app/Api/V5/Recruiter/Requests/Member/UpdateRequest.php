<?php


namespace App\Api\V5\Recruiter\Requests\Member;

use App\Api\V5\Recruiter\Requests\BaseRequest;
use Illuminate\Validation\Rule;
class UpdateRequest extends BaseRequest
{


    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'member_id'        => 'required|integer|min:1',
            'member_name'      => 'nullable|max:64',
            'member_sex'       => [
                'nullable',
                Rule::in([1, 2]),
            ],
            'member_mobile'    => ['nullable', 'max:20', 'regex:/^[+][0-9]*$/'],
            'member_birthday'  => 'nullable|date_format:Y-m-d',
            'member_avatar'    => 'nullable|image|max:255'
        ];
    }

    public function messages()
    {
        return [
            'member_mobile.regex' => 'Enter Mobile phone number starting with + Area code'
        ];
    }

}