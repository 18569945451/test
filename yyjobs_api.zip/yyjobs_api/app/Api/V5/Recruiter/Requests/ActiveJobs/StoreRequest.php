<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/2
 * Time: 10:30
 */

namespace App\Api\V5\Recruiter\Requests\ActiveJobs;

use App\Api\V5\Recruiter\Requests\BaseRequest;

class StoreRequest extends BaseRequest
{


    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'labour_request_id'      => 'nullable|integer|min:1',
            'job_employer_admin_id'  => 'required|integer|min:1',
            'job_title'              => 'required|string|max:255',
            'job_contact_name'       => 'required|string|max:60',
            'job_contact_no'         => 'required|string|max:60',
            'job_hour_rate'          => 'required|numeric',
            'job_start_date'         => 'required|date',
            'job_end_date'           => 'required|date|after:job_start_date',
            'job_need_people_count'  => 'required|integer|min:1',
            'job_image_url'          => 'required_without:job_image_file|string|max:255',
            'job_image_file'         => 'required_without:job_image_url|image|max:1024',
            'job_address'            => 'required|string|max:255',
            'job_zip'                => 'required|numeric|digits:6',
            'job_latitude'           => 'required|numeric',
            'job_longitude'          => 'required|numeric',
            'job_description'        => 'required|string|max:1000',
            'job_requirements'       => 'nullable|string',
            'job_post'               => 'nullable|string|max:60',
            'job_people_nationality' => 'nullable|string',
            'job_people_age'         => 'nullable|string',
            'job_people_language'    => 'nullable|string',
            'job_industry_id'        => 'required|integer|min:1',
            'job_people_sex'         => 'nullable|in:0,1,2',
            'job_note'               => 'nullable|string|max:1000',
        ];
    }

}