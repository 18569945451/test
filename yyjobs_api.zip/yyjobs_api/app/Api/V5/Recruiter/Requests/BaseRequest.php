<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/30
 * Time: 14:42
 */

namespace App\Api\V5\Recruiter\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

abstract class BaseRequest extends FormRequest
{
    protected function failedValidation(Validator $validator)
    {
        throw (new HttpResponseException(
            apiReturn([], 403, $validator->errors()->first())
        ));
    }
}
