<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/9
 * Time: 14:49
 */

namespace App\Api\V5\Recruiter\Requests\Schedule;

use App\Api\V5\Recruiter\Requests\BaseRequest;

class StatusRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            's_id' => 'required|integer',
            'status' => 'required|in:2,3',
        ];
    }
}
