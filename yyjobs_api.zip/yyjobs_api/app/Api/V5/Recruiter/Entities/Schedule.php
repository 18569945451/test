<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 16:42
 */

namespace App\Api\V5\Recruiter\Entities;


use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    //1：Pending信用低于70的时候申请的，2：Applied申请成功，3：Rejected Request管理员拒绝，4：Auto Cancelled未签到或到时未签出自动取消，5：Complete成功签出待审批，6：Payment Pending待支付，
    //7：Rejected不认可该工作，8：Payment Processed支付完成，9：主动取消，10：主动拒绝，11：auto_complete自动签出，12：no_show，13：Revised
    const APPLY_PENDING     = 1;
    const APPLIED           = 2;
    const REJECT_REQUEST    = 3;
    const AUTO_CANCELLED    = 4;
    const COMPLETE          = 5;
    const PAYMENT_PENDING   = 6;
    const PAYMENT_REJECTED  = 7;
    const PAYMENT_PROCESSED = 8;
    const CANCELLED         = 9;
    const AUTO_COMPLETE     = 11;
    const NO_SHOW           = 12;
    const REVISED           = 13;

    public static $workStatusMap = [
        self::APPLY_PENDING     => "Pending",
        self::APPLIED           => "Applied",
        self::REJECT_REQUEST    => "Rejected",
        self::AUTO_CANCELLED    => "Canceled",
        self::COMPLETE          => "Completed",
        self::PAYMENT_PENDING   => "Payment Pending",
        self::PAYMENT_REJECTED  => "Payment Rejected",
        self::PAYMENT_PROCESSED => "Payment Processed",
        self::CANCELLED         => "Canceled",
        self::AUTO_COMPLETE     => "Completed",
        self::NO_SHOW           => "No Show",
    ];

    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'job_schedules';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 's_id';

    /**
     * @var array
     */
    protected $fillable
        = [
            'member_id',
            'member_name',
            'job_id',
            'is_assigned',
            'cancel_status',
            'cancel_reason',
            'cancel_image',
            'cancel_time',
            'checkin_time',
            'adjusted_checkin_time',
            'checkin_signature',
            'checkin_address',
            'checkout_time',
            'adjusted_checkout_time',
            'checkout_signature',
            'checkout_address',
            'work_hours',
            'adjusted_work_minutes',
            'extra_work_minutes',
            'adjusted_hourly_rate',
            'job_salary',
            'job_rating',
            'reviews',
            'process_date',
            'payment_methods',
            'add_time',
            'member_current_lat',
            'member_current_long',
            'remark',
            'employer_remark',
            'is_send',
            'work_status',
            'revise_version',
            'source',
        ];


    public $timestamps = false;

    public function job()
    {
        return $this->belongsTo(Job::class,'job_id','job_id');
    }

    public function member()
    {
        return $this->belongsTo(Member::class,'member_id','member_id');
    }

    public function scopeOnlyJob($query,$jobID)
    {
        if (is_array($jobID)){
            return $query->whereIn('job_id',$jobID);
        }
        return $query->where('job_id',$jobID);
    }

    public function scopeOnlyParent($query)
    {
        return $query->where('parent_id',0);
    }

    public function scopeSent($query)
    {
        return $query->where('is_send',1);
    }

    public function scopeAppliedWithChild($query)
    {
        return $query->whereIn('work_status',[2,5,6,8,11,12,13]);
    }

    public function scopeApplied($query)
    {
        return $query->appliedWithChild()->onlyParent();
    }
}