<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:13
 */

namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;

class LabourRequisition extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'labour_requisitions';


    /**
     * @var array
     */
    protected $fillable
        = [
            'employer_admin_id',
            'job_title',
            'need_num',
            'job_start',
            'job_end',
            'job_id',
            'remark_id',
            'status',
            'created_at',
        ];


    public $timestamps = false;

    public function requisitionRemark()
    {
        return $this->belongsTo(LabourRequisitionRemark::class, 'id', 'remark_id');
    }

    public function adminUser()
    {
        return $this->belongsTo(Admin::class,'employer_admin_id','id');
    }

    public function employer()
    {
        return $this->belongsTo(Employer::class,'employer_admin_id','e_admin_id');
    }

    public function remark()
    {
        return $this->hasOne(LabourRequisitionRemark::class,'id','remark_id');
    }
}