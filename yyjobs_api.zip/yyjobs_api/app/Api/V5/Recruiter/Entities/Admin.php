<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:14
 */

namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    protected $table = 'admins';


    protected $primaryKey = 'id';


    protected $hidden = [
        //'password',
    ];


    protected $fillable = ['name', 'email', 'password', 'remember_token', 'created_at', 'updated_at', 'type', 'has_employer', 'registration_id','status'];


    public $timestamps = false;

    public static function hasEmployer()
    {
        return explode(',',auth('recruiter')->user()->has_employer);
    }

}
