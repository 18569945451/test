<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/23
 * Time: 10:07
 */

namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;

class ChatRoomUser extends Model
{
    protected $table = 'chat_rooms_users';
    protected $fillable = ['room_id', 'user_id'];
    public $timestamps = false;
}