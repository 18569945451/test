<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/03
 * Time: 16:09
 */
namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'member';


    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'member_id';

    /**
     * @var array
     */
    protected $fillable
        = [
            'member_name',
            'member_sex',
            'member_email',
            'member_password',
            'member_payment_password',
            'member_add_time',
            'member_update_time',
            'member_platform',
            'member_country_code',
            'member_mobile',
            'member_nric',
            'member_school_id',
            'social_access_token',
            'social_google_id',
            'social_fb_id',
            'member_avatar',
            'member_salary_rate',
            'member_birthday',
            'member_credit',
            'member_point',
            'registration_id',
            'member_recruiter_id',
            'member_invite_code',
            'member_status',
        ];


    public $timestamps = false;


}
