<?php


namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;
class Industry extends Model
{
    protected $table = 'industry';


    protected $primaryKey = 'industry_id';


    protected $hidden = [
        //'password',
    ];


    protected $fillable = ['industry_id', 'industry_name', 'industry_image', 'industry_image_new'];


    public $timestamps = false;

}