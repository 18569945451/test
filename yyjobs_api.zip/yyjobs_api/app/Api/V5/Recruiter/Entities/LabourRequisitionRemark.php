<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/7/16
 * Time: 15:13
 */

namespace App\Api\V5\Recruiter\Entities;


use Illuminate\Database\Eloquent\Model;

class LabourRequisitionRemark extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'labour_requisition_remarks';


    /**
     * @var array
     */
    protected $fillable = ['remark', 'signature',];


    public $timestamps = false;

    public function requisition()
    {
        return $this->belongsTo(LabourRequisition::class, 'remark_id', 'id');
    }


}