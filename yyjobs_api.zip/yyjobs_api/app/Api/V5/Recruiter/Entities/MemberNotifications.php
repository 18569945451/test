<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/30
 * Time: 15:25
 */
namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;

class MemberNotifications extends Model
{
    protected $table = 'member_notifications';
    protected $primaryKey = 'id';
    protected $fillable = ['type', 'member_id', 'title', 'content', 'data', 'job_id', 'is_read', 'time',];
    public $timestamps = false;
}
