<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/22
 * Time: 11:48
 */

namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ChatRoom extends Model
{
    use SoftDeletes;
    protected $table = 'chat_rooms';
    protected $fillable = ['group_id', 'name', 'created_at', 'updated_at', 'deleted_at',];
    public $timestamps = true;

    public function jobs()
    {
        return $this->belongsToMany(Job::class,'chat_rooms_jobs','room_id','job_id');
    }

    public function users()
    {
        return $this->hasMany(ChatRoomUser::class,'room_id','id');
    }
}