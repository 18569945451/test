<?php

namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;

class Employer extends Model
{
    protected $table = 'employer';

    protected $primaryKey = 'e_id';

    protected $fillable = ['e_admin_id', 'e_recruiter_id', 'e_company_name', 'e_company_logo', 'e_email', 'e_company_description', 'e_contact_no', 'e_hourly_rate', 'e_industry_id', 'e_status'];

    public $timestamps = false;

    public function industry()
    {
        return $this->hasOne(Industry::class, 'industry_id', 'e_industry_id');
    }
}
