<?php

namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;

class RecruiterNotifications extends Model
{
    protected $table = 'recruiter_notifications';
    protected $primaryKey = 'id';
    protected $fillable = ['type', 'admin_id', 'title', 'content', 'job_id', 'is_read',];
    public $timestamps = false;
}
