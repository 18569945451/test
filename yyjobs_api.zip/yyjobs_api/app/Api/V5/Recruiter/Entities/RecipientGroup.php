<?php

namespace App\Api\V5\Recruiter\Entities;

use Illuminate\Database\Eloquent\Model;
class RecipientGroup extends Model
{
    protected $table = 'recipient_groups';
    protected $primaryKey = 'group_id';
    protected $guarded = ['_token'];
    public $timestamps = false;
}
