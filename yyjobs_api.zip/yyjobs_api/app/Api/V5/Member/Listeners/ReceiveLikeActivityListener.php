<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/25
 * Time: 16:30
 */
namespace App\Api\V5\Member\Listeners;

use App\Api\V5\Member\Events\ReceiveLikeActivityEvent;
use Illuminate\Support\Facades\Redis;

class ReceiveLikeActivityListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ReceiveLikeActivityEvent  $event
     * @return void
     */
    public function handle(ReceiveLikeActivityEvent $event)
    {
        $fromMember = auth('member')->user();
        if ($event->like->likeable_type == 'content'){
            $newsFeed = $event->like->likeable()->with('resources')->first();
            if ($newsFeed->member_id > 0 && $newsFeed->member_id != $fromMember->member_id){
                $data = [
                    'type'               => 'like',
                    'like_id'            => $event->like->id,
                    'news_feed_id'       => $newsFeed->id,
                    'from_member_id'     => $fromMember->member_id,
                    'from_member_name'   => $fromMember->member_name,
                    'from_member_avatar' => $fromMember->member_avatar,
                    'description'        => $newsFeed->description,
                    'created_at'         => time(),
                    'image'              => isset($newsFeed->resources[0]->image) ? $newsFeed->resources[0]->image : '',
                ];
                //$res = Redis::lrange("yyjobs-api:news-feed-activity:{$newsFeed->member_id}:comments",0,-1);
                Redis::lpush("yyjobs-api:news-feed-activity:{$newsFeed->member_id}:comments",json_encode($data));
                Redis::expire("yyjobs-api:news-feed-activity:{$newsFeed->member_id}:comments", (60 * 60 * 24) * 15);
            }
        }
    }
}
