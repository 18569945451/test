<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/25
 * Time: 17:21
 */
namespace App\Api\V5\Member\Listeners;

use App\Api\V5\Member\Events\ReceiveCancelLikeActivityEvent;
use App\Api\V5\Member\Events\ReceiveLikeActivityEvent;
use Illuminate\Support\Facades\Redis;

class ReceiveCancelLikeActivityListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ReceiveCancelLikeActivityEvent  $event
     * @return void
     */
    public function handle(ReceiveCancelLikeActivityEvent $event)
    {
        $fromMember = auth('member')->user();
        if ($event->like->likeable_type == 'content'){
            $newsFeed = $event->like->likeable()->with('resources')->first();
            if ($newsFeed->member_id > 0 && $newsFeed->member_id != $fromMember->member_id){
                Redis::lpush("yyjobs-api:news-feed-activity:{$newsFeed->member_id}:cancel-like",$event->like->id);
                Redis::expire("yyjobs-api:news-feed-activity:{$newsFeed->member_id}:cancel-like", (60 * 60 * 24) * 15);
            }
        }
    }
}
