<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/25
 * Time: 16:57
 */

namespace App\Api\V5\Member\Listeners;

use App\Api\V5\Member\Events\ReceiveCommentActivityEvent;
use Illuminate\Support\Facades\Redis;

class ReceiveCommentActivityListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ReceiveCommentActivityEvent $event
     *
     * @return void
     */
    public function handle(ReceiveCommentActivityEvent $event)
    {
        $fromMember = auth('member')->user();
        if ($event->comment->commentable_type == 'content') {
            $newsFeed = $event->comment->commentable()->with('resources')->first();
            if ($newsFeed->member_id > 0 && $newsFeed->member_id != $fromMember->member_id){
                $data = [
                    'type'               => 'comment',
                    'comment_id'         => $event->comment->id,
                    'news_feed_id'       => $newsFeed->id,
                    'from_member_id'     => $fromMember->member_id,
                    'from_member_name'   => $fromMember->member_name,
                    'from_member_avatar' => $fromMember->member_avatar,
                    'description'        => $newsFeed->description,
                    'body'               => $event->comment->body,
                    'created_at'         => time(),
                    'image'              => isset($newsFeed->resources[0]->image) ? $newsFeed->resources[0]->image : '',
                ];
                //$res = Redis::lrange("yyjobs-api:news-feed-activity:{$newsFeed->member_id}:comments",0,-1);
                Redis::lpush("yyjobs-api:news-feed-activity:{$newsFeed->member_id}:comments", json_encode($data));
                Redis::expire("yyjobs-api:news-feed-activity:{$newsFeed->member_id}:comments", (60 * 60 * 24) * 15);
            }
        }
    }
}
