<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/18
 * Time: 13:46
 */

namespace App\Api\V5\Member\Listeners;

use App\Api\V5\Member\Events\LatestNewsFeedEvent;
use Illuminate\Support\Facades\Redis;

class LatestNewsFeedListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  LatestNewsFeedEvent $event
     *
     * @return void
     */
    public function handle(LatestNewsFeedEvent $event)
    {
        Redis::set("yyjobs-api:latest-activity:news-feed", $event->timestamp);
    }
}
