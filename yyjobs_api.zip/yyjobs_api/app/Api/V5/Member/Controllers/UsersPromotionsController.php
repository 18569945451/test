<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/4
 * Time: 10:16
 */
namespace App\Api\V5\Member\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V5\Member\Presenters\Promotions\MinePresenter;
use App\Api\V5\Member\Repositories\UsersPromotionsRepository;
use App\Api\V5\Member\Repositories\PromotionsRepository;
use Prettus\Validator\Exceptions\ValidatorException;
use Illuminate\Support\MessageBag;
class UsersPromotionsController extends Controller
{
    protected $repository;
    protected $validator;
    protected $promotionsRepository;

    public function __construct(UsersPromotionsRepository $repository,PromotionsRepository $promotionsRepository)
    {
        $this->repository = $repository;
        $this->promotionsRepository = $promotionsRepository;
    }


    /**
     * @SWG\Get(path="/index.php/api/employee/usersPromotions/my_promotions",
     *   tags={"promotions"},
     *   summary="promotions 我的优惠券列表 以及搜索",
     *   description="my promotions",
     *   operationId="my promotions",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="status",type="integer",  description="优惠券的状态0:All  2:Active 3:Expired", required=false),
     *   @SWG\Parameter(in="query",  name="keywords",type="string",  description="暂定为title和promo_code", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function my_promotions(Request $request){
        try {
            $data = $this->repository->myPromotions();

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }


    /**
     * @SWG\Post(path="/index.php/api/employee/usersPromotions/get_promotions",
     *   tags={"promotions"},
     *   summary="promotions 用户获取优惠券",
     *   description="get promotions",
     *   operationId="get promotions",
     *   consumes={"application/x-www-form-urlencoded"},
     *  *   @SWG\Parameter(in="query",  name="id",type="string",  description="优惠券的id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */

    public function get_promotions(Request $request){
        $code = 200;
        try {
            $this->validate($request, [
                'id'       => 'required|string'
            ]);
            $this->promotionsRepository->validatorPromotions(null,$code);

            $data = array();
            $this->promotionsRepository->promotions_clicks();
            $this->repository->get_promotions($code);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], $code, $e->getMessageBag()->first());
        }
    }
}