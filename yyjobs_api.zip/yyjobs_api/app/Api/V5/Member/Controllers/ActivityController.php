<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/25
 * Time: 17:04
 */

namespace App\Api\V5\Member\Controllers;

use App\Api\V5\Member\Repositories\ActivityRepository;
use App\Api\V5\Member\Validators\ActivityValidator;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Prettus\Validator\Exceptions\ValidatorException;

class ActivityController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(ActivityRepository $repository,ActivityValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/activity/index",
     *   tags={"news-feed-activity"},
     *   summary="news-feed 动态列表",
     *   description="news-feed-activity index",
     *   operationId="news-feed-activity index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index()
    {
        $memberId = auth('member')->user()->member_id;
        return apiReturn($this->repository->all($memberId));
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/activity/count",
     *   tags={"news-feed-activity"},
     *   summary="news-feed 动态计数",
     *   description="news-feed-activity count",
     *   operationId="news-feed-activity count",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function count()
    {
        $memberId = auth('member')->user()->member_id;
        return apiReturn($this->repository->count($memberId));
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/activity/latest-time",
     *   tags={"news-feed-activity"},
     *   summary="获取最新动态时间戳",
     *   description="news-feed-activity 获取最新动态时间戳",
     *   operationId="news-feed-activity 获取最新动态时间戳",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function latest(Request $request)
    {
        return apiReturn($this->repository->latest($request->type));
    }
}