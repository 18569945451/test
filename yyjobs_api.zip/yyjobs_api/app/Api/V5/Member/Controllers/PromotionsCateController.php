<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/4
 * Time: 10:20
 */
namespace App\Api\V5\Member\Controllers;
use App\Api\V5\Member\Repositories\CatePromotionsRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class PromotionsCateController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(CatePromotionsRepository $repository)
    {
        $this->repository = $repository;
    }


    /**
     * @SWG\Get(path="/index.php/api/employee/promotionsCate/cate_list",
     *   tags={"promotions"},
     *   summary="promotions 优惠券分类",
     *   description="cate list",
     *   operationId="cate list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function cate_list(Request $request){
        try {
            $data = $this->repository->get_cate();

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}
