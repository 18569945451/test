<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/22
 * Time: 15:57
 */

namespace App\Api\V5\Member\Controllers;

use App\Http\Controllers\Controller;
use App\Api\V5\Member\Validators\NewsFeedSubResourceVoteValidator;
use App\Api\V5\Member\Repositories\NewsFeedSubResourceVoteRepository;
use Illuminate\Http\Request;
use Prettus\Validator\Exceptions\ValidatorException;

class NewsFeedSubResourceVoteController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(NewsFeedSubResourceVoteRepository $repository,NewsFeedSubResourceVoteValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/news-feed/vote/click",
     *   tags={"news-feed-vote"},
     *   summary="click",
     *   description="点击投票",
     *   operationId="点击投票",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="resource_id",type="string",  description="resource_id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function click(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('click');
            $data = $this->repository->click($request->resource_id);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}