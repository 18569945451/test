<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/4
 * Time: 10:11
 */
namespace App\Api\V5\Member\Controllers;
use App\Api\V5\Member\Repositories\PromotionsBannerRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class PromotionsBannerController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(PromotionsBannerRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/promotionsBanner/banner_list",
     *   tags={"promotions"},
     *   summary="promotions 促销广告位",
     *   description="promotions banner",
     *   operationId="promotions banner",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function banner_list(Request $request){
        try {
            $data = $this->repository->getBannerList();

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}