<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 15:02
 */

namespace App\Api\V5\Member\Controllers;

use App\Api\V5\Member\Criteria\NewsFeedComment\ListCriteria;
use App\Api\V5\Member\Presenters\NewsFeedComment\ListPresenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V5\Member\Validators\NewsFeedCommentValidator;
use App\Api\V5\Member\Repositories\NewsFeedCommentRepository;

class NewsFeedCommentController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(NewsFeedCommentRepository $repository,NewsFeedCommentValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/comment",
     *   tags={"news-feed-comment"},
     *   summary="news-feed 评论列表",
     *   description="news-feed comment",
     *   operationId="news-feed comment",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="news_feed_id",type="string",  description="news feed id", required=true),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function comments(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('comments');
            $this->repository->pushCriteria(ListCriteria::class);
            $this->repository->setPresenter(ListPresenter::class);
            $data = $this->repository->commentsList($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/news-feed/comment/create",
     *   tags={"news-feed-comment"},
     *   summary="新增评论",
     *   description="create comment",
     *   operationId="create comment",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="news_feed_id",type="string",  description="news feed id", required=true),
     *   @SWG\Parameter(in="formData",  name="body",type="string",  description="评论类容", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function create(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('create');
            $data = $this->repository->createComment($request);

            return apiReturn($data['data']);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/news-feed/comment/destroy",
     *   tags={"news-feed-comment"},
     *   summary="删除评论",
     *   description="destroy comment",
     *   operationId="destroy comment",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="comment_id",type="string",  description="评论 id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function destroy(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('destroy');
            $data = $this->repository->destroyComment($request->comment_id);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}