<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 17:16
 */

namespace App\Api\V5\Member\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V5\Member\Validators\NewsFeedLikeValidator;
use App\Api\V5\Member\Repositories\NewsFeedLikeRepository;

class NewsFeedLikeController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(NewsFeedLikeRepository $repository,NewsFeedLikeValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/news-feed/like/click",
     *   tags={"news-feed-like"},
     *   summary="click",
     *   description="点赞",
     *   operationId="点赞",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="id",type="string",  description="id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function click(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('click');
            $data = $this->repository->click($request->id);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}