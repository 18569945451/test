<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 15:42
 */

namespace App\Api\V5\Member\Controllers;

use App\Api\V5\Member\Criteria\NewsFeed\AllCriteria;
use App\Api\V5\Member\Criteria\NewsFeed\DestroyCriteria;
use App\Api\V5\Member\Criteria\NewsFeed\DetailCriteria;
use App\Api\V5\Member\Criteria\NewsFeed\HotCriteria;
use App\Api\V5\Member\Criteria\NewsFeed\IndexCriteria;
use App\Api\V5\Member\Criteria\NewsFeed\MineCriteria;
use App\Api\V5\Member\Presenters\NewsFeed\AllPresenter;
use App\Api\V5\Member\Presenters\NewsFeed\DetailPresenter;
use App\Api\V5\Member\Presenters\NewsFeed\IndexPresenter;
use App\Api\V5\Member\Presenters\NewsFeed\HotPresenter;
use App\Api\V5\Member\Presenters\NewsFeed\MinePresenter;
use App\Api\V5\Member\Repositories\NewsFeedRepository;
use App\Api\V5\Member\Validators\NewsFeedValidator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class NewsFeedController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(NewsFeedRepository $repository,NewsFeedValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/index",
     *   tags={"news-feed"},
     *   summary="news-feed 列表",
     *   description="news-feed index",
     *   operationId="news-feed index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('index');
            $this->repository->pushCriteria(IndexCriteria::class);
            $this->repository->setPresenter(IndexPresenter::class);
            $data = $this->repository->newsFeedList($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }


    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/all",
     *   tags={"news-feed"},
     *   summary="news-feed 列表",
     *   description="news-feed all",
     *   operationId="news-feed all",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="micro_timestamp",type="string",  description="毫秒", required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function all(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('all');
            $this->repository->pushCriteria(AllCriteria::class);
            $this->repository->setPresenter(AllPresenter::class);
            $data = $this->repository->newsFeedAll($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/hot",
     *   tags={"news-feed"},
     *   summary="news-feed hot 列表",
     *   description="news-feed hot index",
     *   operationId="news-feed hot index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function hot(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('hot');
            $this->repository->pushCriteria(HotCriteria::class);
            $this->repository->setPresenter(HotPresenter::class);
            $data = $this->repository->newsFeedHotList($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/mine",
     *   tags={"news-feed"},
     *   summary="我的 news-feed 列表",
     *   description="news-feed mine",
     *   operationId="news-feed mine",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function mine(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('mine');
            $this->repository->pushCriteria(MineCriteria::class);
            $this->repository->setPresenter(MinePresenter::class);
            $data = $this->repository->mineNewsFeedList($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/news-feed/create",
     *   tags={"news-feed"},
     *   summary="发布新news-feed",
     *   description="news-feed create",
     *   operationId="news-feed create",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="description",type="string",  description="文字内容(最大1024)", required=false),
     *   @SWG\Parameter(in="formData",  name="resource[0]",type="file",  description="图片", required=false),
     *   @SWG\Parameter(in="formData",  name="resource[1]",type="file",  description="图片", required=false),
     *   @SWG\Parameter(in="formData",  name="resource[2]",type="file",  description="图片", required=false),
     *   @SWG\Parameter(in="formData",  name="resource[3]",type="file",  description="图片", required=false),
     *   @SWG\Parameter(in="formData",  name="resource[4]",type="file",  description="图片", required=false),
     *   @SWG\Parameter(in="formData",  name="resource[5]",type="file",  description="图片", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function create(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('create');
            $this->validator->createAction();
            $data = $this->repository->createNewsFeed($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/news-feed/detail",
     *   tags={"news-feed"},
     *   summary="news-feed 详细信息(评论列表调用)",
     *   description="news-feed detail",
     *   operationId="news-feed detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="id",type="string",  description="news feed id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('detail');
            $this->repository->pushCriteria(DetailCriteria::class);
            $this->repository->setPresenter(DetailPresenter::class);
            $data = $this->repository->newsFeedDetail();

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/news-feed/destroy",
     *   tags={"news-feed"},
     *   summary="news-feed 删除",
     *   description="news-feed 删除",
     *   operationId="news-feed 删除",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="id",type="string",  description="news feed id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function destroy(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('destroy');
            $this->repository->pushCriteria(DestroyCriteria::class);
            $data = $this->repository->newsFeedDestroy($request->id);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }


}