<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 14:07
 */
namespace App\Api\V5\Member\Controllers;
use App\Api\V5\Member\Criteria\Promotions\ListCriteria;
use App\Api\V5\Member\Criteria\Promotions\DetailCriteria;
use App\Api\V5\Member\Presenters\Promotions\ListPresenter;
use App\Api\V5\Member\Presenters\Promotions\DetailPresenter;
use App\Api\V5\Member\Repositories\PromotionsRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class PromotionsController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(PromotionsRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/promotions/index",
     *   tags={"promotions"},
     *   summary="promotions 列表,promotions列表搜索",
     *   description="promotions index",
     *   operationId="promotions index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页(无需分页不用传)", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10无需分页不用传)", required=false),
     *   @SWG\Parameter(in="query",  name="keywords",type="string",  description="关键字(初步定义为title和promo_code)", required=false),
     *   @SWG\Parameter(in="query",  name="cate_id",type="string",  description="对应的分类id", required=false),
     *   @SWG\Parameter(in="query",  name="status",type="string",  description="0:All 1:UpComing 2.OnGoging 可以用来搜索，列表页不用传", required=false),
     *   @SWG\Parameter(in="query",  name="limit",type="string",  description="不需要分页,limit是要取数据的条数", required=false),
     *   @SWG\Parameter(in="query",  name="except_id",type="string",  description="需要排除掉的id", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(Request $request){
        try {
            $this->repository->pushCriteria(ListCriteria::class);
            $this->repository->setPresenter(ListPresenter::class);
            $data = $this->repository->promotionsList($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }


    /**
     * @SWG\Get(path="/index.php/api/employee/promotions/detail",
     *   tags={"promotions"},
     *   summary="promotions 详情",
     *   description="promotions detail",
     *   operationId="promotions detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="id",type="string",  description="优惠券的id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(Request $request){
        try {
            $this->validate($request, [
                'id'       => 'required'
            ]);
            $this->repository->pushCriteria(DetailCriteria::class);
            $this->repository->setPresenter(DetailPresenter::class);
            $data = $this->repository->PromotionsDetail();

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

}