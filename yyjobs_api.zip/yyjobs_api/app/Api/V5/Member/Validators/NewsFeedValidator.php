<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 16:04
 */

namespace App\Api\V5\Member\Validators;

use Illuminate\Support\MessageBag;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use \Prettus\Validator\LaravelValidator;

class NewsFeedValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'index' => [
                'keyword'   => 'sometimes|string|max:32',
                'cur_page'  => 'sometimes|integer|min:0',
                'page_size' => 'sometimes|integer|min:1',
            ],
            'hot' => [
                'cur_page'  => 'sometimes|integer|min:0',
                'page_size' => 'sometimes|integer|min:1',
            ],
            'mine' => [
                'cur_page'  => 'sometimes|integer|min:0',
                'page_size' => 'sometimes|integer|min:1',
            ],
            'detail' => [
                'id'  => 'required|integer|min:1',
            ],
            'create' => [
                'description'  => 'sometimes|string|max:1024',
                'resource'  => 'sometimes|array|max:6',
            ],
            'destroy' => [
                'id'  => 'required|integer|min:1',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    public function createAction()
    {
        if (!request()->all()){
            throw new ValidatorException(new MessageBag(["Oops, you can't post empty content."]));
        }
    }
}