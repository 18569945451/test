<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 17:18
 */

namespace App\Api\V5\Member\Validators;

use \Prettus\Validator\Contracts\ValidatorInterface;
use \Prettus\Validator\LaravelValidator;

class NewsFeedLikeValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            /*'comments' => [
                'news_feed_id'  => 'required|integer|min:1',
                'cur_page'  => 'sometimes|integer|min:0',
                'page_size' => 'sometimes|integer|min:1',
            ],
            'create' => [
                'news_feed_id'  => 'required|integer|min:1',
                'body'  => 'required|string|max:512',
            ],*/
            'click' => [
                'id'  => 'required|integer|min:1',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];
}