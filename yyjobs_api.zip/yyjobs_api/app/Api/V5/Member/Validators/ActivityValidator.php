<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/18
 * Time: 14:00
 */

namespace App\Api\V5\Member\Validators;

use \Prettus\Validator\Contracts\ValidatorInterface;
use \Prettus\Validator\LaravelValidator;

class ActivityValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'latest' => [
                'type'   => 'required|in:news-feed,promotion',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

}