<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 16:04
 */

namespace App\Api\V5\Member\Validators;

use Illuminate\Support\MessageBag;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use \Prettus\Validator\LaravelValidator;

class NewsFeedSubResourceVoteValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'click' => [
                'resource_id'  => 'required|integer|min:1',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];
}