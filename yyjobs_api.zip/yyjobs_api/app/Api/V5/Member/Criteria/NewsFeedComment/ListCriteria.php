<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 15:08
 */

namespace App\Api\V5\Member\Criteria\NewsFeedComment;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $newsFeedId = request('news_feed_id');
        return $model->with(['member'=>function($query){
            return $query->select(['member_id','member_name','member_avatar']);
        }])
            ->where('commentable_id',$newsFeedId)
            ->where('commentable_type','content')
            ->orderBy('created_at','DESC');
    }
}