<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 14:23
 */
namespace App\Api\V5\Member\Criteria\Promotions;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $cateId   =  request()->input('cate_id');

        $keywords = request()->input('keywords');
        $except_id = (int)request()->input('except_id') >0 ?(int)request()->input('except_id'):0;

        $currentTime = date('Y-m-d H:i:s',time());
        $status = (int)request()->input('status');
        $limit = (int)request()->input('limit') >0 ?(int)request()->input('limit'):0;

        $obj = $model->where('is_deleted',0)->when($cateId,function($q) use($cateId){
            return $q->where('cate_id',$cateId);
        })->when($keywords,function($q) use($keywords){
            return $q->whereRaw(" (title like '%$keywords%' or promo_code like '%$keywords%')");
        })->when($except_id,function($q) use($except_id){
            return $q->where('id','<>',$except_id);
        })->when($limit,function($q) use($limit){
            return $q->limit($limit);
        })
        ->where('end_date','>=',$currentTime)
        ->orderBy('publish_date','desc')->select('id','cate_id','title','summary','image','start_date','end_date');

        switch($status){
            //快要到来的
            case 1:
                $obj->where('start_date','>',$currentTime);
                break;
            case 2:
                //已经在运行的
                $obj->where('start_date','<=',$currentTime);
                $obj->where('end_date','>=',$currentTime);
                break;
            default:
        }

        return $obj;
    }
}