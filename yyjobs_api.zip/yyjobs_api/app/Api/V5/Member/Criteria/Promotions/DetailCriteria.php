<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 14:23
 */
namespace App\Api\V5\Member\Criteria\Promotions;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class DetailCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $id = request()->input('id');
        $users_id = isset(auth('member')->user()->member_id) ? auth('member')->user()->member_id : '';
        return $model->where('is_deleted',0)
                     ->where('id',$id)
                     ->when($users_id, function($qy) use($users_id){
                         return $qy->with(['users_promotions'=>function($q)use($users_id){
                             $q->where('users_id',$users_id);
                         }]);
                     })
                     ->select(
                        'id','title','description','image_detail','start_date', 'end_date','publish_date','summary','promo_code','cate_id'
                     );
    }
}