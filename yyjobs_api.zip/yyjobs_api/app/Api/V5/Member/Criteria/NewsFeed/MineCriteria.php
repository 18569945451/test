<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 14:15
 */

namespace App\Api\V5\Member\Criteria\NewsFeed;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class MineCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        return $model
            ->with('resources')
            //->with('member')
            ->where('member_id',auth('member')->user()->member_id)->orderBy('created_at','DESC');
    }
}