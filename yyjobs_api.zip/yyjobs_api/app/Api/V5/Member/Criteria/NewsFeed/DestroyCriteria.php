<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/15
 * Time: 14:16
 */

namespace App\Api\V5\Member\Criteria\NewsFeed;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class DestroyCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $id       = request('id');
        $memberId = auth('member')->user()->member_id;

        return $model->whereId($id)->whereMemberId($memberId);
    }
}