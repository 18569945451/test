<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/20
 * Time: 15:29
 */

namespace App\Api\V5\Member\Criteria\NewsFeed;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class AllCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $keyword        = request('keyword');
        $microTimestamp = request('micro_timestamp');

        return $model
            ->where(function($query)use($keyword){
                return $query->whereHas('member',function ($query)use($keyword){
                    return $query->where(function ($subQuery)use($keyword){
                        return $subQuery->where('member_name','like',"%{$keyword}%");
                    });
                })
                    ->orWhereHas('admin',function ($query)use($keyword){
                        return $query->where(function ($subQuery)use($keyword){
                            return $subQuery->where('name','like',"%{$keyword}%");
                        });
                    })
                    ->orWhere('description','like',"%{$keyword}%");
            })
            ->with([
                'admin',
                'member'=>function($query){
                    return $query->select(['member_id','member_name','member_avatar']);
                },
                'likes'=>function($query){
                    return $query->where('member_id',auth('member')->user()->member_id);
                },
                'resources'
            ])
            ->when($microTimestamp,function($query)use($microTimestamp){
                return $query->where('updated_micro_at','<',$microTimestamp);
            })
            ->withCount('likes')
            ->withCount('comments')
            ->orderBy('updated_micro_at', 'DESC');
    }
}