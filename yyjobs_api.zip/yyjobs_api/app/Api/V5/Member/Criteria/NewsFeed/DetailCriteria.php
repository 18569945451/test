<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 14:41
 */

namespace App\Api\V5\Member\Criteria\NewsFeed;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class DetailCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $id       = request('id');
        $memberId = auth('member')->user()->member_id;

        return $model
            ->with([
                'resources',
                'member',
                'admin',
                'likes'=>function($query)use($memberId){
                    return $query->where('member_id',$memberId);
                }
            ])
            ->withCount(['likes','comments'])
            ->where('id',$id)
            /*->where('member_id',$memberId)*/;
    }
}