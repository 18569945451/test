<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/8
 * Time: 15:37
 */

namespace App\Api\V5\Member\Criteria\NewsFeed;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class HotCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $oneMonthAgo = Carbon::now()->addMonth(-1);
        return $model
            ->with([
                'member'=>function($query){
                    return $query->select(['member_id','member_name','member_avatar']);
                },
                'likes'=>function($query){
                    return $query->where('member_id',auth('member')->user()->member_id);
                },
                'resources'
            ])
            ->whereHas('likes')
            ->withCount('likes')
            ->withCount('comments')
            ->where('member_id', '>',0)
            ->where('updated_at', '>',$oneMonthAgo)
            ->orderBy('likes_count','DESC')
            ->orderBy('updated_at','DESC');
    }
}