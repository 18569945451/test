<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 15:50
 */

namespace App\Api\V5\Member\Criteria\NewsFeed;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class IndexCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $keyword       = request('keyword');

        return $model
            ->where(function($query)use($keyword){
                return $query->whereHas('member',function ($query)use($keyword){
                    return $query->where(function ($subQuery)use($keyword){
                        return $subQuery->where('member_name','like',"%{$keyword}%");
                    });
                })
                    ->orWhereHas('admin',function ($query)use($keyword){
                        return $query->where(function ($subQuery)use($keyword){
                            return $subQuery->where('name','like',"%{$keyword}%");
                        });
                    })
                    ->orWhere('description','like',"%{$keyword}%");
            })
            ->with([
                'admin',
                'member'=>function($query){
                    return $query->select(['member_id','member_name','member_avatar']);
                },
                'likes'=>function($query){
                    return $query->where('member_id',auth('member')->user()->member_id);
                },
                'resources'
            ])
            ->withCount('likes')
            ->withCount('comments')
            ->orderBy('updated_at', 'DESC');
    }
}