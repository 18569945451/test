<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 18:23
 */
namespace App\Api\V5\Member\Repositories;


use App\Api\V5\Member\Entities\UsersPromotions;
use App\Api\V6\Member\Jobs\RewardsPointRecord;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;
use Prettus\Repository\Eloquent\BaseRepository;

class UsersPromotionsRepository extends BaseRepository
{
    public function model()
    {
        return UsersPromotions::class;
    }


    public function myPromotions(){
        $users_id = auth('member')->user()->member_id;
        $time = time();
        $status = request()->input('status')?(int)request()->input('status'):0;
        $obj = $this->model->join('promotions','promotions.id','users_promotions.promotions_id');
        $currentTime = date('Y-m-d H:i:s',time());
        $keywords = request()->input('keywords');
        switch($status){
            //Active //已经在运行的
            case 2:
                $obj->where('end_date','>=',$currentTime);
                break;
            //end //已经结束的
            case 3:
                $obj->where('end_date','<',$currentTime);
                break;
            default:
        }
        
        $result = $obj->where('users_id',$users_id)
                        ->when($keywords,function($q) use($keywords){
                            $q->whereRaw(" (promotions.title like '%$keywords%' or promotions.promo_code like '%$keywords%')");
                        })
                        ->orderBy('diffTime','asc')
                       ->selectRaw("promotions.id,promotions.title,promotions.summary,
                                promotions.image,promotions.promo_code,promotions.start_date,
                                promotions.end_date,ABS('$time' - UNIX_TIMESTAMP(start_date))  AS diffTime")
                        ->get();
        if(!$result->isEmpty()){
            foreach($result as &$v){
                $start_time = $v->start_date;
                $end_time = $v->end_date;
                $v['start_date'] = date('M d,Y',strtotime($v->start_date));
                $v['end_date'] = date('M d,Y',strtotime($v->end_date));
                $v['start_time'] = strtotime($start_time);
                $v['end_time'] = strtotime($end_time);
            }
        }
        return $result;
    }

    public function get_promotions(&$code){
        $id = request()->input('id');
        $users_id = auth('member')->user()->member_id;
        if($this->model->where('users_id',$users_id)->where('promotions_id',$id)->first()){
            $code = 403;
            throw new ValidatorException(new MessageBag(["You've already got it."]));
        }
        $my_promotions_arr = array(
           'users_id'       => auth('member')->user()->member_id,
           'promotions_id'  => $id,
            'addtime'       => time()
        );

        //rewards 积分
        RewardsPointRecord::dispatch(
            [
                'member_id'     => auth('member')->user()->member_id,
                'member_name'   => auth('member')->user()->member_name,
                'promotions_id' => $id,
            ],
            'Promotion_Apply'
        );

        $this->model->insert($my_promotions_arr);
    }

}