<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 15:46
 */

namespace App\Api\V5\Member\Repositories;

use App\Api\V5\Member\Events\LatestNewsFeedEvent;
use App\Api\V6\Member\Jobs\RewardsPointRecord;
use Carbon\Carbon;
use DB;
use App\Api\V5\Member\Entities\NewsFeed;
use App\Api\V5\Member\Entities\NewsFeedSubResource;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class NewsFeedRepository extends BaseRepository
{
    public function model()
    {
        return NewsFeed::class;
    }

    /**
     * @param $request
     *
     * @return bool
     */
    public function createNewsFeed($request)
    {
        $member = auth('member')->user();

        $updatedForCarbon                 = Carbon::now();
        $newsFeedData['member_id']        = $member->member_id;
        $newsFeedData['description']      = $request->description ?? '';
        $newsFeedData['updated_at']       = $updatedForCarbon;
        $newsFeedData['updated_micro_at'] = $updatedForCarbon->getTimestamp().str_pad($updatedForCarbon->micro, 6, 0, STR_PAD_LEFT);

        $resourceRep = new NewsFeedSubResourceRepository($this->app);

        DB::beginTransaction();
        try {
            $newsFeed = $this->create($newsFeedData);
            if ($request->has('resource')){
                foreach ($request->resource as $image) {
                    $filePath = $resourceRep->saveImageResource($image);
                    $resource = new NewsFeedSubResource(['image' => $filePath]);
                    $newsFeed->resources()->save($resource);
                }
            }

            //rewards 积分
            RewardsPointRecord::dispatch(
                [
                    'member_id'     => auth('member')->user()->member_id,
                    'member_name'   => auth('member')->user()->member_name,
                    'newsFeed_id' => $newsFeed->id,
                ],
                'NewsFeed_Post'
            );


            DB::commit();
            event(new LatestNewsFeedEvent(Carbon::parse($newsFeed->created_at)->getTimestamp()));
            return true;
        } catch (\Exception $e) {
            DB::rollback();
            return false;
        }
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function newsFeedList($request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $result = $condition->offset($offset)->limit($pageSize)->get();
        $parserResult = $this->parserResult($result)['data'];

        $pollRep = new NewsFeedPollRepository($this->app);
        $pollData = $pollRep->newsFeedListTypeOfPoll($parserResult);

        $data['list'] = $this->newsFeedAssemble($parserResult,$pollData);
        
        return $data;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function newsFeedAll($request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $result = $condition->offset($offset)->limit($pageSize)->get();
        $parserResult = $this->parserResult($result)['data'];

        $pollRep = new NewsFeedPollRepository($this->app);
        $pollData = $pollRep->newsFeedListTypeOfPoll($parserResult,true);

        $data['list'] = $this->newsFeedAssemble($parserResult,$pollData);

        return $data;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function newsFeedHotList($request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $result = $condition->offset($offset)->limit($pageSize)->get();
        $data['list'] = $this->parserResult($result)['data'];

        return $data;
    }

    /**
     * Content类型与Poll类型组装
     * @param $newsFeed
     * @param $newsFeedPoll
     *
     * @return mixed
     */
    protected function newsFeedAssemble($newsFeed,$newsFeedPoll)
    {
        foreach ($newsFeed as $key => $value) {
            if (count($value) == 2){
                $newsFeed[$key] = $newsFeedPoll[array_first($value)];
            }
        }
        return $newsFeed;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function mineNewsFeedList($request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $result = $condition->offset($offset)->limit($pageSize)->get();

        $data['list'] = $this->parserResult($result)['data'];

        return $data;
    }

    /**
     * @return mixed
     */
    public function newsFeedDetail()
    {
        return $this->first();
    }

    /**
     * 删除 News Feed
     * @param $id
     *
     * @return int
     * @throws ValidatorException
     */
    public function newsFeedDestroy($id)
    {
        try {
            return $this->delete($id);
        } catch (\Exception $e) {
            throw new ValidatorException(new MessageBag(["Oops, Did not find an entry to delete."]));
        }

    }
}