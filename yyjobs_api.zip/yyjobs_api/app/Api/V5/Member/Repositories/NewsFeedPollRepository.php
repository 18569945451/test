<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 10:50
 */

namespace App\Api\V5\Member\Repositories;

use App\Api\V5\Member\Entities\NewsFeedPoll;
use Prettus\Repository\Eloquent\BaseRepository;

class NewsFeedPollRepository extends BaseRepository
{
    public function model()
    {
        return NewsFeedPoll::class;
    }

    /**
     * 为了减少查询次数，把Poll类型集中处理
     * @param $newsFeeds
     * @param bool $hasMicro
     *
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function newsFeedListTypeOfPoll($newsFeeds,$hasMicro = false)
    {
        $pollIds = [];
        $ids = [];
        $member = auth('member')->user();
        foreach ($newsFeeds as $item) {
            if (count($item) == 2){
                $pollIds[] = $item['poll_id'];
                $ids[$item['poll_id']] = $item['id'];
            }
        }

        $pollData = $this->model
            ->with(
                [
                    'resources'=>function($query)use($member){
                        return $query->with(['votes'=>function($subQuery)use($member){
                            return $subQuery->where('member_id',$member->member_id);
                        }])->withCount('votes');
                    },
                    'likes'=>function($query)use($member){
                        return $query->where('member_id',$member->member_id);
                    },
                    'admin'
                ]
            )
            ->withCount('likes')
            ->withCount('comments')
            ->whereIn('id',$pollIds)
            ->orderBy('updated_at','DESC')
            ->get();

        $typeOfPoll = [];
        foreach ($pollData as $key => $value) {
            $micro = $hasMicro ? $value->updated_micro_at : 0 ;
            $typeOfPoll[$ids[$value->id]] = [
                'id'             => $ids[$value->id],
                'type'           => 'poll',
                'poll_type'      => $value->type,
                'created_at'     => $value->created_at->getTimestamp(),
                'micro_at'       => $micro,
                'description'    => $value->description,
                'question'       => $value->question,
                'publish_by'     => $value->admin->name,
                'avatar'         => "",
                'resources'      => $value->resources,
                'likes_count'    => $value->likes_count,
                'comments_count' => $value->comments_count,
                'likes'          => $value->likes,
            ];
        }

        return $typeOfPoll;
    }
    
    
}