<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/25
 * Time: 17:05
 */

namespace App\Api\V5\Member\Repositories;
use Illuminate\Support\Facades\Redis;

class ActivityRepository
{
    /**
     * @param $memberId
     *
     * @return array
     */
    public function all($memberId)
    {
        $redisData = Redis::lrange("yyjobs-api:news-feed-activity:{$memberId}:comments",0,-1);
        $cancelData = Redis::lrange("yyjobs-api:news-feed-activity:{$memberId}:cancel-like",0,-1);

        $data = [];
        foreach ($redisData as $key => $value) {
            $item = json_decode($value,true);
            if ($item['type'] == 'comment'){
                $data[] = $item;
                continue;
            }
            if (!in_array($item['like_id'],$cancelData)){
                $data[] = $item;
            }
        }
        Redis::del([
            "yyjobs-api:news-feed-activity:{$memberId}:comments",
            "yyjobs-api:news-feed-activity:{$memberId}:cancel-like",
        ]);
        return $data;
    }

    /**
     * @param $memberId
     *
     * @return array
     */
    public function count($memberId)
    {
        $redisData = Redis::llen("yyjobs-api:news-feed-activity:{$memberId}:comments");
        $cancelData = Redis::llen("yyjobs-api:news-feed-activity:{$memberId}:cancel-like");
        return $redisData - $cancelData;
    }

    /**
     * @return mixed
     */
    public function latest()
    {
        return [
            'news_feed' => Redis::get("yyjobs-api:latest-activity:news-feed") ?? 0,
            'promotion' => Redis::get("yyjobs-api:latest-activity:promotion") ?? 0,
        ];
    }
}