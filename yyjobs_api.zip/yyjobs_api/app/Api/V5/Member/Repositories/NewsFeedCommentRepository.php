<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 15:04
 */

namespace App\Api\V5\Member\Repositories;

use App\Api\V5\Member\Entities\NewsFeed;
use App\Api\V5\Member\Entities\NewsFeedComment;
use App\Api\V5\Member\Events\ReceiveCommentActivityEvent;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V5\Member\Presenters\NewsFeedComment\ListPresenter;

class NewsFeedCommentRepository extends BaseRepository
{
    public function model()
    {
        return NewsFeedComment::class;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function commentsList($request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $result = $condition->offset($offset)->limit($pageSize)->get();

        $data['list'] = $this->parserResult($result)['data'];

        return $data;
    }

    /**
     * @param Request $request
     *
     * @return mixed
     */
    public function createComment(Request $request)
    {
        $newsFeed = NewsFeed::find($request->news_feed_id);

        $request->request->add(['member_id'=>auth('member')->user()->member_id]);

        if ($newsFeed->news_feed_poll_id == 0 ){
            $request->request->add(
                ['commentable_type' => 'content','commentable_id'=>$newsFeed->id]
            );
        }else{
            $request->request->add(
                ['commentable_type' => 'poll','commentable_id'=>$newsFeed->news_feed_poll_id]
            );
        }
        $comment = $this->model->create($request->all());
        event(new ReceiveCommentActivityEvent($comment));
        $this->setPresenter(ListPresenter::class);
        return $this->parserResult($comment);
    }

    /**
     * 删除评论
     * @param $id
     *
     * @return int
     * @throws ValidatorException
     */
    public function destroyComment($id)
    {
        $currentMember = auth('member')->user();
        $comment = $this->model->find($id);

        //news feed 发布人删除别人的评论
        if ($comment->commentable->member_id == $currentMember->member_id){
            return $this->delete($id);
        }

        //评论人删除自己的评论
        if ($comment->member_id == $currentMember->member_id){
            return $this->delete($id);
        }

        throw new ValidatorException(new MessageBag(["Can't delete someone's comment."]));

    }
}