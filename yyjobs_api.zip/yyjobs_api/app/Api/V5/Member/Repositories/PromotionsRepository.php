<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 14:16
 */
namespace App\Api\V5\Member\Repositories;


use App\Api\V5\Member\Entities\Promotions;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;
use Prettus\Repository\Eloquent\BaseRepository;

class PromotionsRepository extends BaseRepository
{
    public function model()
    {
        return Promotions::class;
    }

    //列表页和搜索
    public function promotionsList()
    {
        $this->applyCriteria();
        $curPage  =  request()->input('cur_page');
        $pageSize =  request()->input('page_size');
        $mark = ($curPage && $pageSize) ? true : false;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage ? $curPage :1;
        $data['pageSize']    = $pageSize ? $pageSize :10;
        $data['countPage']   = ceil($data['count'] / $data['pageSize']);

        $obj = $condition->when($mark,function($q) use($curPage,$pageSize){
                   return $q->offset(($curPage - 1) * $pageSize)->limit($pageSize);
              });

        $result =  $obj->get();

        $data['list'] = $this->parserResult($result);
        return $data;
    }

    public function PromotionsDetail(){
        return $this->first();
    }



    public function promotions_clicks()
    {
        $id = (int)request()->input('id');
        $this->model->where('id',$id)->increment('clicks','1');
    }

    public function validatorPromotions($id = null, &$code){
        $id = $id ? $id :(int)request()->input('id');

        $tempData = $this->model->where('id',$id)->where('is_deleted',0)->first();
        $time  = date('Y-m-d H:i:s',time());
        if(!$tempData){
            $code = 403;
            throw new ValidatorException(new MessageBag(["Promotions is not Exist!"]));
        }
        if($tempData && $tempData['end_date'] < $time){
            $code = -1;
            throw new ValidatorException(new MessageBag(["Promotions is Expired!"]));
        }
    }

}