<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 17:17
 */

namespace App\Api\V5\Member\Repositories;

use App\Api\V5\Member\Entities\NewsFeed;
use App\Api\V5\Member\Entities\NewsFeedLike;
use App\Api\V5\Member\Events\ReceiveCancelLikeActivityEvent;
use App\Api\V5\Member\Events\ReceiveLikeActivityEvent;
use Prettus\Repository\Eloquent\BaseRepository;

class NewsFeedLikeRepository extends BaseRepository
{
    public function model()
    {
        return NewsFeedLike::class;
    }

    /**
     * @param $newsFeedId
     *
     * @return bool|int
     */
    public function click($newsFeedId)
    {
        $member = auth('member')->user();
        $newsFeed = NewsFeed::with(['likes'=>function($query)use($member){
            return $query->where('member_id',$member->member_id);
        }])->find($newsFeedId);

        if (count($newsFeed->likes)){
            event(new ReceiveCancelLikeActivityEvent($newsFeed->likes[0]));
            return $this->delete($newsFeed->likes[0]->id);
        }else{
            $data['member_id'] = $member->member_id;
            if ($newsFeed->news_feed_poll_id == 0) {
                $data['likeable_id']   = $newsFeed->id;
                $data['likeable_type'] = 'content';
            } else {
                $data['likeable_id']   = $newsFeed->news_feed_poll_id;
                $data['likeable_type'] = 'poll';
            }
            $like = $this->create($data);

            event(new ReceiveLikeActivityEvent($like));

            return !!$like;
        }

    }
}