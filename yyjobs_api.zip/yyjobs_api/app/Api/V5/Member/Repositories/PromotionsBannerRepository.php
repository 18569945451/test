<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/4
 * Time: 10:09
 */
namespace App\Api\V5\Member\Repositories;


use App\Api\V5\Member\Entities\PromotionsBanner;
use Prettus\Repository\Eloquent\BaseRepository;

class PromotionsBannerRepository extends BaseRepository
{
    public function model()
    {
        return PromotionsBanner::class;
    }

    public function getBannerList(){
        return $this->model->where('status',0)
            ->select(
                'id','title','image','type','url','promotions_id'
            )
            ->orderBy('sort','asc')
            ->get();
    }

}