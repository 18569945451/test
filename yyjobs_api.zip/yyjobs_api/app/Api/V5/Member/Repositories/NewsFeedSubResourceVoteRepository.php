<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/22
 * Time: 16:00
 */

namespace App\Api\V5\Member\Repositories;

use App\Api\V5\Member\Entities\NewsFeedSubResourceVote;
use Prettus\Repository\Eloquent\BaseRepository;

class NewsFeedSubResourceVoteRepository extends BaseRepository
{
    public function model()
    {
        return NewsFeedSubResourceVote::class;
    }

    /**
     * @param $resourceId
     *
     * @return int|mixed
     */
    public function click($resourceId)
    {
        $member = auth('member')->user();
        $vote = $this->findWhere(['member_id'=>$member->member_id,'resource_id'=>$resourceId])->first();

        if (!$vote){
            return !!$this->create(['member_id'=>$member->member_id,'resource_id'=>$resourceId]);
        }
        return $this->delete($vote->id);
    }

}