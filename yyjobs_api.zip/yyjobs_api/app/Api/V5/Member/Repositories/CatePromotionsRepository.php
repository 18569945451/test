<?php
/**
 * Created by PhpStorm.
 * User: dell
 * Date: 2019/3/3
 * Time: 21:46
 */
namespace App\Api\V5\Member\Repositories;


use App\Api\V5\Member\Entities\Promotions_cate;
use Prettus\Repository\Eloquent\BaseRepository;

class catePromotionsRepository extends BaseRepository
{
    public function model()
    {
        return Promotions_cate::class;
    }

    public function get_cate(){
        return $this->model->orderBy('sort','asc')->limit(8)->get();
    }
}