<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/22
 * Time: 14:56
 */

namespace App\Api\V5\Member\Repositories;

use App\Api\V5\Member\Entities\NewsFeedSubResource;
use Illuminate\Http\File;
use Illuminate\Http\UploadedFile;
use Prettus\Repository\Eloquent\BaseRepository;

class NewsFeedSubResourceRepository extends BaseRepository
{
    public function model()
    {
        return NewsFeedSubResource::class;
    }

    /**
     * 保存资源图片
     * @param $image
     *
     * @return string
     */
    public function saveImageResource(UploadedFile $image)
    {
        //获取宽高
        list($width, $height) = getimagesize($image);

        //获取hash
        $hash = $image->hashName();

        //修改后的全名
        $joinString          = '-'.$width.'x'.$height;
        $position            = strpos($hash, '.');
        $fileNameWithWidthHeight = substr_replace($hash, $joinString, $position, 0);

        $path = $image->storeAs(substr(generateFilePath(), 0, -1),$fileNameWithWidthHeight);
        return generateFileUrl($path);
    }
}