<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 14:17
 */
namespace App\Api\V5\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class Promotions extends Model
{
    protected $table = 'promotions';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $guarded = ['_token'];

    public function users_promotions(){
        return $this->hasOne(UsersPromotions::class,'promotions_id','id');
    }

}