<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 14:17
 */
namespace App\Api\V5\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class PromotionsBanner extends Model
{
    protected $table = 'promotions_banner';
    protected $primaryKey = 'id';
    protected $guarded = ['_token'];

}