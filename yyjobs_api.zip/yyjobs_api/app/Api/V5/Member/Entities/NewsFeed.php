<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 15:47
 */

namespace App\Api\V5\Member\Entities;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NewsFeed extends Model
{
    use SoftDeletes;
    protected $table = 'news_feed';
    protected $primaryKey = 'id';
    protected $fillable = [
                'member_id',
                'admin_id',
                'news_feed_poll_id',
                'description',
                'created_at',
                'updated_at',
                'updated_micro_at',
                'deleted_at',
            ];

    public function resources()
    {
        return $this->morphMany(NewsFeedSubResource::class, 'content','resourceable_type','resourceable_id','id');
    }

    public function likes()
    {
        return $this->morphMany(NewsFeedLike::class, 'content','likeable_type','likeable_id','id');
    }

    public function comments()
    {
        return $this->morphMany(NewsFeedComment::class, 'content','commentable_type','commentable_id','id');
    }

    public function admin()
    {
        return $this->belongsTo(Admin::class,'admin_id','id');
    }

    public function member()
    {
        return $this->belongsTo(Member::class,'member_id','member_id');
    }

    public function poll()
    {
        return $this->hasOne(NewsFeedPoll::class,'id','news_feed_poll_id');
    }
}