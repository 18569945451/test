<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 16:20
 */

namespace App\Api\V5\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class NewsFeedPoll extends Model
{
    protected $table = 'news_feed_poll';
    protected $primaryKey = 'id';
    protected $fillable = [
            'admin_id',
            'type',
            'description',
            'question',
            'created_at',
            'updated_at',
            'deleted_at',
        ];

    public function resources()
    {
        return $this->morphMany(NewsFeedSubResource::class, 'poll','resourceable_type','resourceable_id','id');
    }

    public function likes()
    {
        return $this->morphMany(NewsFeedLike::class, 'poll','likeable_type','likeable_id','id');
    }

    public function comments()
    {
        return $this->morphMany(NewsFeedComment::class, 'poll','commentable_type','commentable_id','id');
    }

    public function admin()
    {
        return $this->belongsTo(Admin::class,'admin_id','id');
    }
}