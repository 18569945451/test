<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 16:16
 */

namespace App\Api\V5\Member\Entities;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NewsFeedComment extends Model
{
    use SoftDeletes;
    protected $table = 'news_feed_comment';
    protected $primaryKey = 'id';
    protected $fillable = [
                'member_id',
                'body',
                'commentable_id',
                'commentable_type',
                'created_at',
                'updated_at',
                'deleted_at'
            ];

    public function commentable()
    {
        return $this->morphTo();
    }

    public function member()
    {
        return $this->belongsTo(Member::class,'member_id','member_id');
    }
}