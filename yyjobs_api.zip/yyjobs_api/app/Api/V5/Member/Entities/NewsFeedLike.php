<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 16:15
 */

namespace App\Api\V5\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class NewsFeedLike extends Model
{
    protected $table = 'news_feed_like';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
                'member_id',
                'likeable_id',
                'likeable_type'
            ];

    public function likeable()
    {
        return $this->morphTo();
    }
}