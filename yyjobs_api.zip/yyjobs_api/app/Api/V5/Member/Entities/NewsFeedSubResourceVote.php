<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 16:18
 */

namespace App\Api\V5\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class NewsFeedSubResourceVote extends Model
{
    protected $table = 'news_feed_sub_resource_vote';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable
        = [
            'member_id',
            'resource_id',
        ];

    public function resource()
    {
        return $this->belongsTo(NewsFeedSubResource::class,'id','resource_id');
    }

    public function members()
    {
        return $this->hasMany(Member::class,'member_id','member_id');
    }

}