<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 18:25
 */
namespace App\Api\V5\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class UsersPromotions extends Model
{
    protected $table = 'users_promotions';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $guarded = ['_token'];

}