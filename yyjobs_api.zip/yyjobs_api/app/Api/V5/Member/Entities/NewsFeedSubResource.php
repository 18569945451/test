<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 16:17
 */

namespace App\Api\V5\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class NewsFeedSubResource extends Model
{
    protected $table = 'news_feed_sub_resource';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable
        = [
            'image',
            'text',
            'resourceable_id',
            'resourceable_type',
        ];

    public function resourceable()
    {
        return $this->morphTo();
    }

    public function votes()
    {
        return $this->hasMany(NewsFeedSubResourceVote::class,'resource_id','id');
    }
}