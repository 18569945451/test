<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/18
 * Time: 13:45
 */

namespace App\Api\V5\Member\Events;

use Illuminate\Queue\SerializesModels;

class LatestNewsFeedEvent
{
    use SerializesModels;

    public $timestamp;

    /**
     * LatestNewsFeedEvent constructor.
     *
     * @param int $timestamp
     */
    public function __construct(int $timestamp)
    {
        $this->timestamp = $timestamp;
    }
}
