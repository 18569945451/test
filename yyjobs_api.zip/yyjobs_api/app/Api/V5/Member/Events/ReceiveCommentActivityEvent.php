<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/25
 * Time: 16:57
 */

namespace App\Api\V5\Member\Events;

use App\Api\V5\Member\Entities\NewsFeedComment;
use Illuminate\Queue\SerializesModels;

class ReceiveCommentActivityEvent
{
    use SerializesModels;

    public $comment;

    /**
     * ReceiveCommentActivityEvent constructor.
     *
     * @param NewsFeedComment $comment
     */
    public function __construct(NewsFeedComment $comment)
    {
        $this->comment = $comment;
    }
}
