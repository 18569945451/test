<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/25
 * Time: 17:21
 */

namespace App\Api\V5\Member\Events;

use App\Api\V5\Member\Entities\NewsFeedLike;
use Illuminate\Queue\SerializesModels;

class ReceiveCancelLikeActivityEvent
{
    use SerializesModels;

    public $like;

    /**
     * ReceiveLikeActivityEvent constructor.
     *
     * @param NewsFeedLike $like
     */
    public function __construct(NewsFeedLike $like)
    {
        $this->like = $like;
    }
}
