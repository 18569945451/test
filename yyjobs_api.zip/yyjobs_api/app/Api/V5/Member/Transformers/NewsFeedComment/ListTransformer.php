<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 15:11
 */

namespace App\Api\V5\Member\Transformers\NewsFeedComment;

use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\NewsFeed $model
     *
     * @return array
     */
    public function transform($model)
    {
        return [
            'id'            => $model->id,
            'member_id'     => $model->member_id,
            'member_name'   => $model->member->member_name,
            'member_avatar' => $model->member->member_avatar,
            'body'          => $model->body,
            'created_at'    => $model->created_at->getTimestamp(),
        ];
    }
}