<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 16:47
 */
namespace App\Api\V5\Member\Transformers\Promotions;

use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\Promotions $model
     *
     * @return array
     */
    public function transform($model)
    {
        return [
            'id'             => $model->id,
            'cate_id'        => $model->cate_id,
            'title'          => $model->title,
            'summary'        => $model->summary ? $model->summary :'',
            'image'          => $model->image,
            'start_date'     => date('M d,Y',strtotime($model->start_date)),
            'end_date'       => date('M d,Y',strtotime($model->end_date)),
            'start_time'     => strtotime($model->start_date),
            'end_time'       => strtotime($model->end_date)
        ];
    }
}