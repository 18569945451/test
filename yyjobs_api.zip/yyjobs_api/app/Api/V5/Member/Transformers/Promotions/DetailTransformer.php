<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 17:19
 */
namespace App\Api\V5\Member\Transformers\Promotions;

use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class DetailTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\Promotions $model
     *
     * @return array
     */
    public function transform($model)
    {
        if(!$model){
            return array();
        }
        return [
            'id'             => $model->id,
            'title'          => $model->title,
            'summary'        => $model->summary ? $model->summary :'',
            'image_detail'   => $model->image_detail,
            'start_date'     => date('G:i M d, Y',strtotime($model->start_date)),
            'end_date'       => date('G:i M d, Y',strtotime($model->end_date)),
            'start_time'     => strtotime($model->start_date),
            'end_time'       => strtotime($model->end_date),
            'promo_code'     => $model->promo_code,
            'publish_date'   => date('M d,Y H:i a',strtotime($model->publish_date)),
            'description'    => $model->description,
            'cate_id'        => $model->cate_id,
            'had_promotions' => (isset($model->users_promotions) && $model->users_promotions) ? 1 :0
        ];
    }
}