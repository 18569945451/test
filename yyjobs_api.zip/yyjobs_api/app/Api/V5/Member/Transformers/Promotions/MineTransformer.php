<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 18:31
 */
namespace App\Api\V5\Member\Transformers\Promotions;

use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class MineTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\Promotions $model
     *
     * @return array
     */
    public function transform($model)
    {
        if(!$model){
            return array();
        }
    }
}