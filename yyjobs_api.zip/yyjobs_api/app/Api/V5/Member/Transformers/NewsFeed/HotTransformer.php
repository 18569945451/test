<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/8
 * Time: 15:38
 */

namespace App\Api\V5\Member\Transformers\NewsFeed;

use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class HotTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\NewsFeed $model
     *
     * @return array
     */
    public function transform($model)
    {
        return [
            'id'             => $model->id,
            'type'           => 'content',
            'created_at'     => $model->created_at->getTimestamp(),
            'description'    => $model->description,
            'publish_by'     => $model->member->member_name,
            'avatar'         => $model->member->member_avatar,
            'resources'      => $model->resources,
            'likes_count'    => $model->likes_count,
            'comments_count' => $model->comments_count,
            'likes'          => $model->likes,
        ];
    }
}