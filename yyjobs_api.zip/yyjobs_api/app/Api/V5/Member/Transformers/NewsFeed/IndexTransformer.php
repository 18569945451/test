<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 17:13
 */

namespace App\Api\V5\Member\Transformers\NewsFeed;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class IndexTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\NewsFeed $model
     *
     * @return array
     */
    public function transform($model)
    {
        $data = $model->news_feed_poll_id == 0
                ? $this->transformContent($model)
                : ['id'=>$model->id,'poll_id'=>$model->news_feed_poll_id];

        return $data;
    }

    public function transformContent($model)
    {
        if ($model->admin) {
            $publishBy = $model->admin->name;
            $avatar = '';
        } elseif ($model->member) {
            $publishBy = $model->member->member_name;
            $avatar = $model->member->member_avatar;
        } else {
            $publishBy = '';
            $avatar = '';
        }

        return [
            'id'             => $model->id,
            'type'           => 'content',
            'created_at'     => $model->created_at->getTimestamp(),
            'description'    => $model->description,
            'publish_by'     => $publishBy,
            'avatar'         => $avatar,
            'resources'      => $model->resources,
            'likes_count'    => $model->likes_count,
            'comments_count' => $model->comments_count,
            'likes'          => $model->likes,
        ];
    }
}