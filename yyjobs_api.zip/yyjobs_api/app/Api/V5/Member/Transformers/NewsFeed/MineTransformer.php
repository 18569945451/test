<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 14:18
 */

namespace App\Api\V5\Member\Transformers\NewsFeed;

use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class MineTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\NewsFeed $model
     *
     * @return array
     */
    public function transform($model)
    {
        return [
            'id'            => $model->id,
            //'member_id'     => $model->member_id,
            //'member_name'   => $model->member->member_name,
            //'member_avatar' => $model->member->member_avatar,
            'description'   => $model->description,
            'created_at'    => $model->created_at->getTimestamp(),
            'resources'     => $model->resources,
        ];

    }
}