<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 16:44
 */

namespace App\Api\V5\Member\Presenters\Promotions;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V5\Member\Transformers\Promotions\ListTransformer;

class ListPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new ListTransformer();
    }
}