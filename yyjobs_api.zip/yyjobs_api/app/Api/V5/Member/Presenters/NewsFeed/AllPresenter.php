<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/20
 * Time: 15:30
 */

namespace App\Api\V5\Member\Presenters\NewsFeed;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V5\Member\Transformers\NewsFeed\AllTransformer;

class AllPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new AllTransformer();
    }
}