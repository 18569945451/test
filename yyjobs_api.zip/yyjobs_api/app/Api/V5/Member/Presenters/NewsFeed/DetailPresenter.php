<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/21
 * Time: 14:42
 */

namespace App\Api\V5\Member\Presenters\NewsFeed;

use Prettus\Repository\Presenter\FractalPresenter;

class DetailPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return null;
    }

    public function present($data)
    {
        if ( ! $data) {
            return "";
        }

        return [
            'id'             => $data->id,
            'publish_id'     => $data->member ? $data->member->member_id : 0,
            'name'           => $data->member ? $data->member->member_name : $data->admin->name,
            'avatar'         => $data->member ? $data->member->member_avatar : $data->admin->avatar,
            'description'    => $data->description,
            'created_at'     => $data->created_at->getTimestamp(),
            'likes_count'    => $data->likes_count,
            'comments_count' => $data->comments_count,
            'resources'      => $data->resources,
            'likes'          => $data->likes,
        ];
    }
}