<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/3/8
 * Time: 15:38
 */

namespace App\Api\V5\Member\Presenters\NewsFeed;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V5\Member\Transformers\NewsFeed\HotTransformer;

class HotPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new HotTransformer();
    }
}