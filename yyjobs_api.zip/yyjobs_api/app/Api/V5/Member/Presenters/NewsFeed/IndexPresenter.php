<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 15:51
 */

namespace App\Api\V5\Member\Presenters\NewsFeed;

use App\Api\V5\Member\Entities\NewsFeed;
use Carbon\Carbon;
use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V5\Member\Transformers\NewsFeed\IndexTransformer;

class IndexPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new IndexTransformer();
        //return null;
    }

    public function present_bak($data)
    {
        return $data;
        $toppingIds = [];
        $newsFeeds = [];
        foreach ($data as $key => $value) {
            if ($value->admin_id == 0){
                $newsFeeds[$key]['id']             = $value->id;
                $newsFeeds[$key]['type']           = "content";
                $newsFeeds[$key]['name']           = $value->member->member_name;
                $newsFeeds[$key]['avatar']         = $value->member->member_avatar;
                $newsFeeds[$key]['created_at']     = $value->created_at->getTimestamp();
                $newsFeeds[$key]['updated_at']     = $value->updated_at->getTimestamp();
                $newsFeeds[$key]['likes_count']    = $value->likes_count;
                $newsFeeds[$key]['comments_count'] = $value->comments_count;
                $newsFeeds[$key]['images']         = $value->resources;
            }else{
                $newsFeeds[$key]['id']             = $value->id;
                $newsFeeds[$key]['type']           = "content";
                $newsFeeds[$key]['name']           = $value->admin->name;
                $newsFeeds[$key]['avatar']         = "";
                $newsFeeds[$key]['created_at']     = $value->created_at->getTimestamp();
                $newsFeeds[$key]['updated_at']     = $value->updated_at->getTimestamp();
                $newsFeeds[$key]['likes_count']    = $value->likes_count;
                $newsFeeds[$key]['comments_count'] = $value->comments_count;
                $newsFeeds[$key]['images']         = $value->resources;
            }


            /*if ($value->admin_id != 0){
                if (Carbon::parse($value->updated_at)->addDay() > Carbon::now()){
                    echo '<pre>';
                    print_r($value->toArray());
                    die;
                }else{
                    $toppingIds[] = $value->id;
                    unset($data[$key]);
                }
            }*/
        }
        sort($newsFeeds);
        return $newsFeeds;
        /*$toppingData = NewsFeed::with([
            'member'=>function($query){
                return $query->select(['member_id','member_name','member_avatar']);
            },
            'resources'
        ])->withCount('likes')
            ->withCount('comments')->whereIn('id',$toppingIds)->get();
        echo '<pre>';
        print_r($toppingData->toArray());
        die;*/

    }
}