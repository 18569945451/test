<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/26
 * Time: 17:36
 */

namespace App\Api\V5\Employer\Repositories;

use App\Api\V5\Employer\Entities\Schedule;
use App\Api\V1\Repositories\FileRepository;
use Prettus\Repository\Eloquent\BaseRepository;

class AttendanceRepository extends BaseRepository
{
    public function model()
    {
        return Schedule::class;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function processUpdate($request)
    {
        $fileRepository = new FileRepository();
        $ids = array_column($request->all()['data'],'s_id');
        $schedules = $this->model->whereIn('s_id',$ids)->get(['s_id','checkin_time','adjusted_checkin_time','checkin_signature','checkout_time','adjusted_checkout_time','checkout_signature','work_hours'])->toArray();
        $schedules = array_column($schedules,null,'s_id');

        $returnData = [];
        foreach ($request->data as $key=>$value) {
            $data = [];
            $hours        = !empty($value['hours']) ? $value['hours'] : 0;
            //签到时间
            $data['checkin_time'] = !empty($value['checkin_time']) ? $value['checkin_time'] : $schedules[$value['s_id']]['checkin_time'];
            //签出时间
            $data['checkout_time'] = !empty($value['checkout_time']) ? $value['checkout_time'] : $schedules[$value['s_id']]['checkout_time'];
            //签到图片
            $data['checkin_signature']  = !empty($value['checkin_signature']) ? $fileRepository->imageReSize($value['checkin_signature'], generateFilePath()) : $schedules[$value['s_id']]['checkin_signature'];
            //签出图片
            $data['checkout_signature'] = !empty($value['checkout_signature']) ? $fileRepository->imageReSize($value['checkout_signature'], generateFilePath()) : $schedules[$value['s_id']]['checkout_signature'];
            //修改后的签到时间
            $data['adjusted_checkin_time']  = !empty($value['adjusted_checkin_time']) ? $this->strTimeToTimestampMinutes($value['adjusted_checkin_time']) : $schedules[$value['s_id']]['adjusted_checkin_time'];
            //修改后的签出时间
            $data['adjusted_checkout_time']  = !empty($value['adjusted_checkout_time']) ? $this->strTimeToTimestampMinutes($value['adjusted_checkout_time']) : $schedules[$value['s_id']]['adjusted_checkout_time'];
            //工时
            if (!empty($data['checkin_time']) && !empty($data['checkout_time'])){
                $data['adjusted_work_minutes']  = $this->model->getWorkMinutes($data['adjusted_checkin_time'],$data['adjusted_checkout_time'],$hours) * 60;
            }
            //额外时间
            $data['extra_work_minutes']  = $hours * 60;

            $this->update($data,$value['s_id']);
            $data['s_id'] = $value['s_id'];
            $returnData[] = $data;
        }

        return $returnData;
    }

    /**
     * 将日期时间转换为不带秒数的时间戳
     * @param $dateTime
     *
     * @return false|int 整分钟
     */
    private function strTimeToTimestampMinutes($dateTime)
    {
        return strtotime(date('Y-m-d H:i', $dateTime).':00');
    }

}