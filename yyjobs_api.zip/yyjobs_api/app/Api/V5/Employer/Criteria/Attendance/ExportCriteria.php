<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/3
 * Time: 15:04
 */

namespace App\Api\V5\Employer\Criteria\Attendance;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;
use App\Api\V5\Employer\Repositories\RequisitionRepository;

class ExportCriteria implements CriteriaInterface
{
    public function apply($model,RepositoryInterface $repository)
    {
        //$requisitionRep = app(RequisitionRepository::class);
        //$employerAdminIds = $requisitionRep->getEmployerAdminIds(request('employer_admin_id'));
        $employerAdminIds = [request('employer_admin_id')];

        $date = request('date',null);
        if ($date){
            $between = [
                Carbon::parse($date)->getTimestamp(),
                Carbon::parse($date)->addDay()->getTimestamp(),
            ];
        }else{
            $between = [
                Carbon::today()->getTimestamp(),
                Carbon::tomorrow()->getTimestamp(),
            ];
        }

        return $model->join('job as j','job_schedules.job_id','j.job_id')
                     ->join('member as m','job_schedules.member_id','m.member_id')
                     ->whereIn('j.job_employer_admin_id',$employerAdminIds)
                     ->whereBetween('j.job_start_date', $between)->orderBy('j.job_start_date','ASC');
    }
}