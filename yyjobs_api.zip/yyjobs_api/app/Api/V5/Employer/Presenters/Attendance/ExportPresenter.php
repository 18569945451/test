<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/3
 * Time: 15:05
 */

namespace App\Api\V5\Employer\Presenters\Attendance;

use App\Api\V5\Employer\Entities\Schedule;
use Carbon\Carbon;
use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V5\Employer\Transformers\Attendance\TodayTransformer;

class ExportPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        //return new TodayTransformer();
        return null;
    }

    public function present($data)
    {
        $dataArray = [];
        $scheduleModel = new Schedule();
        $removes = [];
        foreach ($data as $dataKey => $dataValue) {
            $dataArray[$dataKey]['s_id']                   = $dataValue['s_id'];
            $dataArray[$dataKey]['member_id']              = $dataValue['member_id'];
            $dataArray[$dataKey]['member_name']            = $dataValue['member_name'];
            $dataArray[$dataKey]['member_nric']            = $dataValue['member_nric'];
            $dataArray[$dataKey]['member_sex']             = $dataValue['member_sex'] == 1 ? 'M' : 'F';
            $dataArray[$dataKey]['adjusted_checkin_time']  = $dataValue['adjusted_checkin_time'];
            $dataArray[$dataKey]['adjusted_checkout_time'] = $dataValue['adjusted_checkout_time'];
            $dataArray[$dataKey]['checkin_time']           = $dataValue['checkin_time'];
            $dataArray[$dataKey]['checkin_time']           = Carbon::createFromTimestamp($dataValue['checkin_time'])->format('H:i');
            $dataArray[$dataKey]['checkout_time']          = $dataValue['checkout_time'];
            $dataArray[$dataKey]['checkout_time']          = Carbon::createFromTimestamp($dataValue['checkout_time'])->format('H:i');
            $dataArray[$dataKey]['checkin_signature']      = $dataValue['checkin_signature'];
            $dataArray[$dataKey]['checkout_signature']     = $dataValue['checkout_signature'];
            if ($dataValue['adjusted_work_minutes'] == 0){
                $dataArray[$dataKey]['hours'] = 0;
                $dataArray[$dataKey]['total'] = 0;
            }else{
                $originMinutes = $scheduleModel->getWorkMinutes($dataArray[$dataKey]['adjusted_checkin_time'],$dataArray[$dataKey]['adjusted_checkout_time']) * 60;
                $dataArray[$dataKey]['total'] = round($dataValue['adjusted_work_minutes'] / 60,2);
                $dataArray[$dataKey]['hours'] = round(($dataValue['adjusted_work_minutes'] - $originMinutes) / 60 ,2);
            }
            $dataArray[$dataKey]['adjusted_checkin_time']  = Carbon::createFromTimestamp($dataValue['adjusted_checkin_time'])->format('H:i');
            $dataArray[$dataKey]['adjusted_checkout_time'] = Carbon::createFromTimestamp($dataValue['adjusted_checkout_time'])->format('H:i');
            $dataArray[$dataKey]['remark']                 = $dataValue['employer_remark'];

            //查找是否有旧数据
            if ($dataValue['parent_id'] != 0){
                $removes[] = $dataValue['parent_id'];
            }
        }

        //去除旧数据
        foreach ((array)$dataArray as $key => $value) {
            if (in_array($value['s_id'],$removes)){
                unset($dataArray[$key]);
            }
        }
        sort($dataArray);
        
        return $dataArray;
    }
}