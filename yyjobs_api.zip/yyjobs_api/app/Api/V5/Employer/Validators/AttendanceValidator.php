<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 16:45
 */

namespace App\Api\V5\Employer\Validators;

use Illuminate\Support\MessageBag;
use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;

class AttendanceValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'attendanceList' => [
                'employer_admin_id' => 'required|integer|min:1',
            ],
            'update'         => [
                'employer_admin_id'             => 'required|integer|min:1',
                'data'                          => 'required|array',
                'data.*.s_id'                   => 'required|integer|min:1',
                'data.*.checkin_time'           => 'integer|min:0',
                'data.*.checkout_time'          => 'integer|min:0',
                'data.*.adjusted_checkin_time'  => 'integer|min:0',
                'data.*.adjusted_checkout_time' => 'integer|min:0',
                'data.*.checkin_signature'      => 'image|between:0,255',
                'data.*.checkout_signature'     => 'image|between:0,255',
                'data.*.hours'                  => 'required|numeric',
                'data.*.remark'                 => 'string|between:0,255',
            ],
            'add'            => [
                'employer_admin_id' => 'required|integer|min:1',
                'member_id'         => 'required|integer|min:1',
                'job_id'            => 'required|integer|min:1',
            ],
            'confirm'        => [
                'date'                => 'required|date|before:tomorrow',
                'confirm_signature'   => 'required|image|between:0,255',
                'employer_admin_id'   => 'required|array',
                'employer_admin_id.*' => 'required|integer|min:1',
            ],
            'revise'         => [
                'employer_admin_id'             => 'required|integer|min:1',
                'confirm_signature'             => 'required|image|between:0,255',
                'data'                          => 'array',
                'data.*.s_id'                   => 'integer|min:1',
                'data.*.checkin_time'           => 'integer|min:0',
                'data.*.checkout_time'          => 'integer|min:0',
                'data.*.adjusted_checkin_time'  => 'integer|min:0',
                'data.*.adjusted_checkout_time' => 'integer|min:0',
                'data.*.hours'                  => 'numeric',
            ],
            'remark'         => [
                'employer_admin_id' => 'required|integer|min:1',
                's_id'              => 'required|integer|min:1',
                'remark'            => 'sometimes|string|max:255',
            ],
            'export'         => [
                'employer_admin_id' => 'required|integer|min:1',
                'date'              => 'required|date',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    public function validPermission($action = '')
    {
        $user = auth('employer')->user();
        if ($user->parent_id != 0 && $user->id != request('employer_admin_id')) {
            throw new ValidatorException(new MessageBag(['You are not eligible for data']));
        }
        if ($action == 'add') {
            $res = \DB::table('job_schedules')->where('member_id', request('member_id'))->where('job_id', request('job_id'))->count();
            if ($res) {
                throw new ValidatorException(new MessageBag(['Cannot add employees repeatedly']));
            }
        }
    }

    public function validPermissionForConfirm()
    {
        $user     = auth('employer')->user();
        $adminIds = request('employer_admin_id');

        foreach ($adminIds as $adminId) {
            if ($user->parent_id != 0 && $user->id != $adminId) {
                throw new ValidatorException(new MessageBag(['You are not eligible to confirm this data']));
            }
        }
    }

}