<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/26
 * Time: 17:29
 */

namespace App\Api\V5\Employer\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V5\Employer\Validators\AttendanceValidator;
use App\Api\V5\Employer\Repositories\AttendanceRepository;

class AttendanceController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(AttendanceRepository $repository, AttendanceValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/attendance/update",
     *   tags={"employer/attendance"},
     *   summary="attendance update",
     *   description="attendance update",
     *   operationId="attendance update",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="employer_admin_id",type="string",  description="账号ID", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][s_id]",type="integer",  description="记录ID", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][remark]",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][remark]",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v5+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function update(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('update');
            $this->validator->validPermission();
            $data = $this->repository->processUpdate($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

}