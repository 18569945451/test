<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/9/2
 * Time: 9:52
 */

namespace App\Api\V7\Employer\Controllers;

use App\Api\V7\Employer\Requests\Auth\RegisterRequest;
use App\Api\V7\Employer\Services\RegisterService;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class AuthController extends Controller
{
    /**
     * @SWG\Post(path="/index.php/api/employer/auth/register",
     *   tags={"auth"},
     *   summary="注册",
     *   description="注册",
     *   operationId="register",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="logo",type="file",  description="logo", required=true),
     *   @SWG\Parameter(in="formData",  name="name",type="string",  description="名称", required=true),
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=true),
     *   @SWG\Parameter(in="formData",  name="contact_person",type="string",  description="联系人", required=false),
     *   @SWG\Parameter(in="formData",  name="contact_no",type="string",  description="联系号码", required=true),
     *   @SWG\Parameter(in="formData",  name="uen_no",type="string",  description="uen号码", required=false),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="formData",  name="password_confirmation",type="string",  description="确认密码", required=true),
     *   @SWG\Parameter(in="formData",  name="company_description",type="string",  description="公司描述", required=false),
     *   @SWG\Parameter(in="formData",  name="industry_id",type="string",  description="行业id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v7+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function register(RegisterRequest $request)
    {
        try {
            $data = (new RegisterService())->register($request);
            return response(['status'=>'success','code'=>200,'message'=>null,'data'=>$data],200);
        } catch (ValidatorException $e) {
            return response(['status'=>'error','code'=>403,'message'=>$e->getMessageBag()->first()],200);
        }
    }
}