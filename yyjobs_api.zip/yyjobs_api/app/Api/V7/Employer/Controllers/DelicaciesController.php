<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/9/2
 * Time: 9:52
 */

namespace App\Api\V7\Employer\Controllers;

use App\Api\V7\Employer\Requests\Auth\DelicaciesRequest;
use App\Api\V7\Employer\Services\DelicaciesService;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class DelicaciesController extends Controller
{
    /**
     * @SWG\Post(path="/index.php/api/employer/auth/register",
     *   tags={"auth"},
     *   summary="注册",
     *   description="注册",
     *   operationId="register",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="file",type="file",  description="产品图片", required=true),
     *   @SWG\Parameter(in="formData",  name="name",type="string",  description="名称", required=true),
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=true),
     *   @SWG\Parameter(in="formData",  name="contact_person",type="string",  description="联系人", required=true),
     *   @SWG\Parameter(in="formData",  name="contact_no",type="string",  description="联系号码", required=true),
     *   @SWG\Parameter(in="formData",  name="uen_no",type="string",  description="uen号码", required=false),
     *   @SWG\Parameter(in="formData",  name="address",type="string",  description="地址", required=true),
     *   @SWG\Parameter(in="formData",  name="average",type="string",  description="平均价格", required=true),
     *   @SWG\Parameter(in="formData",  name="MF_operation",type="string",  description="周一到周五工作时间", required=true),
     *   @SWG\Parameter(in="formData",  name="SS_operation",type="string",  description="周六到周日工作时间", required=true),
     *   @SWG\Parameter(in="formData",  name="brand",type="string",  description="关于品牌", required=true),
     *   @SWG\Parameter(in="formData",  name="industry_id",type="string",  description="行业id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v7+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */

    //注册
    public function register(DelicaciesRequest $request)
    {
        try {

            $data = (new DelicaciesService())->register($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {

            return response(['status'=>'error','code'=>403,'message'=>$e->getMessageBag()->first()],403);
        }
    }

    //下拉框数据
    public function delicacies()
    {
            $data['data'] = (new DelicaciesService())->delicacies();

            return $data;
    }
}