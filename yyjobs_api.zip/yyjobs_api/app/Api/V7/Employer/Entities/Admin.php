<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/9/2
 * Time: 9:58
 */
namespace App\Api\V7\Employer\Entities;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    protected $table = 'admins';

    protected $primaryKey = 'id';

    protected $hidden = [];

    protected $fillable = ['name', 'email', 'password', 'remember_token', 'created_at', 'updated_at', 'type', 'has_employer', 'registration_id','status'];

    public function employer()
    {
        return $this->hasOne(Employer::class,'e_admin_id','id');
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class,'role_admin','user_id','role_id');
    }
}
