<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/9/2
 * Time: 9:58
 */
namespace App\Api\V7\Employer\Entities;

use Illuminate\Database\Eloquent\Model;

class Employer extends Model
{
    protected $table = 'employer';

    protected $primaryKey = 'e_id';

    protected $fillable = ['e_admin_id', 'e_recruiter_id', 'e_company_name', 'e_company_logo', 'e_email', 'e_company_description', 'e_contact_person', 'e_contact_no', 'e_uen_no', 'e_hourly_rate', 'e_hourly_rate_working', 'e_hourly_rate_weekend', 'e_industry_id', 'e_status', 'e_add_time', 'e_gst',];

    public $timestamps = false;

    public function admin()
    {
        return $this->belongsTo(Admin::class,'id','e_admin_id');
    }
}
