<?php
/**
 * Created by PhpStorm.
 * User: wn
 * Date: 2019/9/9
 * Time: 9:58
 */
namespace App\Api\V7\Employer\Entities;

use App\Api\V7\Employer\Services\DelicaciesService;
use Illuminate\Database\Eloquent\Model;

class DelicaciesMerchants extends Model
{
    protected $table = 'delicacies_merchants';

    protected $primaryKey = 'id';

    protected $hidden = [];

    protected $fillable = ['name', 'uen_no', 'email', 'contact_person', 'contact_number', 'address', 'avg_expense_per_pax', 'operation_hours_1', 'operation_hours_2', 'about', 'images', 'category', 'created_at', 'updated_at',];

    public static $data = [

        ['industry_id'=>'0','industry_name'=>'Alcohol'],
        ['industry_id'=>'1','industry_name'=>'Asian'],
        ['industry_id'=>'2','industry_name'=>'Bakery & Cake'],
        ['industry_id'=>'3','industry_name'=>'Beverages'],
        ['industry_id'=>'4','industry_name'=>'Breakfast & Brunch'],
        ['industry_id'=>'5','industry_name'=>'Bubble Tea'],
        ['industry_id'=>'6','industry_name'=>'Burges'],
        ['industry_id'=>'7','industry_name'=>'Chiken'],
        ['industry_id'=>'8','industry_name'=>'Chinese'],
        ['industry_id'=>'9','industry_name'=>'Coffee & Tea'],
        ['industry_id'=>'10','industry_name'=>'Dessert'],
        ['industry_id'=>'11','industry_name'=>'Durian'],
        ['industry_id'=>'12','industry_name'=>'Fast Food'],
        ['industry_id'=>'13','industry_name'=>'Halal'],
        ['industry_id'=>'14','industry_name'=>'Hot Pot'],
        ['industry_id'=>'15','industry_name'=>'Ice Cream'],
        ['industry_id'=>'16','industry_name'=>'Indian'],
        ['industry_id'=>'17','industry_name'=>'Italian'],
        ['industry_id'=>'18','industry_name'=>'Japanese'],
        ['industry_id'=>'19','industry_name'=>'Koran'],
        ['industry_id'=>'20','industry_name'=>'Local'],
        ['industry_id'=>'21','industry_name'=>'Mexican'],
        ['industry_id'=>'22','industry_name'=>'Nasi Lemak'],
        ['industry_id'=>'23','industry_name'=>'Noodles'],
        ['industry_id'=>'24','industry_name'=>'Pasta'],
        ['industry_id'=>'25','industry_name'=>'Pizza'],
        ['industry_id'=>'26','industry_name'=>'Ramen'],
        ['industry_id'=>'27','industry_name'=>'Salad'],
        ['industry_id'=>'28','industry_name'=>'Seafood'],
        ['industry_id'=>'29','industry_name'=>'Small Bites / Snacks'],
        ['industry_id'=>'30','industry_name'=>'Snacks','Soup'],
        ['industry_id'=>'31','industry_name'=>'Suchi'],
        ['industry_id'=>'32','industry_name'=>'Tea'],
        ['industry_id'=>'33','industry_name'=>'Thai'],
        ['industry_id'=>'34','industry_name'=>'Vegetarian Friendly'],
        ['industry_id'=>'35','industry_name'=>'Vietnamese'],
        ['industry_id'=>'36','industry_name'=>'Western']
    ];

}
