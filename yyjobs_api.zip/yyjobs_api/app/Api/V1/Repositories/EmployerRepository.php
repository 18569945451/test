<?php
namespace App\Api\V1\Repositories;

use App\Models\Employer;
use Prettus\Repository\Eloquent\BaseRepository;

class EmployerRepository extends BaseRepository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return Employer::class;
    }

    public function search($curPage, $pageSize)
    {
        $offset = ($curPage - 1) * $pageSize;

        $this->model = $this->model->where('e_status','1');

        //总数
        $count = $this->model->count();

        //总页数
        $countPage = ceil($count / $pageSize);

        //数据
        $result = $this->model->offset($offset)->limit($pageSize)->orderBy('e_id','desc')->get(['e_admin_id','e_company_name'])->toArray();

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'result'),
        ];
    }
}