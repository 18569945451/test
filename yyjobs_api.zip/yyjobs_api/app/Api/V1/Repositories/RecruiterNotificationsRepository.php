<?php


namespace App\Api\V1\Repositories;

use App\Traits\Admin\Jpush;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Models\Employer;
use App\Models\RecruiterNotifications;
use Carbon\Carbon;
class RecruiterNotificationsRepository extends BaseRepository
{
    use Jpush;

    public function model()
    {
        return RecruiterNotifications::class;
    }

    public function saveFullNotificationToRecruiter($recruiterId, $job)
    {
        $employer         = (new Employer())->where('e_admin_id', $job->job_employer_admin_id)->value('e_company_name');
        $jobDate          = Carbon::createFromTimestamp($job->job_start_date)->format('Y-m-d');
        $type             = 'fully_applied'; //工作通知
        $content          = "The job on {$jobDate} at {$employer} is fully applied by the staffs. Please click to check the details";

        $this->model->insert(array(
            'type'      => $type,
            'admin_id'  => $recruiterId,
            'title'     => 'Your posting job is fully applied.',
            'content'   => $content,
            'time'      => time(),
            'job_id'    => $job->job_id,
            'data'      => json_encode(['job_id'=>$job->job_id])
        ));
        return [
            'content' => $content,
            'data'    => ['msg_type' => $type,'job_id'=>$job->job_id],
        ];
    }

}