<?php

namespace App\Api\V1\Repositories;

use App\Api\V2\Repositories\MemberNotificationsRepository;
use App\Models\Admin;
use App\Models\JobSchedules;
use App\Traits\Admin\Jpush;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V1\Repositories\RecruiterNotificationsRepository;
class JobSchedulesRepository extends BaseRepository
{
    use Jpush;
    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return JobSchedules::class;
    }

    /**
     * 申请工作
     * @param $member
     * @param $jobId
     *
     * @return array
     */
    public function apply($member,$jobId)
    {
        $jobRep = app(JobRepository::class);
        $job = $jobRep->find($jobId);
        $memberInfoRep = app(EmployeeInfoRepository::class);
        $memberInfo = $memberInfoRep->getInfo($member->toArray());
        if ($jobValid = $this->validJob($job,$memberInfo)){
            if ($jobValid['error'] == 1){
                return $jobValid;
            }
        }
        $schedules = $this->createSchedules($job,$memberInfo);

        $this->fullApplyNotification($job);

        return ['error'=>0,'data'=>$schedules,'msg'=>'Successful application'];

    }

    /**
     * 验证是否可以申请
     * @param $job
     * @param $memberInfo
     *
     * @return array
     */
    public function validJob($job,$memberInfo)
    {
        $employerAdmin = Admin::find($job->job_employer_admin_id);
        if ($employerAdmin->under_hy == 1){
            //是否申请过
            if ($this->findWhere(['member_id'=>$memberInfo['member_id'],'job_id'=>$job->job_id])->first()){
                return ['error'=>1,'msg'=>'You have applied for this job and cannot apply repeatedly.'];
            }

            //个人状态是否可以申请
            if ($memberInfo['member_status'] != 3){
                return ['error'=>1,'msg'=>'Your account status is pending or blocked!'];
            }
        }

        //工作是否可以申请
        if ($job->job_status != 4){
            return ['error'=>1,'msg'=>'This job is currently unavailable!'];
        }

        //工作是否过期
        if ($job->job_start_date <= (time()-3600 * 2)){
            return ['error'=>1,'msg'=>'Work has started for two hour, please apply for other work!'];
        }

        //工作是否过期
        if ($job->job_end_date <= time()){
            return ['error'=>1,'msg'=>'The job has already expired!'];
        }

        $startDate = $job->job_start_date;
        $endDate = $job->job_end_date;

        //是否有时间相冲突的工作
        if ($this->hasConflict($memberInfo['member_id'],$startDate,$endDate)){
            return ['error'=>1,'msg'=>'You have a schedule that overlaps with this job start date or end date!'];
        }

        //是否填写用户详细信息
        if(!isset($memberInfo['info_id'])){
            return ['error'=>1,'msg'=>'Your info setting doesn\'t meet the job requirement. Please go back to try other jobs.'];
        }

        $age = $this->getMemberAge($memberInfo['member_birthday']);

        //年龄是否符合要求
        if (!$this->validAge($age,$job->job_people_age)){
            return ['error'=>1,'msg'=>'Age does not meet requirements.'];
        }

        //性别是否符合要求
        if ($job->job_people_sex != 0 && $job->job_people_sex != $memberInfo['member_sex']){
            return ['error'=>1,'msg'=>'Sex does not meet requirements'];
        }

        //国籍是否符合要求
        if ($job->job_people_nationality != '' && $job->job_people_nationality != $memberInfo['info_nationality']){
            return ['error'=>1,'msg'=>'Nationality does not meet requirements'];
        }

        //语言是否符合要求
        $lang = $this->validLanguage($job->job_people_language,$memberInfo['info_language']);

        if (!$lang){
            return ['error'=>1,'msg'=>'Language does not meet requirements'];
        }

        //工作是否申请满了
        $applyNum = $this->getJobApplyNum($job->job_id);
        if ($applyNum >= $job->job_need_people_count){
            return ['error'=>1,'msg'=>'This job has already fully applied. Please check other jobs.'];
        }

        return ['error'=>0];
    }

    /**
     * 是否有时间相冲突的工作
     * @param $memberId
     * @param $startDate
     * @param $endDate
     *
     * @return mixed
     */
    public function hasConflict($memberId,$startDate,$endDate)
    {
        return $this->model->leftJoin('job as j','job_schedules.job_id','j.job_id')
            ->where('job_schedules.member_id',$memberId)
            ->where(function ($query)use ($startDate,$endDate){
                $query->where(function ($query) use ($startDate) {
                    $query->where('j.job_start_date', '<=', $startDate);
                    $query->where('j.job_end_date', '>=', $startDate);
                });
                $query->orWhere(function ($query) use ($endDate){
                    $query->where('j.job_start_date', '<=', $endDate);
                    $query->where('j.job_end_date', '>=', $endDate);
                });
            })
            ->whereIn('job_schedules.work_status',['1','2'])
            ->first();
    }

    /**
     * 根据时间戳获取年龄
     * @param $time
     *
     * @return float
     */
    public function getMemberAge($time)
    {
        return (time() - $time) / 60 / 60 / 24 / 365;
    }

    /**
     * 语言是否符合
     * @param $jobLang
     * @param $memberLang
     * @param $type
     * @return bool
     */
    public function validLanguage($jobLang, $memberLang, $type = 'or')
    {
        if ($jobLang == '') {
            return true;
        }
        if ($jobLang != '' && $memberLang == '') {
            return false;
        }

        $jobLanguage    = explode(',', $jobLang);
        $memberLanguage = explode(',', $memberLang);

        if ($type == 'or') {
            foreach ($memberLanguage as $lang) {
                if (in_array($lang, $jobLanguage)) {
                    return true;
                }
            }

            return false;
        }

        if ($type == 'and') {
            if (array_diff($jobLanguage, $memberLanguage)) {
                return false;
            }

            return true;
        }
    }

    /**
     * @param $age
     * @param $ageRand
     *
     * @return bool
     */
    private function validAge($age, $ageRand)
    {
        if (!$ageRand){
            return true;
        }
        $ageRandArr = explode(',',$ageRand);
        $ageArr = [];
        foreach ($ageRandArr as $key=>$value) {
            $valueSplitArray = $value == '50+' ? ['51','70'] : explode('-',$value);
            for ($i=$valueSplitArray[0];$i<=$valueSplitArray[1];$i++){
                $ageArr[] = $i;
            }
        }

        return in_array(intval($age),$ageArr);
    }

    /**
     * 工作申请了多少人
     * @param $jobId
     *
     * @return mixed
     */
    public function getJobApplyNum($jobId)
    {
        //工作状态（1：Pending信用低于70的时候申请的，
        //2：Applied申请成功，
        //3：Rejected Request管理员拒绝，
        //4：Auto Cancelled未签到或到时未签出自动取消，
        //5：Complete成功签出待审批，
        //6：Payment Pending待支付，
        //7：Rejected不认可该工作，
        //8：Payment Processed支付完成）
        return $this->model->where('job_id',$jobId)->whereIn('work_status',[1,2,4,5,6,7,8,11,12])->count();
    }

    /**
     * 插入数据
     * @param $job
     * @param $member
     *
     * @return mixed
     */
    public function createSchedules($job,$member)
    {
        $schedules['member_id'] = $member['member_id'];
        $schedules['member_name'] = $member['member_name'];
        $schedules['job_id'] = $job->job_id;
        $schedules['is_assigned'] = 0;
        $schedules['cancel_status'] = 0;
        $schedules['cancel_reason'] = '';
        $schedules['cancel_image'] = '';
        $schedules['checkin_time'] = 0;
        $schedules['adjusted_checkin_time'] = $job->job_start_date;
        $schedules['checkin_address'] = '';
        $schedules['checkout_time'] = 0;
        $schedules['adjusted_checkout_time'] = $job->job_end_date;
        $schedules['checkout_address'] = '';
        $schedules['work_hours'] = 0.00;
        $schedules['adjusted_hourly_rate'] = 0.00;
        $schedules['job_salary'] = 0.00;
        $schedules['process_date'] = 0;
        $schedules['payment_methods'] = '';
        $schedules['add_time'] = time();
        $schedules['member_current_lat'] = '';
        $schedules['member_current_long'] = '';
        $schedules['work_status'] = $member['member_credit'] < 70 ? 1 : 2;
        $schedules['source'] = 1;

        //notify 申请工作时credits低于70分发送通知
        if ($member['member_credit'] < 70){
            $notifyRep = app(MemberNotificationsRepository::class);
            $data = $notifyRep->saveNotifyApplyJobForCreditsLow($member['member_id'],$job->job_id);
            if ($member['registration_id']){
                $this->notifyApplyJobForCreditsLow($data,[$member['registration_id']]);
            }
        }


        return $this->create($schedules);
    }

    public function search($curPage, $pageSize, $memberId,$industryId,$employerId)
    {
        $offset = ($curPage - 1) * $pageSize;

        $this->model = $this->model->join('job as j','job_schedules.job_id','j.job_id')
                                   ->leftJoin('employer as e','j.job_employer_admin_id','e.e_admin_id');

        //只显示待审批 与 申请成功的
        $this->model = $this->model
            ->where(function ($query){
                $query->whereIn('job_schedules.work_status',['1','2'])->where('job_schedules.is_assigned', 0)
                    ->orWhere([['job_schedules.work_status', 2], ['job_schedules.is_assigned', 1]]);
            });

        //条件：雇员
        if ($memberId){
            $this->model = $this->model->where('job_schedules.member_id',$memberId);
        }

        //条件：行业
        if ($industryId){
            $this->model = $this->model->whereIn('j.job_industry_id',$industryId);
        }

        //条件：雇主
        if ($employerId){
            $this->model = $this->model->whereIn('j.job_employer_admin_id',$employerId);
        }

        $count = $this->model->count();

        $countPage = ceil($count / $pageSize);

        $result = $this->model->offset($offset)->limit($pageSize)->orderBy('job_schedules.job_id','desc')->get(['job_schedules.*','j.*','e.e_company_logo as employer_logo'])->toArray();

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'result'),
        ];
    }

    public function detail($memberId)
    {
        $job = $this->model->leftJoin('job as j','job_schedules.job_id','j.job_id')
            ->where('job_schedules.member_id',$memberId)
            ->where('job_schedules.work_status',2)
            //->where('j.job_end_date','>',time())
            ->where('j.job_status',4)
            ->orderBy('j.job_end_date','asc')
            ->first();
        if (!$job){
            $job = $this->model->leftJoin('job as j','job_schedules.job_id','j.job_id')
                ->where('job_schedules.member_id',$memberId)
                ->where('job_schedules.work_status',2)
                ->where('job_schedules.checkin_time','>',0)
                ->where('job_schedules.checkout_time','=',0)
                ->orderBy('j.job_end_date','asc')
                ->first();
        }

        if ($job){
            return ['error'=>0,'data'=>$job->toArray(),'msg'=>''];
        }
        return ['error'=>1,'msg'=>'No related work'];
    }

    public function cancel($request,$memberId,$jobId)
    {
        $schedules = $this->findWhere(['job_id'=>$jobId,'member_id'=>$memberId])->first();

        if($schedules->cancel_status == 1){
            return ['error'=>1,'msg'=>"This job has been cancelled and cannot be canceled repeatedly"];
        }

        if($schedules->is_send == 1){
            return ['error'=>1,'msg'=>"Your work plan has been confirmed by the administrator and cannot be cancelled"];
            //return ['error'=>1,'msg'=>"Can't cancel because your work plan has been confirmed by the administrator"];
        }

        $settingRep = app(SettingRepository::class);
        $setting = $settingRep->first();
        
        $cancelHour = (time() - $schedules->add_time) / 3600;

        $deduction = 0;
        if ($cancelHour >= 72){
            $deduction = $setting->credits_cancel_job_before_72_hours;
        }
        if ($cancelHour < 72 && $cancelHour > 0){
            $deduction = $setting->credits_cancel_job_within_72_hours;
        }

        $scheduleData['cancel_status'] = 1;
        $scheduleData['cancel_reason'] = $request->input('reason');


        $fileRepository = app(FileRepository::class);
        if ($request->file('file')){
            $scheduleData['cancel_image'] = $fileRepository->imageReSize( request()->file('file'),generateFilePath());
        }

        $scheduleData['work_status'] = 9;
        $scheduleData['cancel_time'] = time();

        $this->update($scheduleData,$schedules->s_id);

        \DB::table('member')->where('member_id',$memberId)->increment('member_credit',$deduction);

        return ['error'=>0,'data'=>true,'msg'=>"Work cancelled, {$deduction} credit points deducted"];
    }

    /**
     * 签入
     * @param $memberId
     * @param $schedulesId
     * @param $latitude
     * @param $longitude
     * @param $address
     *
     * @return array
     */
    public function checkin($memberId, $schedulesId, $latitude, $longitude,$address)
    {
        $schedules = $this->find($schedulesId);
        $jobRep = app(JobRepository::class);
        $job = $jobRep->find($schedules->job_id);

        //是否本人
        if ($memberId != $schedules->member_id){
            return ['error'=>1,'msg'=>'Illegal request.'];
        }

        //工作是否可以申请
        if ($job->job_status != 4){
            return ['error'=>1,'msg'=>'This job is currently unavailable!'];
        }

        //是否申请成功
        if ($schedules->work_status != 2){
            return ['error'=>1,'msg'=>'Please apply for the job and try again.'];
        }


        $schedulesData['member_current_lat'] = $latitude;
        $schedulesData['member_current_long'] = $longitude;
        //没有签入过就更新用户签入数据
        if ($schedules->checkin_time == 0){
            $interval = $job->job_start_date - time();
            
            if ($interval / 3600 > 1) {
                return ['error'=>1,'msg'=>'You can only check in an hour before the start of your job.'];
            }
            
            //是不是在范围内
            if ($this->distance($job->job_latitude,$job->job_longitude,$latitude,$longitude) > 500){
                return ['error'=>1,'msg'=>'You are not currently within the scope of your work.'];
            }

            $schedulesData['checkin_time'] = time();
            $schedulesData['checkin_address'] = $address;
        }
        
        $res = $this->update($schedulesData,$schedulesId);
        if ($res){
            return ['error'=>0,'data'=>$res];
        }
        return ['error'=>1,'msg'=>'Check in failed'];
    }

    /**
     * 签出
     * @param $member
     * @param $schedulesId
     * @param $latitude
     * @param $longitude
     * @param $address
     *
     * @return array
     */
    public function checkout($member, $schedulesId, $latitude, $longitude,$address)
    {
        $schedules = $this->find($schedulesId);
        $jobRep    = app(JobRepository::class);
        $job       = $jobRep->find($schedules->job_id);

        //是否本人
        if ($member->member_id != $schedules->member_id){
            return ['error'=>1,'msg'=>'Illegal request.'];
        }

        //工作是否可以申请
        if ($job->job_status != 4){
            return ['error'=>1,'msg'=>'This job is currently unavailable!'];
        }

        //是否已经签入
        if ($schedules->checkin_time == 0){
            return ['error'=>1,'msg'=>'You have not checked in yet.'];
        }

        $schedulesData['member_current_lat'] = $latitude;
        $schedulesData['member_current_long'] = $longitude;
        $schedulesData['checkout_time'] = time();
        $schedulesData['checkout_address'] = $address;
        $schedulesData['work_hours'] = $this->getWorkHours($job,$schedules);

        $schedulesData['job_salary'] = $schedulesData['work_hours'] / 60 * $member->member_salary_rate;
        $schedulesData['work_status'] = 5;

        $res = $this->update($schedulesData,$schedulesId);
        if ($res){
            return ['error'=>0,'data'=>$res];
        }

        return ['error' => 1, 'msg' => 'Check out failed'];
    }

    private function getWorkHours($job,$schedules)
    {
        $now   = time();
        $start = ($schedules->checkin_time > $job->job_start_date) ? $schedules->checkin_time : $job->job_start_date;
        $end   = ($now > $job->job_end_date) ? $job->job_end_date : $now;
        if ($end > $start){
            return ($end - $start) / 60;
        }
        return 0;
    }

    public function reject($memberId, $jobId)
    {
        $res = $this->model->where('job_id',$jobId)->where('member_id',$memberId)->update(['work_status'=>10]);
        if ($res){
            $data = $this->model->where('job_id',$jobId)->where('member_id',$memberId)->first();
            return ['error'=>0,'data'=>$data];
        }

        return ['error' => 1, 'msg' => 'Reject failed'];
    }

    public function accept($memberId, $jobId)
    {
        $jobRep = app(JobRepository::class);
        $job = $jobRep->find($jobId);
        if ($hasConflict = $this->hasConflict($memberId,$job->job_start_date,$job->job_end_date)){
            if ($hasConflict->job_id != $jobId){
                return ['error'=>1,'msg'=>'You have a schedule that overlaps with this job start date or end date!'];
            }
        }
        
        $res = $this->model->where('job_id',$jobId)->where('member_id',$memberId)->update(['work_status'=>2]);
        if ($res){
            $data = $this->model->where('job_id',$jobId)->where('member_id',$memberId)->first();
            return ['error'=>0,'data'=>$data];
        }

        return ['error' => 1, 'msg' => 'Accept failed'];
    }

    public function distance($lat1, $long1, $lat2, $long2)
    {
        return intval(6378.138 * 2 * asin(
                sqrt(
                    cos($lat1 * 3.1415926 / 180) * cos($lat2 * 3.1415926 / 180) * pow(sin(($long1 * 3.1415926 / 180 - $long2 * 3.1415926 / 180) / 2), 2)
                    + pow(sin(($lat1 * 3.1415926 / 180 - $lat2 * 3.1415926 / 180) / 2), 2)
                )
            ));
    }


    /**
     * @param $job
     * 即将满员的整体通知
     * @return void|null
     */
    public function fullApplyNotification($job)
    {
        $jobNeedNum    = $job->job_need_people_count;

        $applyNum = $this->getJobApplyNum($job->job_id);

        if($jobNeedNum != $applyNum){
            return;
        }

        $recruiterData = $this->getRecruiterData($job->job_recruiter_admin_id);

        $data = app(RecruiterNotificationsRepository::class)->saveFullNotificationToRecruiter($recruiterData->id, $job);
        if($recruiterData->registration_id){
            $this->notifyFullyAppliedToRecruiter($data, $recruiterData->registration_id);
        }
        return null;
    }


    /**
     * @param $jobID
     * 获取recruiter的信息
     * @return mixed
     */
    public function getRecruiterData($recruiterID)
    {
        return Admin::find($recruiterID);
    }
}