<?php

namespace App\Api\V1\Repositories;

use App\Api\V1\Services\TimApi;
use App\Traits\Admin\Jpush;
use Hash;
use Validator;
use App\Models\Member;
use Prettus\Repository\Eloquent\BaseRepository;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
class EmployeeRepository extends BaseRepository
{

    use Jpush;
    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return Member::class;
    }

    public function validateMember($request)
    {
        $data['member_name'] = $request['name'];
        $data['member_email'] = isset($request['email']) ? $request['email'] : '';
        $data['member_nric'] =   $request['nric_no'];
        $data['member_mobile'] = $request['mobile_no'];
        return Validator::make(
            $data,
            [
             'member_email'     => 'unique:member',
             'member_nric'   => 'unique:member',
             'member_mobile' => 'unique:member',
            ]
        );
    }

    /**
     * 手机号注册
     * @param $request
     *
     * @return array
     */
    public function registerForMobile($request)
    {
        $validator = $this->validate($request);
        if ($validator->fails()) {
            return ['error' => 1, 'msg' => 'Invalid Data'];
        }
        if ($this->isExist($request)) {
            return ['error' => 1, 'msg' => 'It\'s Exist' ,'code'=>402];
        }

        $data = [
            'member_name'      => $request['name'],
            'member_password'  => bcrypt($request['password']),
            'member_email'     => $request['email'] ?? '',
            'member_nric'      => $request['nric_no'],
            'member_mobile'    => $request['mobile_no'],
            'member_school_id' => $request['school'],
            'member_add_time'  => time(),
        ];

        if ($res = $this->create($data)) {
            $token = auth('member')->attempt(['member_id' => $res->member_id]);

            //更新设备id
            $this->updateMemberRegistration($request['registration_id'],$res->member_id);

            //notify 发送注册成功通知
            if ($request['registration_id']){
                $this->register($res,$request['registration_id']);
            }
            $identifier = 'm'.$res->member_id;
            return [
                'error' => 0,
                'data'  => [
                    'member_id'  => $res->member_id,
                    'token'      => $token,
                    'signature'  => $this->getSignature($identifier),
                    'identifier' => $identifier,
                ],
                'msg'   => 'Registration Success!',
            ];
        }

        return ['error' => 1, 'msg' => 'Invalid Data'];

    }

    /**
     * 脸书注册
     * @param $request
     *
     * @return array
     */
    public function registerForFacebook($request)
    {
        $validator = $this->validate($request);
        if ($validator->fails()) {
            return ['error' => 1, 'msg' => 'Invalid Data'];
        }
        if ($this->isExist($request)) {
            return ['error' => 1, 'msg' => 'It\'s Exist' ,'code'=>402];
        }

        $fbUser = $this->getFacebookUser($request['social_access_token']);

        if (!empty($request['social_fb_id']) && $fbUser['status_code'] == 200) {
            $userData = [
                'member_name'      => $request['name'],
                'member_email'     => $request['email'] ?? '',
                'member_nric'      => $request['nric_no'],
                'member_mobile'    => $request['mobile_no'],
                'member_school_id' => $request['school'],
                'social_access_token' => bcrypt($request['social_access_token']),
                'social_fb_id'     => $request['social_fb_id'],
                'member_platform'  => $request['platform'],
                'member_add_time'  => time(),
            ];
            if ($res = $this->create($userData)) {
                $token = auth('member')->attempt(['member_id' => $res->member_id]);

                //更新设备id
                $this->updateMemberRegistration($request['registration_id'],$res->member_id);

                $identifier = 'm'.$res->member_id;
                return [
                    'error' => 0,
                    'data'  => [
                        'member_id'  => $res->member_id,
                        'token'      => $token,
                        'signature'  => $this->getSignature($identifier),
                        'identifier' => $identifier,
                    ],
                    'msg'   => 'Registration Success!',
                ];
            }

            return ['error' => 1, 'msg' => 'Invalid Data'];
        }

        return ['error' => 1, 'msg' => 'Invalid Social Account'];
    }

    /**
     * 谷歌注册
     * @param $request
     *
     * @return array
     */
    public function registerForGoogle($request)
    {
        $validator = $this->validate($request);
        if ($validator->fails()) {
            return ['error' => 1, 'msg' => 'Invalid Data'];
        }
        if ($this->isExist($request)) {
            return ['error' => 1, 'msg' => 'It\'s Exist' ,'code'=>402];
        }

        $fbUser = $this->getGoogleUser($request['social_access_token']);

        if (!empty($request['social_google_id']) && $fbUser['status_code'] == 200) {
            $userData = [
                'member_name'         => $request['name'],
                'member_email'        => $request['email'] ?? '',
                'member_nric'         => $request['nric_no'],
                'member_mobile'       => $request['mobile_no'],
                'member_school_id'    => $request['school'],
                'social_access_token' => bcrypt($request['social_access_token']),
                'social_google_id'    => $request['social_google_id'],
                'member_platform'     => $request['platform'],
                'member_add_time'     => time(),
            ];
            if ($res = $this->create($userData)) {
                $token = auth('member')->attempt(['member_id' => $res->member_id]);

                //更新设备id
                $this->updateMemberRegistration($request['registration_id'],$res->member_id);
                $identifier = 'm'.$res->member_id;
                return [
                    'error' => 0,
                    'data'  => [
                        'member_id'  => $res->member_id,
                        'token'      => $token,
                        'signature'  => $this->getSignature($identifier),
                        'identifier' => $identifier,
                    ],
                    'msg'   => 'Registration Success!',
                ];
            }

            return ['error' => 1, 'msg' => 'Invalid Data'];
        }

        return ['error' => 1, 'msg' => 'Invalid Social Account'];
    }

    /**
     * 普通登录
     * @param $request
     *
     * @return array
     */
    public function login($request)
    {
        if(filter_var($request['nric_no'], FILTER_VALIDATE_EMAIL)){
            $field = 'member_email';
        }elseif(substr($request['nric_no'],0,1) == "+"){
            $field = 'member_mobile';
        }else{
            $field = 'member_nric';
        }

        $member = $this->findWhere([$field=>$request['nric_no']])->first();

        if (empty($member)){
            return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
        }

        //检查密码
        if ($request['password'] && !Hash::check($request['password'], $member->member_password)) {
            return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
        }

        if ($member->member_status == 5){
            return ['error' => 1, 'msg' => 'Your account is currently prohibited from logging in.'];
        }
        //更新设备id
        $this->updateMemberRegistration($request['registration_id'],$member->member_id);

        if($token = auth()->guard('member')->attempt(['member_id'=>$member->member_id])){
            $identifier = 'm'.$member->member_id;
            return [
                'error' => 0,
                'data' => [
                    'member_id'  => $member->member_id,
                    'token'      => $token,
                    'signature'  => $this->getSignature($identifier),
                    'identifier' => $identifier,
                ],
                'msg'   => 'Login successful',
            ];
        }

        return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];

    }

    /**
     * 脸书登录
     * @param $request
     *
     * @return array
     */
    public function loginForFacebook($request)
    {
        $member = $this->findWhere(['social_fb_id' => $request['social_fb_id']])->first();
        $fbUser = $this->getFacebookUser($request['social_access_token']);
        if ( ! empty($member['social_fb_id']) || ! empty($member)) {
            if ($member->member_status == 5){
                return ['error' => 1, 'msg' => 'Your account is currently prohibited from logging in.'];
            }
            if ($fbUser['status_code'] == 200) {
                $token = auth()->guard('member')->attempt(['member_id' => $member->member_id]);

                //更新设备id
                $this->updateMemberRegistration($request['registration_id'],$member->member_id);
                $identifier = 'm'.$member->member_id;
                return [
                    'error' => 0,
                    'data'  => [
                        'member_id'  => $member->member_id,
                        'token'      => $token,
                        'signature'  => $this->getSignature($identifier),
                        'identifier' => $identifier,
                    ],
                    'msg'   => 'Login successful',
                ];
            } else {
                return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
            }
        } else {
            return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
        }
    }

    /**
     * 谷歌登录
     * @param $request
     *
     * @return array
     */
    public function loginForGoogle($request)
    {
        $member = $this->findWhere(['social_google_id' => $request['social_google_id']])->first();
        $googleUser = $this->getGoogleUser($request['social_access_token']);
        if ( ! empty($member['social_google_id']) || ! empty($member)) {
            if ($member->member_status == 5){
                return ['error' => 1, 'msg' => 'Your account is currently prohibited from logging in.'];
            }
            if ($googleUser['status_code'] == 200) {
                $token = auth()->guard('member')->attempt(['member_id' => $member->member_id]);

                //更新设备id
                $this->updateMemberRegistration($request['registration_id'],$member->member_id);

                $identifier = 'm'.$member->member_id;
                return [
                    'error' => 0,
                    'data'  => [
                        'member_id'  => $member->member_id,
                        'token'      => $token,
                        'signature'  => $this->getSignature($identifier),
                        'identifier' => $identifier,
                    ],
                    'msg'   => 'Login successful',
                ];
            } else {
                return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
            }
        } else {
            return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
        }
    }

    /**
     * 是否存在
     * @param $data
     *
     * @return mixed
     */
    public function isExist($data)
    {
        return $this->model->where('member_nric', $data['nric_no'])
            ->orWhere('member_mobile', $data['mobile_no'])->first();
    }

    /**
     * 验证请求数据
     * @param $request
     *
     * @return mixed
     */
    private function validate($request)
    {
        if (isset($request['password'])) {
            return Validator::make(
                $request,
                [
                    'name'      => 'required',
                    'password'  => 'required',
                    //'email'     => 'required',
                    'nric_no'   => 'required',
                    'mobile_no' => 'required',
                ]
            );
        }

        return Validator::make(
            $request,
            ['name' => 'required',/* 'email' => 'required', */'nric_no' => 'required', 'mobile_no' => 'required']
        );
    }


    /**
     * 获取脸书用户
     * @param $token
     *
     * @return array
     */
    private function getFacebookUser($token)
    {
        $client = new Client(['defaults' => ['verify' => false]]);
        try {
            $response = $client->request(
                'GET',
                config('custom.facebook_endpoint').'/v2.10/me?field=id,name,email&&access_token='.$token
            );

            return [
                'status_code' => $response->getStatusCode(),
                'body'        => $response->getBody(),
            ];


        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                $body = $e->getResponse()->getBody();
                $status = $e->getResponse()->getStatusCode();

                return [
                    'status_code' => $status,
                    'body'        => $body,
                ];

            }
        }
    }

    /**
     * 获取谷歌用户
     * @param $token
     *
     * @return array
     */
    private function getGoogleUser($token)
    {
        $client = new Client(['defaults' => ['verify' => false]]);
        try {
            $response = $client->request(
                'GET',
                config('custom.google_endpoint').'/oauth2/v3/tokeninfo?id_token='.$token
            );

            return [
                'status_code' => $response->getStatusCode(),
                'body'        => $response->getBody(),
            ];

        } catch (RequestException $e) {

            if ($e->hasResponse()) {
                $body = $e->getResponse()->getBody();
                $status = $e->getResponse()->getStatusCode();

                return [
                    'status_code' => $status,
                    'body'        => $body,
                ];

            }
        }
    }

    private function updateMemberRegistration($registrationId,$memberId)
    {
        $registrationForMember = $this->findWhere(['registration_id'=>$registrationId])->first();
        if (isset($registrationForMember->member_id) && $registrationForMember->member_id != $memberId){
            $this->update(['registration_id'=>''],$registrationForMember->member_id);
        }

        $this->update(['registration_id'=>$registrationId],$memberId);
    }

    public function forgetPassword($request)
    {
        $valid = Validator::make(
            $request,
            ['member_nric' => 'required', 'member_mobile' => 'required', 'password' => 'required|confirmed|min:8|max:20','password_confirmation' => 'required']
        );

        if ($valid->fails()) {
            return ['error' => 1, 'msg' => $valid->errors()->all()[0]];
        }
        
        $member = $this->findWhere(['member_mobile'=>trim($request['member_mobile']),'member_nric'=>trim($request['member_nric'])])->first();
        if (!$member){
            return ['error' => 1, 'msg' => 'This employee does not exist.'];
        }

        $data['member_password'] = bcrypt($request['password']);

        $res = $this->update($data,$member->member_id);

        if($res !== false){
            return ['error' => 0,'data'=>$member,'msg' => 'Password reset complete.'];
        }

        return ['error' => 1, 'msg' => 'Server Error.'];

    }

    /**
     * 关闭接收通知（删除或添加设备id）
     * @param $memberId
     * @param $registrationId
     * @return array
     */
    public function registration($memberId,$registrationId)
    {
        if ($registrationId){
            $res = $this->updateMemberRegistration($registrationId,$memberId);
        }else{
            $res = $this->update(['registration_id'=>''],$memberId);
        }

        if ($res !== false){
            return ['error' => 0,'data'=>[]];
        }

        return ['error' => 1, 'msg' => 'Server Error.'];
    }

    /**
     * @param $identifier
     *
     * @return bool|mixed
     */
    private function getSignature($identifier){

        $tim = new TimApi();
        return $tim->setIdentifier($identifier)->signature();
    }


}