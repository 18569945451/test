<?php

namespace App\Api\V1\Repositories;

use App\Models\JobSchedules;
use Prettus\Repository\Eloquent\BaseRepository;
class HistoryRepository extends BaseRepository
{
    public $workStatusInfo = [
        3=>'Your application is rejected by YY.',
        4=>'This job is auto-cancelled.',
        5=>'You have completed this job.',
        6=>'Payment status: Pending',
        7=>'Your completed job is rejected by YY.',
        8=>'Payment status: Processed',
        9=>'You have cancelled this job.',
        11=>'The job is auto checked out.',
    ];

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return JobSchedules::class;
    }

    public function search($type, $curPage, $pageSize,$memberId, $industryId,$workStatus, $employerId, $startTime, $endTime)
    {
        $offset = ($curPage - 1) * $pageSize;

        //计算总薪水
        $earnedCount = $this->model->whereIn('work_status',['6','8'])->where('member_id',$memberId)->sum('job_salary');
        $deduction = $this->model->whereIn('work_status',['6','8'])->where('member_id',$memberId)->sum('deduction');
        $earned = $earnedCount - $deduction;

        //计算总完成数
        $completeTotal = $this->model->whereIn('work_status',['3','4','5','9','11'])->where('member_id',$memberId)->count();

        $this->model = $this->model->leftJoin('job as j','job_schedules.job_id','j.job_id')
                                   ->leftJoin('employer as e','j.job_employer_admin_id','e.e_admin_id');

        if ($memberId){
            $this->model = $this->model->where('job_schedules.member_id',$memberId);
        }

        if ($industryId){
            $this->model = $this->model->whereIn('j.job_industry_id',$industryId);
        }

        if ($employerId){
            $this->model = $this->model->whereIn('j.job_employer_admin_id',$employerId);
        }

        if ($workStatus){
            $this->model = $this->model->whereIn('job_schedules.work_status',$workStatus);
        }

        if ($startTime > 0){
            $this->model = $this->model->where('j.job_start_date','>',$startTime);
            $this->model = $this->model->where('j.job_start_date','<',$endTime);
        }

        $count = $this->model->count();

        $countPage = ceil($count / $pageSize);

        $result = $this->model->offset($offset)->limit($pageSize)->orderBy('j.job_start_date','desc')->get()->toArray();

        $data = [];
        foreach ($result as $key => $value) {
            $data[$key]['job_id'] = $value['job_id'];
            $data[$key]['job_title'] = $value['job_title'];
            $data[$key]['s_id'] = $value['s_id'];
            $data[$key]['job_image'] = $value['job_image'];
            $data[$key]['employer_logo'] = $value['e_company_logo'];
            $data[$key]['job_employer_company_name'] = $value['job_employer_company_name'];
            $data[$key]['job_industry_name'] = $value['job_industry_name'];
            $data[$key]['job_start_date'] = $value['job_start_date'];
            $data[$key]['job_end_date'] = $value['job_end_date'];
            $data[$key]['job_hour_rate'] = $value['job_hour_rate'];
            $data[$key]['job_address'] = $value['job_address'];
            $data[$key]['info'] = $this->workStatusInfo[$value['work_status']];
            $data[$key]['work_status'] = $value['work_status'];
        }

        $earned = sprintf("%.2f",$earned);
        return [
            'error' => 0,
            'data'  => compact('completeTotal','earned','countPage', 'count', 'curPage', 'pageSize', 'data'),
        ];

        /*if ($type == 'earned') {
            $earned = $this->model->whereIn('work_status',['6','8'])->where('member_id',$memberId)->sum('job_salary');

            return [
                'error' => 0,
                'data'  => compact('earned','countPage', 'count', 'curPage', 'pageSize', 'data'),
            ];
        } else {
            return [
                'error' => 0,
                'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'data'),
            ];
        }*/

    }

    /**
     * 计算待开始工作的工作数
     * @param $memberId
     *
     * @return mixed
     */
    public function pending($memberId)
    {
        return $this->model->whereIn('work_status',['1','2'])->where('member_id',$memberId)->count();
    }

    /**
     * 计算总共赚的薪水
     * @param $memberId
     *
     * @return mixed
     */
    public function earned($memberId)
    {
        $num = $this->model->whereIn('work_status',['6','8'])->where('member_id',$memberId)->sum('job_salary');
        $deduction = $this->model->whereIn('work_status',['6','8'])->where('member_id',$memberId)->sum('job_salary');
        $earned = $num - $deduction;
        return sprintf("%.2f",$earned);
    }

    /**
     * 计算总共完成的工作数
     * @param $memberId
     *
     * @return mixed
     */
    public function completeTotal($memberId)
    {
        return $this->model->whereIn('work_status',['5','6','7','8'])->where('member_id',$memberId)->count();
    }
}