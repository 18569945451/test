<?php

namespace App\Api\V1\Repositories;

use DB;
use App\Models\Job;
use Prettus\Repository\Eloquent\BaseRepository;
class JobRepository extends BaseRepository
{

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return Job::class;
    }

    public function search($curPage, $pageSize, $industryId,$employerId,$startTime)
    {
        
        $offset = ($curPage - 1) * $pageSize;
        $startTime = $startTime ?? time();
        $startTime -= 3600;
        $sql = '';

        $sql .= "SELECT %s FROM ( SELECT j.*, COUNT(js.s_id) AS apply_count FROM job AS j LEFT JOIN job_schedules AS js ON j.job_id = js.job_id AND js.work_status IN (2,5,6,8,11) WHERE j.`job_start_date` > {$startTime} AND j.job_status=4";

        if ($industryId){
            $industryId = implode(',',$industryId);
            $sql .= " AND j.job_industry_id in ({$industryId}) ";
        }

        if ($employerId){
            $employerId = implode(',',$employerId);
            $sql .= " AND j.job_employer_admin_id in ({$employerId}) ";
        }

        $sql .= " GROUP BY j.job_id ) AS t WHERE job_need_people_count > apply_count ";
        
        //总条数
        $countSql = sprintf($sql,'count(*) as total');
        $countNum = \DB::select($countSql);
        $count = $countNum[0]->total;

        //总页数
        $countPage = ceil($count / $pageSize);

        //分页
        $sql .= " ORDER BY job_start_date asc LIMIT {$offset},{$pageSize}";

        //列表数据
        $listSql = sprintf($sql,' * ');

        $result = \DB::select($listSql);

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'result'),
        ];


    }

    public function search_bak($curPage, $pageSize, $industryId,$employerId,$startTime)
    {
        $offset = ($curPage - 1) * $pageSize;
        if ($industryId){
            $this->model = $this->model->whereIn('job_industry_id',$industryId);
        }

        if ($employerId){
            $this->model = $this->model->whereIn('job_employer_admin_id',$employerId);
        }
        
        if ($startTime){
            $this->model = $this->model->where('job_end_date','>',$startTime);
        }else{
            $this->model = $this->model->where('job_end_date','>',time());
        }

        //总数
        $count = $this->model->count();
        
        //总页数
        $countPage = ceil($count / $pageSize);

        //数据
        $result = $this->model->offset($offset)->limit($pageSize)->orderBy('job_start_date','asc')->get()->toArray();

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'result'),
        ];

    }

    public function detail($memberId, $jobId)
    {
        $job = $this->find($jobId)->toArray();

        $data['job'] = $this->formatJob($job);

        //是否在该工作接收组(app端apply按钮是否显示)
        if ($job['recipient_id'] === null || $job['recipient_id'] == 0){
            $data['job']['display_apply_button'] = 1;
        }else{
            $recMember = \DB::table('recipient_groups_member')->where('member_id',$memberId)->where('recipient_group_id',$job['recipient_id'])->first();
            $data['job']['display_apply_button'] = $recMember ? 1: 0;
        }

        $schedules = $this->getSchedules($memberId,$job['job_id']);
        if ($schedules){
            $data['schedules'] = $schedules;
        }else{
            if ($job['job_end_date'] <= time()) {
                return ['error' => 1, 'msg' => 'The job is not available now.'];
            }
        }
        return [
            'error' => 0,
            'data'  => $data,
        ];
    }

    private function formatJob($job){
        $data['job_id'] = $job['job_id'];
        $data['job_title'] = $job['job_title'];
        $data['description']['job_image'] = $job['job_image'];
        $data['description']['job_type'] = $job['job_employer_company_name'];
        $data['description']['job_location'] = $job['job_address'];
        $data['description']['job_date'] = $job['job_address'];
        $data['description']['description'] = $job['job_description'];
        $data['description']['job_industry_name'] = $job['job_industry_name'];
        $data['description']['hourly_rate'] = $job['job_hour_rate'];
        $starTime = $job['job_start_date'];
        $data['description']['job_date'] = date('d/M/Y',$job['job_start_date']).'('.date('H:ia',$starTime).' - '.date('H:ia',$job['job_end_date']).')';
        $data['job_role'] = $job['job_post'];
        $data['required']['age'] = $job['job_people_age'] ? $job['job_people_age']: 'Any';
        $data['required']['language'] = str_replace(' ',',',ucwords(str_replace(',',' ',$job['job_people_language'])));
        $data['required']['gender'] = $job['job_people_sex'] == 0 ? 'Both' : ($job['job_people_sex'] == 1 ? 'Male' : 'Female');
        $data['required']['nationality'] = $job['job_people_nationality'];
        $data['remarks'] = $job['job_note'];
        $data['requirements'] = $job['job_requirements'];

        return $data;
    }

    private function getSchedules($memberId,$jobId){
        $schedulesRep = app(JobSchedulesRepository::class);
        $schedules = $schedulesRep->findWhere(['member_id'=>$memberId,'job_id'=>$jobId])->first();
        if ($schedules) {
            $settingRep = app(SettingRepository::class);
            $setting    = $settingRep->first();

            $cancelHour = (time() - $schedules->add_time) / 3600;

            $deduction = 0;
            if ($cancelHour >= 72) {
                $deduction = $setting->credits_cancel_job_before_72_hours;
            }
            if ($cancelHour < 72 && $cancelHour > 0) {
                $deduction = $setting->credits_cancel_job_within_72_hours;
            }

            $schedules->deduction = $deduction;

            if ($schedules->work_hours == 0 || $schedules->work_status == 11){
                $schedules->work_hours = $this->getWorkHours($jobId,$schedules);
            }

            return $schedules->toArray();
        }

        return [];
    }

    private function getWorkHours($jobId,$schedules)
    {
        $job = $this->find($jobId);
        if ($schedules->checkin_time > $job->job_start_date){
            $beginHandel = strtotime(date('Y-m-d H'.':00', strtotime ("+1 hour", $schedules->checkin_time)));
            $diff = $beginHandel - $schedules->checkin_time;
            $begin = $diff > 1800 ? $beginHandel - 1800 : $beginHandel;
        }else{
            $begin = $job->job_start_date;
        }

        if ($schedules->checkout_time < $job->job_end_date){
            $finish = $schedules->checkout_time;
        }else{
            $finish = $job->job_end_date;
        }

        return floor(($finish - $begin) / 60);
    }
}