<?php

namespace App\Api\V1\Repositories;

use App\Models\Support;
use Prettus\Repository\Eloquent\BaseRepository;
class SupportRepository extends BaseRepository
{

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return Support::class;
    }

    public function send($memberId, $subject, $message)
    {
        $data = [
            'subject'   => $subject,
            'message'   => $message,
            'member_id' => $memberId,
            'add_time'  => time(),
        ];

        if ($res = $this->create($data)) {
            return ['error' => 0, 'data' => $res];
        }

        return ['error' => 1, 'msg' => 'Server Error.'];
    }
}