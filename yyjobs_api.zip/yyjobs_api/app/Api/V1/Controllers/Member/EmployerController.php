<?php

namespace App\Api\V1\Controllers\Member;

use App\Api\V1\Repositories\EmployerRepository;
use App\Http\Controllers\Controller;
use Dingo\Api\Http\Request;

class EmployerController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/employee/employer/list",
     *   tags={"employee/employer"},
     *   summary="employer列表（雇主列表）",
     *   description="employer列表（雇主列表）",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v1+json",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function lists(Request $request)
    {
        $employerRep        = app(EmployerRepository::class);

        $curPage         = $request->input('cur_page', 1);
        $pageSize        = $request->input('page_size', 9999);

        $data = $employerRep->search($curPage, $pageSize);
        if ($data['error']) {
            return apiReturn([], 404, $data['msg']);
        }

        return apiReturn($data['data']['result']);
    }
}
