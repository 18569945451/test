<?php

namespace App\Api\V1\Controllers\Member;

use App\Api\V1\Repositories\EmployerRepository;
use App\Api\V1\Repositories\HistoryRepository;
use App\Http\Controllers\Controller;
use Dingo\Api\Http\Request;

class HistoryController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/employee/history/completed",
     *   tags={"employee/history"},
     *   summary="completed列表",
     *   description="completed列表",
     *   operationId="completed",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="query",  name="industry_id[]",type="string",  description="行业id(可用,分隔方式)", required=false),
     *   @SWG\Parameter(in="query",  name="employer_id[]",type="string",  description="雇主id(可用,分隔方式)", required=false),
     *   @SWG\Parameter(in="query",  name="start_time",type="string",  description="工作开始时间(时间戳)", required=false),
     *   @SWG\Parameter(in="query",  name="end_time",type="string",  description="工作结束时间(时间戳)", required=false),
     *   @SWG\Parameter(in="query",  name="work_status[]",type="string",  description="工作状态(可用,分隔方式)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v1+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function completed(Request $request)
    {
        $historyRep        = app(HistoryRepository::class);

        $curPage         = $request->input('cur_page', 1);
        $pageSize        = $request->input('page_size', 10);
        $startTime       = $request->input('start_time', 1);
        $endTime         = $request->input('end_time', 1830268800);
        $memberId        = auth('member')->user()->member_id;
        //行业
        if (empty($request->input('industry_id'))){
            $industryId = [];
        }else{
            if(is_string($request->input('industry_id'))){
                $industryId = explode(',',$request->input('industry_id'));
            }else{
                $industryId = $request->input('industry_id');
            }
        }

        //雇主
        if (empty($request->input('employer_id'))){
            $employerId = [];
        }else{
            if(is_string($request->input('employer_id'))){
                $employerId = explode(',',$request->input('employer_id'));
            }else{
                $employerId = $request->input('employer_id');
            }
        }

        //工作状态 默认 3 4 5 9
        if (empty($request->input('work_status'))){
            $workStatus = ['3','4','5','9','11'];
        }else{
            if(is_string($request->input('work_status'))){
                $workStatus = explode(',',$request->input('work_status'));
            }else{
                $workStatus = $request->input('work_status');
            }
        }

        $data = $historyRep->search('completed',$curPage, $pageSize,$memberId,$industryId,$workStatus,$employerId,$startTime,$endTime);

        if ($data['error']) {
            return apiReturn([], 404, $data['msg']);
        }

        return apiReturn($data['data']);
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/history/earned",
     *   tags={"employee/history"},
     *   summary="earned列表",
     *   description="earned列表",
     *   operationId="earned",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="query",  name="industry_id[]",type="string",  description="行业id(可用,分隔方式)", required=false),
     *   @SWG\Parameter(in="query",  name="employer_id[]",type="string",  description="雇主id(可用,分隔方式)", required=false),
     *   @SWG\Parameter(in="query",  name="start_time",type="string",  description="工作开始时间(时间戳)", required=false),
     *   @SWG\Parameter(in="query",  name="end_time",type="string",  description="工作结束时间(时间戳)", required=false),
     *   @SWG\Parameter(in="query",  name="work_status[]",type="string",  description="工作状态(可用,分隔方式)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v1+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function earned(Request $request)
    {
        $historyRep        = app(HistoryRepository::class);

        $curPage         = $request->input('cur_page', 1);
        $pageSize        = $request->input('page_size', 10);
        $startTime       = $request->input('start_time', 1);
        $endTime         = $request->input('end_time', 1830268800);
        $memberId        = auth('member')->user()->member_id;
        //行业
        if (empty($request->input('industry_id'))){
            $industryId = [];
        }else{
            if(is_string($request->input('industry_id'))){
                $industryId = explode(',',$request->input('industry_id'));
            }else{
                $industryId = $request->input('industry_id');
            }
        }

        //雇主
        if (empty($request->input('employer_id'))){
            $employerId = [];
        }else{
            if(is_string($request->input('employer_id'))){
                $employerId = explode(',',$request->input('employer_id'));
            }else{
                $employerId = $request->input('employer_id');
            }
        }

        //工作状态 默认 3 4 5 9
        if (empty($request->input('work_status'))){
            $workStatus = ['6','8'];
        }else{
            if(is_string($request->input('work_status'))){
                $workStatus = explode(',',$request->input('work_status'));
            }else{
                $workStatus = $request->input('work_status');
            }
        }

        $data = $historyRep->search('earned',$curPage, $pageSize,$memberId,$industryId,$workStatus,$employerId,$startTime,$endTime);

        if ($data['error']) {
            return apiReturn([], 404, $data['msg']);
        }

        return apiReturn($data['data']);
    }
}
