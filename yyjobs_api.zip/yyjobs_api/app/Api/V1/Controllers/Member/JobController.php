<?php

namespace App\Api\V1\Controllers\Member;

use App\Api\V1\Repositories\JobRepository;
use App\Http\Controllers\Controller;
use Dingo\Api\Http\Request;

class JobController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/employee/job/list",
     *   tags={"employee/job"},
     *   summary="工作列表",
     *   description="工作列表",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="query",  name="industry_id[]",type="string",  description="行业id", required=false),
     *   @SWG\Parameter(in="query",  name="employer_id[]",type="string",  description="雇主id", required=false),
     *   @SWG\Parameter(in="query",  name="start_time",type="string",  description="工作开始时间", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v1+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function lists(Request $request)
    {
        $jobRep        = app(JobRepository::class);

        $curPage         = $request->input('cur_page', 1);
        $pageSize        = $request->input('page_size', 15);
        $startTime       = $request->input('start_time', time());
        if (empty($request->input('industry_id'))){
            $industryId = [];
        }else{
            if(is_string($request->input('industry_id'))){
                $industryId = explode(',',$request->input('industry_id'));
            }else{
                $industryId = $request->input('industry_id');
            }
        }

        if (empty($request->input('employer_id'))){
            $employerId = [];
        }else{
            if(is_string($request->input('employer_id'))){
                $employerId = explode(',',$request->input('employer_id'));
            }else{
                $employerId = $request->input('employer_id');
            }
        }

        $data = $jobRep->search($curPage, $pageSize, $industryId,$employerId,$startTime);
        if ($data['error']) {
            return apiReturn([], 404, $data['msg']);
        }

        return apiReturn($data['data']);
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/job/detail",
     *   tags={"employee/job"},
     *   summary="工作详情",
     *   description="工作详情",
     *   operationId="detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="job_id",type="string",  description="工作id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v1+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="<table>
        <tr>请求成功</tr>
        <tr><td>work_status</td><td>工作状态（1：Pending信用低于70的时候申请的，2：Applied申请成功，3：Rejected Request管理员拒绝，4：Auto Cancelled未签到或到时未签出自动取消，5：Complete成功签出待审批，6：Payment Pending待支付，7：Rejected不认可该工作，8：Payment Processed支付完成，9：主动取消，10：主动拒绝）</td></tr>
        </table>"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function detail(Request $request)
    {
        $jobRep = app(JobRepository::class);

        $memberId = auth('member')->user()->member_id;
        $jobId    = $request->input('job_id');

        $data = $jobRep->detail($memberId, $jobId);
        if ($data['error']) {
            return apiReturn([], 404, $data['msg']);
        }

        return apiReturn($data['data']);
    }
}
