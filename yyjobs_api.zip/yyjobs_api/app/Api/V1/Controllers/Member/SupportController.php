<?php

namespace App\Api\V1\Controllers\Member;

use App\Api\V1\Repositories\SupportRepository;
use App\Http\Controllers\Controller;
use Dingo\Api\Http\Request;

class SupportController extends Controller
{
    /**
     * @SWG\Post(path="/index.php/api/employee/support/send",
     *   tags={"employee/support"},
     *   summary="意见反馈",
     *   description="意见反馈",
     *   operationId="send",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="subject",type="string",  description="标题", required=true),
     *   @SWG\Parameter(in="formData",  name="message",type="string",  description="内容", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v1+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function send(Request $request)
    {
        $supportRep        = app(SupportRepository::class);

        $subject  = $request->input('subject');
        $message  = $request->input('message');
        $memberId = auth('member')->user()->member_id;

        if (!$subject || !$message || !$memberId){
            return apiReturn([], 403, 'Parameter error.');
        }

        $data = $supportRep->send($memberId,$subject,$message);

        if ($data['error']) {
            return apiReturn([], 404, $data['msg']);
        }

        return apiReturn($data['data']);
    }
}
