<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/20
 * Time: 14:19
 */

namespace App\Api\V1\Services;

use GuzzleHttp\Client;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;

class TimApi
{
    protected $sdkAppId;
    protected $identifier;
    protected $privateKeyPath;
    protected $signatureToolPath;

    protected $batchSendMsgUri = 'https://console.tim.qq.com/v4/openim/batchsendmsg';
    protected $createRoomUri = 'https://console.tim.qq.com/v4/group_open_http_svc/create_group';
    protected $addRoomUsersUri = 'https://console.tim.qq.com/v4/group_open_http_svc/add_group_member';
    protected $sendRoomNotificationUri = 'https://console.tim.qq.com/v4/group_open_http_svc/send_group_system_notification';
    protected $sendRoomMessage = 'https://console.tim.qq.com/v4/group_open_http_svc/send_group_msg';

    public function __construct()
    {
        $env = env('APP_ENV') == 'production' ? 'product' : 'develop';

        $this->sdkAppId          = config("tim.{$env}.app_id");
        $this->identifier        = config("tim.{$env}.admin_identifier");
        $this->privateKeyPath    = config("tim.{$env}.private_key_path");
        $this->signatureToolPath = config("tim.{$env}.signature_tool_path");

        return $this;
    }

    /**
     * @return string
     */
    public function batchSendMsgUri()
    {
        $signature = $this->signature();
        return $this->batchSendMsgUri."?usersig={$signature}&identifier={$this->identifier}&sdkappid={$this->sdkAppId}&contenttype=json";
    }

    /**
     * 创建聊天室地址
     * @return string
     */
    public function createRoomUri()
    {
        $signature = $this->signature();
        $rand = rand(10000000, 90000000);
        return $this->createRoomUri."?sdkappid={$this->sdkAppId}&identifier={$this->identifier}&usersig={$signature}&random={$rand}&contenttype=json";
    }

    /**
     * 添加人员进聊天室地址
     * @return string
     */
    public function addRoomUsersUri()
    {
        $signature = $this->signature();
        $rand = rand(10000000, 90000000);
        return $this->addRoomUsersUri."?sdkappid={$this->sdkAppId}&identifier={$this->identifier}&usersig={$signature}&random={$rand}&contenttype=json";
    }

    /**
     * 发送聊天室系统通知地址
     * @return string
     */
    public function sendRoomNotificationUri()
    {
        $signature = $this->signature();
        $rand = rand(10000000, 90000000);
        return $this->sendRoomNotificationUri."?sdkappid={$this->sdkAppId}&identifier={$this->identifier}&usersig={$signature}&random={$rand}&contenttype=json";
    }

    /**
     * 发送聊天室信息地址
     * @return string
     */
    public function sendRoomMessageUri()
    {
        $signature = $this->signature();
        $rand = rand(10000000, 90000000);
        return $this->sendRoomMessage."?sdkappid={$this->sdkAppId}&identifier={$this->identifier}&usersig={$signature}&random={$rand}&contenttype=json";
    }

    /**
     * @param $identifier
     *
     * @return $this
     */
    public function setIdentifier($identifier)
    {
        $this->identifier = $identifier;
        return $this;
    }

    /**
     * @return bool|mixed
     */
    public function signature()
    {
        $command = $this->signatureToolPath
            . ' ' . escapeshellarg($this->privateKeyPath)
            . ' ' . escapeshellarg($this->sdkAppId)
            . ' ' . escapeshellarg($this->identifier);

        exec($command, $out, $status);

        if ($status == -1) {
            return false;
        }
        return current($out);
    }

    /**
     * @param        $recruiter
     * @param string $msgContent
     * @param string $fromAccount
     * @param array  $toAccount
     *
     * @return bool
     * @throws ValidatorException
     */
    public function batchSendMsg($recruiter,string $msgContent,string $fromAccount,array $toAccount)
    {
        $content = [
            'SyncOtherMachine' => 1,
            'From_Account'     => $fromAccount,
            'To_Account'       => array_values($toAccount),
            'MsgRandom'        => rand(10000000, 90000000),
            'MsgBody'          => [['MsgType' => 'TIMTextElem', 'MsgContent' => ['Text' => $msgContent]]],
            'OfflinePushInfo' => [
                'PushFlag'    => 0,
                'Desc'        => $msgContent,
                'Ext'         => $msgContent,
                'AndroidInfo' => ['Sound' => 'android.mp3'],
                'ApnsInfo'    => [
                    'Sound'     => 'apns.mp3',
                    'BadgeMode' => 1,
                    'Title'     => $recruiter->name,
                ],
            ],
        ];
        $client = new Client([
            'headers' => [ 'Content-Type' => 'application/json' ]
        ]);
        $response = $client->post($this->batchSendMsgUri(), ['body'=>json_encode($content)]);
        $body = json_decode((string)$response->getBody());
        if ($body->ErrorCode != 0 || $body->ActionStatus != 'OK'){
            throw new ValidatorException(new MessageBag([$body->ErrorInfo]));
        }
        return true;
    }

    /**
     * 创建聊天室
     * @param $users
     * @param $roomName
     * @return bool
     */
    public function createRoom($users,$roomName)
    {
        $MemberList = [];
        foreach ($users as $key=>$user) {
            $MemberList[$key]['Member_Account']=$user;
        }

        $content = [
            "Name"       => $roomName,
            "Type"       => "ChatRoom",
            "MemberList" => $MemberList,
        ];
        $client = new Client(['verify' => false]);
        $response = $client->post($this->createRoomUri(), ['body'=>json_encode($content)]);
        return json_decode((string)$response->getBody());
    }

    /**
     * 增加群组成员
     * @param $users
     * @param $roomGroupID
     * @return bool
     */
    public function addRoomUsers($users,$roomGroupID)
    {
        $MemberList = [];
        foreach ($users as $user) {
            $MemberList[]['Member_Account'] = $user;
        }

        $content = [
            "GroupId"    => $roomGroupID,
            "MemberList" => $MemberList,
        ];

        $client = new Client(['verify' => false]);
        $response = $client->post($this->addRoomUsersUri(), ['body'=>json_encode($content)]);
        return json_decode((string)$response->getBody());
    }

    /**
     * 发送聊天室系统通知
     * @param $roomGroupID
     *
     * @return mixed
     */
    public function sendRoomNotification($roomGroupID)
    {
        $content = [
            "GroupId"    => $roomGroupID,
            "Content" => "Welcome to join the group! Let's start to chat now. ",
        ];

        $client = new Client(['verify' => false]);
        $response = $client->post($this->sendRoomNotificationUri(), ['body'=>json_encode($content)]);
        return json_decode((string)$response->getBody());
    }

    /**
     * 发送聊天室信息
     * @param $roomGroupID
     *
     * @return mixed
     */
    public function sendRoomMessage($roomGroupID)
    {
        $content = [
            "GroupId" => $roomGroupID,
            "Random"  => rand(1000000, 9000000),
            "MsgBody"=>[
                [
                    "MsgType"=>"TIMTextElem",
                    "MsgContent"=>[
                        "Text"=>"Welcome to join the group! Let's start to chat now. "
                    ]
                ]
            ],
            "OfflinePushInfo"=>[
                "PushFlag"=>0,
                "Desc"=>"Welcome to join the group! Let's start to chat now. ",
                "Ext"=>"Welcome to join the group! Let's start to chat now. ",
                "AndroidInfo"=>[
                    "Sound"=>"android.mp3"
                ],
                "ApnsInfo"=>[
                    "Sound"=>"apns.mp3",
                    "BadgeMode" => 1,
                    "Title" => "Welcome to join the group! Let's start to chat now. ",
                    "SubTitle" => "Welcome to join the group! Let's start to chat now. ",
                ]
            ]
        ];


        $client = new Client(['verify' => false]);
        $response = $client->post($this->sendRoomMessageUri(), ['body'=>json_encode($content)]);
        return json_decode((string)$response->getBody());
    }
}