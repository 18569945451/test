<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/8
 * Time: 10:19
 */

namespace App\Api\V1\Finance\Repositories;

use App\Api\V1\Finance\Criteria\Finance\FinanceCriteria;
use App\Api\V1\Finance\Entities\Finance;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;
use Illuminate\Support\Facades\Hash;

class FinanceRepository extends BaseRepository
{
    public function model()
    {
        return Finance::class;
    }

    /**
     * 登陆
     * @param $request
     *
     * @return array
     * @throws ValidatorException
     */
    public function login($request)
    {
        $this->pushCriteria(FinanceCriteria::class);
        $finance = $this->first(['id', 'email', 'password', 'status', 'registration_id']);
        if ( ! $finance) {
            throw new ValidatorException(
                new MessageBag(['Can\'t find this e-mail account'])
            );
        }

        if ( ! Hash::check($request->password, $finance->password)) {
            throw new ValidatorException(
                new MessageBag(['Incorrect password for account'])
            );
        }

        if (1 != $finance->status || $finance->roleAdmin->role->name != 'Finance') {
            throw new ValidatorException(
                new MessageBag(['Your account is forbidden to login'])
            );
        }

        return ['id' => $finance->id, 'token' => $this->getToken($finance)];
    }

    /**
     * 获取token
     *
     * @param Finance $finance
     *
     * @return bool
     */
    private function getToken(Finance $finance)
    {
        return auth('finance')->attempt(['id' => $finance->id]);
    }
}