<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:49
 */

namespace App\Api\V1\Finance\Validators;

use \Prettus\Validator\Contracts\ValidatorInterface;
use \Prettus\Validator\LaravelValidator;

class AuthValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules= [
            'login' => [
                'email' => 'required|email|min:5',
                'password'=>'required|between:8,20',
            ]
        ];
}