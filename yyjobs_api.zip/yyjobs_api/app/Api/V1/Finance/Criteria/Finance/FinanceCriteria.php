<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/8
 * Time: 10:43
 */

namespace App\Api\V1\Finance\Criteria\Finance;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class FinanceCriteria implements CriteriaInterface
{
    public function apply($model,RepositoryInterface $repository)
    {
        return $model->where('type',0)->where('email',request('email'));
    }
}