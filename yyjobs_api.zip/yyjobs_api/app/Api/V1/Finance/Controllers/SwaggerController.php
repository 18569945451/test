<?php

namespace App\Api\V1\Finance\Controllers;

use App\Http\Controllers\Controller;

class SwaggerController extends Controller
{
    /**
     * 返回JSON格式的Swagger定义
     *
     * 这里需要一个主`Swagger`定义：
     * @SWG\Swagger(
     *   @SWG\Info(
     *     title="YY Finance",
     *     version="v1"
     *   )
     * )
     */
    public function getJson()
    {
        $swagger = \Swagger\scan(app_path('Api/V1/Finance/Controllers/'));
        return response()->json($swagger, 200);
    }
}