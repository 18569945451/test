<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/8
 * Time: 10:12
 */

namespace App\Api\V1\Finance\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V1\Finance\Validators\AuthValidator;
use App\Api\V1\Finance\Repositories\FinanceRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class AuthController extends Controller
{
    protected $repository;

    protected $validator;

    public function __construct(FinanceRepository $repository, AuthValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/finance/auth/login",
     *   tags={"finance/auth"},
     *   summary="登录",
     *   description="登录",
     *   operationId="login",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="email",type="string", default="Finance_01@qq.com",  description="邮箱", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string", default="12345678"  description="密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v1+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function login(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('login');
            $data = $this->repository->login($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/finance/auth/info",
     *   tags={"finance/info"},
     *   summary="个人信息",
     *   description="个人信息",
     *   operationId="info",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v1+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function info(Request $request)
    {
        return apiReturn(auth('finance')->user());
    }
}