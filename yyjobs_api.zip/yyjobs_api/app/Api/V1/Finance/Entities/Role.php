<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/8
 * Time: 11:03
 */

namespace App\Api\V1\Finance\Entities;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'roles';


    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';

    public $timestamps = false;

}
