<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/8
 * Time: 11:03
 */

namespace App\Api\V1\Finance\Entities;

use Illuminate\Database\Eloquent\Model;

class RoleAdmin extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'role_admin';


    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'user_id';

    public $timestamps = false;

    public function role()
    {
        return $this->hasOne(Role::class,'id','role_id');
    }

}
