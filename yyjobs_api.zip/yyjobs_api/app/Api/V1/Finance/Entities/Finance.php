<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/8
 * Time: 10:19
 */

namespace App\Api\V1\Finance\Entities;

use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Finance extends Authenticatable implements JWTSubject
{
    protected $guard = 'finance';


    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'admins';


    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden
        = [
            'password',
            'remember_token',
            'has_employer',
            'registration_id',
            'created_at',
            'updated_at',
        ];

    /**
     * @var array
     */
    protected $fillable
        = [
            'name',
            'email',
            'password',
            'remember_token',
            'created_at',
            'updated_at',
            'type',
            'has_employer',
            'registration_id',
            'status',
        ];

    public $timestamps = false;

    /**
     * 获取主键
     *
     * @return string
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * 返回一个键值数组，其中包含要添加到JWT的任何自定义声明。
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function roleAdmin()
    {
        return $this->hasOne(RoleAdmin::class, 'user_id', 'id');
    }
}
