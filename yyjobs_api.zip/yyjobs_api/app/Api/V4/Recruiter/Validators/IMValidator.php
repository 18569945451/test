<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/1/11
 * Time: 10:47
 */

namespace App\Api\V4\Recruiter\Validators;

use \Prettus\Validator\Contracts\ValidatorInterface;
use \Prettus\Validator\LaravelValidator;

class IMValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'batchSendMsg' => [
                'msg_content' => 'required|string|max:1024',
                'to_account'  => 'required|array',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

}