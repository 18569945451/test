<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/21
 * Time: 13:52
 */

namespace App\Api\V4\Recruiter\Validators;

use Illuminate\Support\MessageBag;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use \Prettus\Validator\LaravelValidator;

class StaffValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'staffList' => [
                'keyword'   => 'sometimes|string|max:32',
                'cur_page'  => 'sometimes|integer|min:0',
                'page_size' => 'sometimes|integer|min:1',
            ],
            'edit'      => [
                'member_id' => 'required|integer',
                'name'      => 'required|string|min:2|max:64',
                'nric'      => 'required|string|min:8',
                'phone'     => 'required|string|min:11',
                'gender'    => 'required|integer|in:1,2',
                'dob'       => 'required|integer',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    public function editAction($request)
    {
        $member = \DB::table('member')->where('member_nric',$request->nric)->first();
        if ($member && $member->member_id != $request->member_id){
            throw new ValidatorException(new MessageBag(['Nric already exists.']));
        }
    }
}