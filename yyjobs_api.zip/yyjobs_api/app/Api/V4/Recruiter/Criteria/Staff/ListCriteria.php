<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/21
 * Time: 13:55
 */

namespace App\Api\V4\Recruiter\Criteria\Staff;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    public function apply($model,RepositoryInterface $repository)
    {
        $recruiter = auth('recruiter')->user();
        $keyword = request('keyword');
        return $model->when($keyword,function($query)use($keyword){
            return $query->where(function($subQuery)use($keyword){
               return $subQuery->where('member_name','like',"%{$keyword}%")
                   ->orWhere('member_nric','like',"%{$keyword}%");
            });
        })->where('member_recruiter_id',$recruiter->id);
    }
}