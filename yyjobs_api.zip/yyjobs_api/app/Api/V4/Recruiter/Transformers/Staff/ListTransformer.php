<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/21
 * Time: 13:58
 */

namespace App\Api\V4\Recruiter\Transformers\Staff;

use League\Fractal\TransformerAbstract;
use App\Api\V4\Recruiter\Entities\Member;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Recruiter\Entities\Member $model
     *
     * @return array
     */
    public function transform(Member $model)
    {
        return [
            'member_id'     => $model->member_id,
            'identifier'    => 'm'.$model->member_id,
            'member_name'   => $model->member_name,
            'member_nric'   => $model->member_nric,
            'member_avatar' => $model->member_avatar ? $model->member_avatar : '',
        ];
    }
}