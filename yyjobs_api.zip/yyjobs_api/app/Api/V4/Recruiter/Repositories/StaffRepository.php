<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/21
 * Time: 13:51
 */

namespace App\Api\V4\Recruiter\Repositories;

use App\Api\V4\Recruiter\Entities\Member;
use Prettus\Repository\Eloquent\BaseRepository;

class StaffRepository extends BaseRepository
{
    public function model()
    {
        return Member::class;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function staffList($request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 20);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $result = $condition->orderBy('member_name','ASC')->offset($offset)->limit($pageSize)->get(['member_id','member_name','member_nric','member_avatar']);

        $data['list']        = $this->parserResult($result)['data'];

        return $data;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function staffEdit($request)
    {
        $data = [
            'member_name'     => $request->name,
            'member_nric'     => $request->nric,
            'member_mobile'   => $request->phone,
            'member_sex'      => $request->gender,
            'member_birthday' => $request->dob,
        ];
        return $this->model->whereMemberId($request->member_id)->update($data);
    }
}