<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/21
 * Time: 11:14
 */

namespace App\Api\V4\Recruiter\Repositories;

use App\Api\V1\Services\TimApi;
use Hash;
use App\Api\V4\Recruiter\Criteria\Auth\RecruiterCriteria;
use App\Api\V4\Recruiter\Entities\Recruiter;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class AuthRepository extends BaseRepository
{
    private $fakeRegister = true;

    public function model()
    {
        return Recruiter::class;
    }

    /**
     * 登陆
     * @param $request
     *
     * @return array
     * @throws ValidatorException
     */
    public function login($request)
    {
        if ($this->fakeRegister){
            $res = Redis::get('yyjobs-api:recruiter:fake_register:'.$request->email);
            if ($res){
                throw new ValidatorException(
                    new MessageBag(['Your account needs to be approved by YY to be used'])
                );
            }
        }

        $this->pushCriteria(RecruiterCriteria::class);
        $admin = $this->first(['id','name', 'email', 'password', 'registration_id']);
        if ( ! $admin) {
            throw new ValidatorException(
                new MessageBag(['Can\'t find this e-mail account'])
            );
        }

        if ( ! Hash::check($request->password, $admin->password)) {
            throw new ValidatorException(
                new MessageBag(['Incorrect password for account'])
            );
        }

        $this->setRegistrationId(
            $admin->id,
            $request->registration_id,
            $admin->registration_id
        );

        $token = $this->getToken($admin);

        $identifier = 'r'.$admin->id;
        return [
            'id'    => $admin->id,
            'token' => $token,
            'name'  => $admin->name,
            'email'  => $admin->email,
            'signature'  => $this->getSignature($identifier),
            'identifier' => $identifier,
        ];
    }

    /**
     * 设置用户的RegistrationId
     *
     * @param        $id
     * @param string $newRegistrationId
     * @param string $curRegistrationId
     *
     * @return bool
     */
    private function setRegistrationId($id, $newRegistrationId = '', $curRegistrationId = '')
    {
        //只有id 则清空该id的RegistrationId
        if ($id && ! $newRegistrationId) {
            return $this->update(['registration_id' => ''], $id);
        }

        if ( ! $curRegistrationId) {
            $curRegistrationId = $this->find($id, ['registration_id'])->registration_id;
        }

        //新RegistrationId与旧RegistrationId对比，不同则设置新的
        if ($newRegistrationId && ($newRegistrationId != $curRegistrationId)) {
            $newRegistrationOwner = $this->skipCriteria()
                ->findByField('registration_id', $newRegistrationId)
                ->first();

            //新RegistrationId之前是否有所有者，有则清空
            if ($newRegistrationOwner) {
                $this->update(['registration_id' => ''], $newRegistrationOwner->id);
            }
            $this->update(['registration_id' => $newRegistrationId], $id);

            return true;
        }

        return true;
    }


    /**
     * 获取token
     *
     * @param Recruiter $admin
     *
     * @return bool
     */
    private function getToken(Recruiter $admin)
    {
        return auth('recruiter')->attempt(['id' => $admin->id]);
    }

    /**
     * @param $identifier
     *
     * @return bool|mixed
     */
    private function getSignature($identifier){

        $tim = new TimApi();
        return $tim->setIdentifier($identifier)->signature();
    }

    public function setRegistration($registrationID)
    {
        $admin = $this->model->find(auth('recruiter')->id());
        return $this->setRegistrationId(
            $admin->id,
            $registrationID,
            $admin->registration_id
        );
    }

    public function fakeRegister($email, $password)
    {
        Redis::set('yyjobs-api:recruiter:fake_register:'.$email,1);
        return true;
    }
}