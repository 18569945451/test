<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/1/16
 * Time: 16:03
 */

namespace App\Api\V4\Recruiter\Repositories;

use App\Api\V4\Recruiter\Entities\Recruiter;
use Prettus\Repository\Eloquent\BaseRepository;

class ProfileRepository extends BaseRepository
{
    public function model()
    {
        return Recruiter::class;
    }

    /**
     * @param $data
     *
     * @return array
     */
    public function transformer($data)
    {
        return [
            'id'                => $data->id,
            'name'              => $data->name,
            'email'             => $data->email,
            //'avatar'            => $data->avatar,
            'group_last_modify' => $data->group_last_modify,
        ];
    }

}