<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/1/11
 * Time: 10:45
 */

namespace App\Api\V4\Recruiter\Repositories;

use App\Api\V1\Services\TimApi;

class IMRepository
{
    public function batchSendMsg($request)
    {
        $recruiter = auth('recruiter')->user();
        $identifier = 'r'.$recruiter->id;
        $tim = new TimApi();
        return $tim->batchSendMsg($recruiter,$request->msg_content,$identifier,$request->to_account);
    }
}