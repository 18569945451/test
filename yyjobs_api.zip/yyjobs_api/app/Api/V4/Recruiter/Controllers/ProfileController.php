<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/1/16
 * Time: 16:02
 */

namespace App\Api\V4\Recruiter\Controllers;

use App\Api\V4\Recruiter\Criteria\Staff\ListCriteria;
use App\Api\V4\Recruiter\Presenters\Staff\ListPresenter;
use App\Api\V4\Recruiter\Repositories\ProfileRepository;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    protected $repository;

    public function __construct(ProfileRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/profile/info",
     *   tags={"profile/info"},
     *   summary="个人信息",
     *   description="个人信息",
     *   operationId="profile/info",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function info(Request $request)
    {
        $data = auth('recruiter')->user();

        return apiReturn($this->repository->transformer($data));
    }

}