<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/21
 * Time: 13:48
 */

namespace App\Api\V4\Recruiter\Controllers;

use App\Api\V4\Recruiter\Criteria\Staff\ListCriteria;
use App\Api\V4\Recruiter\Presenters\Staff\ListPresenter;
use App\Http\Controllers\Controller;
use App\Api\V4\Recruiter\Validators\StaffValidator;
use App\Api\V4\Recruiter\Repositories\StaffRepository;
use Illuminate\Http\Request;
use Prettus\Validator\Exceptions\ValidatorException;

class StaffController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(StaffRepository $repository,StaffValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/staff/list",
     *   tags={"recruiter/staff"},
     *   summary="员工列表",
     *   description="员工列表",
     *   operationId="staff/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认20)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function staffList(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('staffList');
            $this->repository->pushCriteria(ListCriteria::class);
            $this->repository->setPresenter(ListPresenter::class);
            $data = $this->repository->staffList($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/staff/info/edit",
     *   tags={"recruiter/staff"},
     *   summary="修改员工信息",
     *   description="修改员工信息",
     *   operationId="staff/info/edit",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="member_id",type="string",  description="用户id", required=true),
     *   @SWG\Parameter(in="formData",  name="name",type="string",  description="姓名", required=true),
     *   @SWG\Parameter(in="formData",  name="nric",type="string",  description="身份证号", required=true),
     *   @SWG\Parameter(in="formData",  name="phone",type="string",  description="手机号码(+6596584906)", required=true),
     *   @SWG\Parameter(in="formData",  name="gender",type="string",  description="性别(1：男，2：女)", required=true),
     *   @SWG\Parameter(in="formData",  name="dob",type="string",  description="出生年月日(时间戳)", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function edit(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('edit');
            $this->validator->editAction($request);
            $data = $this->repository->staffEdit($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/recruiter/staff/info/detail",
     *   tags={"recruiter/staff"},
     *   summary="员工信息",
     *   description="员工信息",
     *   operationId="staff/info/detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="member_id",type="string",  description="用户id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(Request $request)
    {
        $field = [
            'member_id',
            'member_name',
            'member_nric',
            'member_sex',
            'member_mobile',
            'member_email',
            'member_salary_rate',
            'member_birthday',
            'member_avatar',
        ];
        $data = $this->repository->find($request->member_id,$field);
        return apiReturn($data);
    }
}