<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/1/11
 * Time: 10:42
 */

namespace App\Api\V4\Recruiter\Controllers;

use App\Api\V4\Recruiter\Repositories\IMRepository;
use App\Api\V4\Recruiter\Validators\IMValidator;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Prettus\Validator\Exceptions\ValidatorException;

class IMController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(IMRepository $repository, IMValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/recruiter/im/batchsendmsg",
     *   tags={"recruiter/im"},
     *   summary="群发消息",
     *   description="群发消息",
     *   operationId="im/batchsendmsg",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="msg_content",type="string",  description="消息文本", required=true),
     *   @SWG\Parameter(in="formData",  name="to_account[0]",type="string",  description="目标账户列表", required=true),
     *   @SWG\Parameter(in="formData",  name="to_account[1]",type="string",  description="目标账户列表", required=false),
     *   @SWG\Parameter(in="formData",  name="to_account[2]",type="string",  description="目标账户列表", required=false),
     *   @SWG\Parameter(in="formData",  name="to_account[3]",type="string",  description="目标账户列表", required=false),
     *   @SWG\Parameter(in="formData",  name="to_account[4]",type="string",  description="目标账户列表", required=false),
     *   @SWG\Parameter(in="formData",  name="to_account[5]",type="string",  description="目标账户列表", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function batchSendMsg(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('batchSendMsg');
            $data = $this->repository->batchSendMsg($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

}