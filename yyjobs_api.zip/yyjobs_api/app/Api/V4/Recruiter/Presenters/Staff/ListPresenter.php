<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/21
 * Time: 13:56
 */

namespace App\Api\V4\Recruiter\Presenters\Staff;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Recruiter\Transformers\Staff\ListTransformer;

class ListPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new ListTransformer();
    }
}