<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 16:41
 */

namespace App\Api\V4\Employer\Controllers;

use App\Api\V4\Employer\Criteria\Attendance\DateCriteria;
use App\Api\V4\Employer\Criteria\Attendance\ExportCriteria;
use App\Api\V4\Employer\Presenters\Attendance\ExportPresenter;
use App\Api\V4\Employer\Presenters\Attendance\ExportWithChildPresenter;
use App\Api\V4\Employer\Presenters\Attendance\TodayPresenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Employer\Validators\AttendanceValidator;
use App\Api\V4\Employer\Repositories\AttendanceRepository;

class AttendanceController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(AttendanceRepository $repository, AttendanceValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/attendance/list",
     *   tags={"employer/attendance"},
     *   summary="attendance list",
     *   description="attendance list",
     *   operationId="attendance/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="string",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="date",type="string",  description="日期(2018-10-18)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function attendanceList(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('attendanceList');
            $this->validator->validPermission();

            $this->repository->pushCriteria(DateCriteria::class);
            $this->repository->setPresenter(TodayPresenter::class);

            $data = $this->repository->attendanceList();
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/attendance/update",
     *   tags={"employer/attendance"},
     *   summary="attendance update",
     *   description="attendance update",
     *   operationId="attendance update",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="employer_admin_id",type="string",  description="账号ID", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][s_id]",type="integer",  description="记录ID", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][remark]",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][remark]",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function update(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('update');
            $this->validator->validPermission();
            $data = $this->repository->processUpdate($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/attendance/add",
     *   tags={"employer/attendance"},
     *   summary="attendance add",
     *   description="attendance add",
     *   operationId="attendance add",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="employer_admin_id",type="string",  description="账号ID", required=true),
     *   @SWG\Parameter(in="formData",  name="member_id",type="integer",  description="雇员id", required=true),
     *   @SWG\Parameter(in="formData",  name="job_id",type="integer",  description="工作id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function add(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('add');
            $this->validator->validPermission('add');
            $data = $this->repository->processStore($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/attendance/confirm",
     *   tags={"employer/attendance"},
     *   summary="attendance 确认",
     *   description="attendance 确认",
     *   operationId="attendance 确认",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="date",type="string",  description="需要确认的日期", required=true),
     *   @SWG\Parameter(in="formData",  name="confirm_signature",type="file",  description="确认签名", required=true),
     *   @SWG\Parameter(in="formData",  name="employer_admin_id[0]",type="integer",  description="部门id", required=true),
     *   @SWG\Parameter(in="formData",  name="employer_admin_id[2]",type="integer",  description="部门id", required=false),
     *   @SWG\Parameter(in="formData",  name="employer_admin_id[3]",type="integer",  description="部门id", required=false),
     *   @SWG\Parameter(in="formData",  name="employer_admin_id[4]",type="integer",  description="部门id", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function confirm(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('confirm');
            $this->validator->validPermissionForConfirm();
            $data = $this->repository->processConfirm($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }



    /**
     * @SWG\Post(path="/index.php/api/employer/attendance/revise",
     *   tags={"employer/attendance"},
     *   summary="attendance revise",
     *   description="attendance revise",
     *   operationId="attendance revise",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="employer_admin_id",type="string",  description="账号ID", required=true),
     *   @SWG\Parameter(in="formData",  name="confirm_signature",type="file",  description="确认签名", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][s_id]",type="integer",  description="记录ID", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[2][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[2][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[2][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[2][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[2][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[2][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[2][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[2][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[3][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[3][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[3][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[3][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[3][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[3][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[3][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[3][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[4][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[4][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[4][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[4][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[4][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[4][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[4][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[4][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[5][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[5][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[5][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[5][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[5][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[5][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[5][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[5][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[6][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[6][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[6][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[6][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[6][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[6][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[6][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[6][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[7][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[7][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[7][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[7][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[7][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[7][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[7][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[7][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[8][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[8][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[8][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[8][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[8][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[8][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[8][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[8][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[9][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[9][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[9][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[9][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[9][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[9][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[9][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[9][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[10][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[10][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[10][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[10][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[10][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[10][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[10][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[10][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[11][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[11][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[11][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[11][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[11][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[11][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[11][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[11][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[12][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[12][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[12][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[12][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[12][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[12][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[12][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[12][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[13][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[13][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[13][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[13][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[13][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[13][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[13][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[13][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[14][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[14][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[14][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[14][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[14][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[14][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[14][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[14][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[15][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[15][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[15][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[15][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[15][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[15][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[15][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[15][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[16][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[16][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[16][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[16][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[16][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[16][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[16][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[16][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[17][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[17][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[17][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[17][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[17][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[17][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[17][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[17][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[18][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[18][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[18][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[18][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[18][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[18][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[18][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[18][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[19][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[19][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[19][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[19][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[19][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[19][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[19][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[19][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[20][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[20][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[20][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[20][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[20][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[20][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[20][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[20][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[21][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[21][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[21][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[21][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[21][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[21][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[21][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[21][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[22][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[22][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[22][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[22][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[22][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[22][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[22][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[22][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[23][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[23][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[23][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[23][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[23][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[23][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[23][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[23][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[24][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[24][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[24][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[24][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[24][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[24][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[24][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[24][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[25][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[25][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[25][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[25][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[25][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[25][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[25][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[25][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[26][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[26][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[26][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[26][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[26][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[26][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[26][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[26][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[27][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[27][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[27][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[27][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[27][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[27][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[27][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[27][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[28][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[28][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[28][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[28][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[28][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[28][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[28][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[28][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[29][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[29][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[29][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[29][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[29][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[29][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[29][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[29][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[30][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[30][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[30][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[30][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[30][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[30][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[30][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[30][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[31][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[31][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[31][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[31][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[31][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[31][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[31][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[31][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[32][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[32][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[32][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[32][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[32][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[32][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[32][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[32][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[33][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[33][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[33][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[33][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[33][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[33][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[33][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[33][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[34][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[34][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[34][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[34][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[34][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[34][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[34][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[34][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[35][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[35][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[35][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[35][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[35][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[35][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[35][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[35][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[36][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[36][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[36][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[36][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[36][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[36][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[36][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[36][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[37][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[37][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[37][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[37][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[37][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[37][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[37][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[37][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[38][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[38][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[38][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[38][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[38][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[38][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[38][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[38][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[39][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[39][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[39][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[39][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[39][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[39][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[39][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[39][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[40][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[40][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[40][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[40][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[40][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[40][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[40][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[40][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[41][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[41][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[41][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[41][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[41][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[41][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[41][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[41][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[42][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[42][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[42][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[42][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[42][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[42][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[42][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[42][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[43][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[43][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[43][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[43][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[43][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[43][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[43][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[43][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[44][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[44][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[44][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[44][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[44][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[44][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[44][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[44][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[45][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[45][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[45][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[45][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[45][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[45][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[45][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[45][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[46][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[46][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[46][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[46][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[46][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[46][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[46][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[46][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[47][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[47][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[47][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[47][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[47][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[47][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[47][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[47][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[48][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[48][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[48][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[48][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[48][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[48][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[48][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[48][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[49][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[49][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[49][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[49][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[49][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[49][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[49][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[49][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[50][s_id]",type="integer",  description="记录ID", required=false),
     *   @SWG\Parameter(in="formData",  name="data[50][checkin_time]",type="integer",  description="签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[50][checkout_time]",type="integer",  description="签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[50][adjusted_checkin_time]",type="integer",  description="修改后的签到时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[50][adjusted_checkout_time]",type="integer",  description="修改后签出时间", required=false),
     *   @SWG\Parameter(in="formData",  name="data[50][checkin_signature]",type="file",  description="签到签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[50][checkout_signature]",type="file",  description="签出签名", required=false),
     *   @SWG\Parameter(in="formData",  name="data[50][hours]",type="string",  description="+/-小时数", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function revise(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('revise');
            $this->validator->validPermission();
            $data = $this->repository->processRevise($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/attendance/remark",
     *   tags={"employer/attendance"},
     *   summary="attendance remark",
     *   description="attendance remark",
     *   operationId="attendance remark",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="employer_admin_id",type="string",  description="账号ID", required=true),
     *   @SWG\Parameter(in="formData",  name="s_id",type="string",  description="记录", required=true),
     *   @SWG\Parameter(in="formData",  name="remark",type="string",  description="string", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function remark(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('remark');
            $this->validator->validPermission();
            $data = $this->repository->remark($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/attendance/export",
     *   tags={"employer/attendance"},
     *   summary="attendance export",
     *   description="attendance export",
     *   operationId="attendance/export",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="string",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="date",type="string",  description="日期(2018-10-18)", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function export(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('export');
            $this->validator->validPermission();

            $this->repository->pushCriteria(ExportCriteria::class);
            //$this->repository->setPresenter(ExportPresenter::class);
            $this->repository->setPresenter(ExportWithChildPresenter::class);

            $data = $this->repository->attendanceList();
            return apiReturn($this->repository->export($data,$request));
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

}