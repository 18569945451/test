<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 13:35
 */

namespace App\Api\V4\Employer\Controllers;

use App\Api\V4\Employer\Criteria\Job\DateCriteria;
use App\Api\V4\Employer\Criteria\Job\GroupCriteria;
use App\Api\V4\Employer\Criteria\Job\HistoryCriteria;
use App\Api\V4\Employer\Criteria\Job\TodayCriteria;
use App\Api\V4\Employer\Presenters\Job\ExportDetailPresenter;
use App\Api\V4\Employer\Presenters\Job\TodayPresenter;
use App\Api\V4\Employer\Presenters\Job\FutureDetailPresenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V4\Employer\Validators\JobValidator;
use App\Api\V4\Employer\Repositories\JobRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class JobController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(JobRepository $repository, JobValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/job/get-jobs-time",
     *   tags={"employer/job"},
     *   summary="获取工作时间",
     *   description="获取工作时间",
     *   operationId="job/get-jobs-time",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="employer_status",type="integer",  description="1：pending，2：confirmed，3：revised，(默认1)", required=false),
     *   @SWG\Parameter(in="query",  name="date",type="string",  description="日期（2018-10-31）", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="json"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function jobsTime(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('jobsTime');
            $this->validator->validPermission();

            $this->repository->pushCriteria(TodayCriteria::class);
            $this->repository->setPresenter(TodayPresenter::class);

            $data = $this->repository->jobsTime($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/job/future",
     *   tags={"employer/job"},
     *   summary="future (New Attendance List)",
     *   description="future",
     *   operationId="job/future",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="start_date",type="string",  description="开始日期(2018-10-14)", required=false),
     *   @SWG\Parameter(in="query",  name="end_date",type="string",  description="结束日期(2018-10-20)", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="json"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function future(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('future');
            $this->validator->validPermission();

            $this->repository->pushCriteria(GroupCriteria::class);
            $data = $this->repository->future();

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/job/future-detail",
     *   tags={"employer/job"},
     *   summary="future detail(New Attendance List)",
     *   description="future detail",
     *   operationId="job/future-detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="date",type="string",  description="日期(2018-10-14)", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="json"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function futureDetail(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('futureDetail');
            $this->validator->validPermission();

            $this->repository->pushCriteria(DateCriteria::class);
            $this->repository->setPresenter(FutureDetailPresenter::class);
            $data = $this->repository->futureDetail();

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/job/future-export",
     *   tags={"employer/job"},
     *   summary="future export(New Attendance List)",
     *   description="future export",
     *   operationId="job/future-export",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="date",type="string",  description="日期(2018-10-14)", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="json"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function futureExport(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('futureDetail');
            $this->validator->validPermission();

            $this->repository->pushCriteria(DateCriteria::class);
            $this->repository->setPresenter(ExportDetailPresenter::class);
            $data = $this->repository->futureDetail();
            return apiReturn($this->repository->futureExport($data));
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/history/list",
     *   tags={"employer/history"},
     *   summary="history list",
     *   description="history list",
     *   operationId="history/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="employer_status",type="integer",  description="employer操作状态(1：pending，2：confirmed，3：revised)", required=false),
     *   @SWG\Parameter(in="query",  name="start_date",type="string",  description="开始日期(2018-10-14)", required=false),
     *   @SWG\Parameter(in="query",  name="end_date",type="string",  description="结束日期(2018-10-20)", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function historyList(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('historyList');
            $this->validator->validPermission();

            $this->repository->pushCriteria(HistoryCriteria::class);
            $data = $this->repository->histories();
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}