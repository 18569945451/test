<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/1/17
 * Time: 10:10
 */

namespace App\Api\V4\Employer\Controllers;

use App\Api\V4\Employer\Repositories\ProfileRepository;
use App\Api\V4\Employer\Validators\ProfileValidator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Employer\Validators\EmployeeValidator;
use App\Api\V4\Employer\Presenters\Employee\SinglePresenter;

class ProfileController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(ProfileRepository $repository, ProfileValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/profile/password/set",
     *   tags={"employer/profile"},
     *   summary="修改密码",
     *   description="修改密码",
     *   operationId="profile/password/set",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="old_password",type="string",  description="旧密码", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="新密码", required=true),
     *   @SWG\Parameter(in="formData",  name="password_confirmation",type="string",  description="确认密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function setPassword(Request $request)
    {
        try {
            $employer = auth('employer')->user();
            $this->validator->with($request->all())->passesOrFail('setPassword');
            $this->validator->validPassword($employer, $request->old_password);
            $data = $this->repository->setPassword($employer, $request->password);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}