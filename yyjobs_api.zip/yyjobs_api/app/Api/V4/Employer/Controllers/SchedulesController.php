<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/16
 * Time: 14:05
 */

namespace App\Api\V4\Employer\Controllers;

use App\Api\V4\Employer\Criteria\Schedules\GroupJobCriteria;
use App\Api\V4\Employer\Validators\SchedulesValidator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Employer\Repositories\SchedulesRepository;

/**
 * History
 * Class SchedulesController
 *
 * @package App\Api\V4\Employer\Controllers
 */
class SchedulesController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(SchedulesRepository $repository,SchedulesValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    public function historyList(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('historyList');
            $this->validator->validPermission();

            $this->repository->pushCriteria(GroupJobCriteria::class);
            $data = $this->repository->getResult();
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}