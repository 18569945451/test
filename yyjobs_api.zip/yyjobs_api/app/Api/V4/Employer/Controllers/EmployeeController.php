<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 11:14
 */

namespace App\Api\V4\Employer\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Employer\Validators\EmployeeValidator;
use App\Api\V4\Employer\Repositories\EmployeeRepository;
use App\Api\V4\Employer\Presenters\Employee\SinglePresenter;

class EmployeeController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(EmployeeRepository $repository, EmployeeValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/employee/find",
     *   tags={"employer/employee"},
     *   summary="查找staff",
     *   description="查找staff",
     *   operationId="employee/find",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="nric",type="string",  description="身份证", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="性别(1：男，2：女)"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function find(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('find');
            $this->repository->setPresenter(SinglePresenter::class);
            $data = $this->repository->search($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}