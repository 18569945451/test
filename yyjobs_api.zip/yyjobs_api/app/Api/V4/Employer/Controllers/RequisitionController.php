<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/12
 * Time: 14:02
 */

namespace App\Api\V4\Employer\Controllers;

use App\Api\V4\Employer\Presenters\Requisition\DateLimitPresenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Employer\Validators\RequisitionValidator;
use App\Api\V4\Employer\Repositories\RequisitionRepository;

class RequisitionController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(RequisitionRepository $repository, RequisitionValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/requisition/add",
     *   tags={"employer/requisition"},
     *   summary="新增需求",
     *   description="新增需求",
     *   operationId="add",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="remark",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="formData",  name="signature",type="file",  description="签名", required=true),
     *   @SWG\Parameter(in="formData",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][date]",type="string",  description="日期（2018-10-14）", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][requisition][0][start_time]",type="string",  description="开始时间（09:00）", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][requisition][0][end_time]",type="string",  description="结束时间（09:00）", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][requisition][0][job_title]",type="string",  description="工作名称", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][requisition][0][need_num]",type="string",  description="需要人数", required=true),
     *   @SWG\Parameter(in="formData",  name="data[0][requisition][1][start_time]",type="string",  description="开始时间（09:00）", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][requisition][1][end_time]",type="string",  description="结束时间（09:00）", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][requisition][1][job_title]",type="string",  description="工作名称", required=false),
     *   @SWG\Parameter(in="formData",  name="data[0][requisition][1][need_num]",type="string",  description="需要人数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][date]",type="string",  description="日期（2018-10-15）", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][requisition][0][start_time]",type="string",  description="开始时间（09:00）", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][requisition][0][end_time]",type="string",  description="结束时间（09:00）", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][requisition][0][job_title]",type="string",  description="工作名称", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][requisition][0][need_num]",type="string",  description="需要人数", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][requisition][1][start_time]",type="string",  description="开始时间（09:00）", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][requisition][1][end_time]",type="string",  description="结束时间（09:00）", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][requisition][1][job_title]",type="string",  description="工作名称", required=false),
     *   @SWG\Parameter(in="formData",  name="data[1][requisition][1][need_num]",type="string",  description="需要人数", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function add(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('add');
            $this->validator->addAction();
            $data = $this->repository->add($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/requisition/get",
     *   tags={"employer/requisition"},
     *   summary="获取需求",
     *   description="获取需求",
     *   operationId="get",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="start_date",type="string",  description="开始日期（2018-10-14）", required=true),
     *   @SWG\Parameter(in="query",  name="end_date",type="string",  description="结束日期（2018-10-20）", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="'pending','approve','update','reject'"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function get(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('get');
            $this->validator->getAction();

            $this->repository->setPresenter(DateLimitPresenter::class);
            $data = $this->repository->getRequisition(
                $request->employer_admin_id,
                $request->start_date,
                $request->end_date
            );
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/requisition/update",
     *   tags={"employer/requisition"},
     *   summary="更新单条需求",
     *   description="更新单条需求",
     *   operationId="update",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="id",type="string",  description="id", required=true),
     *   @SWG\Parameter(in="formData",  name="remark",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="formData",  name="signature",type="file",  description="签名", required=false),
     *   @SWG\Parameter(in="formData",  name="date",type="string",  description="日期（2018-10-15）", required=true),
     *   @SWG\Parameter(in="formData",  name="start_time",type="string",  description="开始时间（09:00）", required=true),
     *   @SWG\Parameter(in="formData",  name="end_time",type="string",  description="结束时间（18:00）", required=true),
     *   @SWG\Parameter(in="formData",  name="job_title",type="string",  description="工作名称", required=true),
     *   @SWG\Parameter(in="formData",  name="need_num",type="string",  description="需要人数", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function update(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('update');
            $this->validator->updateAction();
            $data = $this->repository->setRequisition($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}