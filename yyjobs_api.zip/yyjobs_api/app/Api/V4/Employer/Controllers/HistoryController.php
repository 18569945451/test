<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/20
 * Time: 11:45
 */

namespace App\Api\V4\Employer\Controllers;

use App\Api\V4\Employer\Criteria\History\GroupJobCriteria;
use App\Api\V4\Employer\Presenters\History\GroupJobPresenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Employer\Validators\HistoryValidator;
use App\Api\V4\Employer\Repositories\HistoryRepository;


class HistoryController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(HistoryRepository $repository, HistoryValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG_Bak\Get(path="/index.php/api/employer/history/list",
     *   tags={"employer/history"},
     *   summary="history list",
     *   description="history list",
     *   operationId="history/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="query",  name="employer_status",type="integer",  description="employer操作状态(1：pending，2：confirmed，3：revised)", required=false),
     *   @SWG\Parameter(in="query",  name="start_date",type="string",  description="开始日期(2018-10-14)", required=false),
     *   @SWG\Parameter(in="query",  name="end_date",type="string",  description="结束日期(2018-10-20)", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function historyList(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('historyList');
            $this->validator->validPermission();

            $this->repository->pushCriteria(GroupJobCriteria::class);
            //$this->repository->setPresenter(GroupJobPresenter::class);

            $data = $this->repository->historyList();
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}