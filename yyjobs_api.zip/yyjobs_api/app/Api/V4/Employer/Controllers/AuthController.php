<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:29
 */

namespace App\Api\V4\Employer\Controllers;

use App\Api\V4\Employer\Repositories\AdminRepository;
use App\Api\V4\Employer\Validators\AuthValidator;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    protected $repository;

    protected $validator;

    public function __construct(AdminRepository $repository, AuthValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/auth/login",
     *   tags={"employer/auth"},
     *   summary="登录",
     *   description="登录",
     *   operationId="login",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="formData",  name="registration_id",type="string",  description="设备id", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function login(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('login');
            $data = $this->repository->login($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/auth/operation-password",
     *   tags={"employer/auth"},
     *   summary="验证操作密码",
     *   description="验证操作密码",
     *   operationId="operation-password",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="operation_password",type="string",  description="操作密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function operationPassword(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('operationPassword');
            $admin = auth('employer')->user();
            if ($admin->operation_password != $request->operation_password){
                return apiReturn([], 403,'Incorrect password');
            }

            return apiReturn(true);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}