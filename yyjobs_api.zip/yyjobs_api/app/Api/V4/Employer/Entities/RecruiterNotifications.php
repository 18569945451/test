<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/21
 * Time: 9:41
 */

namespace App\Api\V4\Employer\Entities;

use Illuminate\Database\Eloquent\Model;

class RecruiterNotifications extends Model
{
    protected $table = 'recruiter_notifications';
    protected $primaryKey = 'id';
    protected $fillable = ['type', 'admin_id', 'title', 'content', 'data', 'job_id', 'is_read', 'time'];
    public $timestamps = false;
}
