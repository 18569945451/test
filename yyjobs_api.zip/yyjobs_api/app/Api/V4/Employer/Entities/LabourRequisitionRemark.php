<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/12
 * Time: 14:05
 */

namespace App\Api\V4\Employer\Entities;


use Illuminate\Database\Eloquent\Model;

class LabourRequisitionRemark extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    //protected $table = 'labour_requisition_remarks';


    /**
     * @var array
     */
    protected $fillable = ['remark', 'signature',];


    public $timestamps = false;

    public function requisition()
    {
        return $this->hasMany(LabourRequisition::class, 'remark_id', 'id');
    }


}