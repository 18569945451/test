<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 13:38
 */

namespace App\Api\V4\Employer\Validators;

use Illuminate\Support\MessageBag;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use \Prettus\Validator\LaravelValidator;

class JobValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'jobsTime'     => [
                'employer_admin_id' => 'required|numeric',
                'date'              => 'string',
            ],
            'future'       => [
                'employer_admin_id' => 'required|numeric',
                'start_date'        => 'date|after:today',
                'end_date'          => 'date|required_with:start_date',
            ],
            'futureDetail' => [
                'employer_admin_id' => 'required|numeric',
                'date'              => 'required|date|after:today',
            ],
            'historyList' => [
                'employer_admin_id' => 'required|integer|min:1',
                'employer_status'   => 'integer',
                'start_date'        => 'date',
                'end_date'          => 'date|before:tomorrow|required_with:start_date',
                'cur_page'          => 'integer|min:1',
                'page_size'         => 'integer|min:1',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    /**
     * @throws ValidatorException
     */
    public function validPermission()
    {
        $user = auth('employer')->user();
        if ($user->parent_id != 0 && $user->id != request('employer_admin_id')) {
            throw new ValidatorException(new MessageBag(['You are not eligible for data']));
        }
    }
}