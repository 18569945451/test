<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 16:45
 */

namespace App\Api\V4\Employer\Validators;

use App\Api\V4\Employer\Entities\Job;
use App\Api\V4\Employer\Entities\Schedule;
use Illuminate\Support\MessageBag;
use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;

class AttendanceValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'attendanceList' => [
                'employer_admin_id' => 'required|integer|min:1',
            ],
            'update'         => [
                'employer_admin_id'             => 'required|integer|min:1',
                'data'                          => 'required|array',
                'data.*.s_id'                   => 'required|integer|min:1',
                'data.*.checkin_time'           => 'integer|min:0',
                'data.*.checkout_time'          => 'integer|min:0',
                'data.*.adjusted_checkin_time'  => 'integer|min:0',
                'data.*.adjusted_checkout_time' => 'integer|min:0',
                'data.*.checkin_signature'      => 'image|between:0,255',
                'data.*.checkout_signature'     => 'image|between:0,255',
                'data.*.hours'                  => 'required|numeric',
                'data.*.remark'                 => 'string|between:0,255',
            ],
            'add'            => [
                'employer_admin_id' => 'required|integer|min:1',
                'member_id'         => 'required|integer|min:1',
                'job_id'            => 'required|integer|min:1',
            ],
            'confirm'        => [
                'date'                => 'required|date|before:tomorrow',
                'confirm_signature'   => 'required|image|between:0,255',
                'employer_admin_id'   => 'required|array',
                'employer_admin_id.*' => 'required|integer|min:1',
            ],
            'revise'         => [
                'employer_admin_id'             => 'required|integer|min:1',
                'confirm_signature'             => 'required|image|between:0,255',
                'data'                          => 'array',
                'data.*.s_id'                   => 'integer|min:1',
                'data.*.checkin_time'           => 'integer|min:0',
                'data.*.checkout_time'          => 'integer|min:0',
                'data.*.adjusted_checkin_time'  => 'integer|min:0',
                'data.*.adjusted_checkout_time' => 'integer|min:0',
                'data.*.hours'                  => 'numeric',
            ],
            'remark'         => [
                'employer_admin_id' => 'required|integer|min:1',
                's_id'              => 'required|integer|min:1',
                'remark'            => 'sometimes|string|max:255',
            ],
            'export'         => [
                'employer_admin_id' => 'required|integer|min:1',
                'date'              => 'required|date',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    public function validPermission($action = '')
    {
        $user = auth('employer')->user();
        if ($user->parent_id != 0 && $user->id != request('employer_admin_id')) {
            throw new ValidatorException(new MessageBag(['You are not eligible for data']));
        }
        if ($action == 'add') {
            $res = \DB::table('job_schedules')->where('member_id', request('member_id'))->where('job_id', request('job_id'))->count();
            if ($res || $this->hasConflict( request('job_id'),request('member_id'))) {
                throw new ValidatorException(new MessageBag(['Cannot add employees repeatedly']));
            }
        }
    }

    public function validPermissionForConfirm()
    {
        $user     = auth('employer')->user();
        $adminIds = request('employer_admin_id');

        foreach ($adminIds as $adminId) {
            if ($user->parent_id != 0 && $user->id != $adminId) {
                throw new ValidatorException(new MessageBag(['You are not eligible to confirm this data']));
            }
        }
    }

    public function hasConflict($jobId, $memberId)
    {
        $job = Job::find($jobId);
        return Schedule::leftJoin('job as j','job_schedules.job_id','j.job_id')
            ->where('job_schedules.member_id',$memberId)
            ->where(function ($query)use ($job){
                $query->where(function ($query) use ($job) {
                    $query->where('j.job_start_date', '<=', $job->job_start_date);
                    $query->where('j.job_end_date', '>=', $job->job_start_date);
                });
                $query->orWhere(function ($query) use ($job){
                    $query->where('j.job_start_date', '<=', $job->job_end_date);
                    $query->where('j.job_end_date', '>=', $job->job_end_date);
                });
            })
            /*->whereIn('job_schedules.work_status',[1,2,13])*/
            ->count();
    }

}