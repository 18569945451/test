<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 11:18
 */

namespace App\Api\V4\Employer\Validators;

use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class EmployeeValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'find'   => [
                'nric' => 'required|max:9',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];
}