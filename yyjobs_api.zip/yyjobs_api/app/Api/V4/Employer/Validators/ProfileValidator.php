<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/1/17
 * Time: 10:12
 */

namespace App\Api\V4\Employer\Validators;

use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;
use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class ProfileValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'setPassword'   => [
                'old_password' => 'required|min:6',
                'password' => 'required|min:8|confirmed',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    /**
     * @param $employer
     * @param $oldPasswd
     *
     * @return bool
     * @throws ValidatorException
     */
    public function validPassword($employer,$oldPasswd)
    {
        if (!\Hash::check($oldPasswd,$employer->password)){
            throw new ValidatorException(new MessageBag(['Old password validation error.']));
        }
        return true;
    }
}