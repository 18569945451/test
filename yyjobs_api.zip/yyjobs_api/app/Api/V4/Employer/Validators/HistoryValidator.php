<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/20
 * Time: 11:47
 */

namespace App\Api\V4\Employer\Validators;

use Illuminate\Support\MessageBag;
use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;

class HistoryValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'historyList' => [
                'employer_admin_id' => 'required|integer|min:1',
                'employer_status'   => 'integer',
                'start_date'        => 'date',
                'end_date'          => 'date|before:tomorrow|required_with:start_date',
                'cur_page'          => 'integer|min:1',
                'page_size'         => 'integer|min:1',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    public function validPermission($action = '')
    {
        $user = auth('employer')->user();
        if ($user->parent_id != 0 && $user->id != request('employer_admin_id')) {
            throw new ValidatorException(new MessageBag(['You are not eligible for data']));
        }
        if ($action == 'add') {
            $res = \DB::table('job_schedules')->where('member_id', request('member_id'))->where('job_id', request('job_id'))->count();
            if ($res) {
                throw new ValidatorException(new MessageBag(['Cannot add employees repeatedly']));
            }
        }
    }

}