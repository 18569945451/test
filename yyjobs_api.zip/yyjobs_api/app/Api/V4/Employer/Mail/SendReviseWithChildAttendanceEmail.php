<?php

namespace App\Api\V4\Employer\Mail;

use Excel;
use Carbon\Carbon;
use App\Api\V4\Employer\Entities\Schedule;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendReviseWithChildAttendanceEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $date;
    public $employerAdminId;

    public function __construct($date,$employerAdminId)
    {
        $this->date = $date;
        $this->employerAdminId = !is_array($employerAdminId) ? [$employerAdminId] : $employerAdminId;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $data = $this->getData();
        $subject = count($data) ? 'Revised '.$data[0]['job_date'].' - '.$data[0]['employer_name'] : 'Send Revised Attendance Email';
        $excelUri = $this->toExcel($data);
        return $this->subject($subject)->from('xiaowei@hongyegroup.com.sg')->markdown('v4.employer.SendReviseAttendanceEmail')->attach($excelUri);
    }

    /**
     * 获取原始数据
     * @return array
     */
    public function getData()
    {
        $model = new Schedule();
        $between = [
            Carbon::parse($this->date)->getTimestamp(),
            Carbon::parse($this->date)->addDay()->getTimestamp(),
        ];
        $model = $model->join('job as j','job_schedules.job_id','j.job_id')
            ->join('member as m','job_schedules.member_id','m.member_id')
            ->where('job_schedules.is_send',1)
            ->whereIn('j.job_employer_admin_id',$this->employerAdminId)
            ->whereBetween('j.job_start_date', $between);
        $data = $model->get(['job_schedules.s_id', 'm.member_id', 'm.member_name', 'm.member_sex','m.member_nric','m.member_mobile',
                             'job_schedules.checkin_time', 'job_schedules.checkout_time','job_schedules.adjusted_checkin_time',
                             'job_schedules.adjusted_checkout_time','job_schedules.revise_version',
                             'job_schedules.work_hours', 'job_schedules.adjusted_work_minutes','job_schedules.parent_id','job_schedules.employer_remark',
                             'j.job_id','j.job_start_date', 'j.job_end_date','j.job_employer_company_name', 'j.job_employer_admin_id','j.employer_status','j.confirm_signature'
        ]);
        
        return $this->present($data);
    }

    /**
     * 格式化原始数据
     * @param $data
     *
     * @return array
     */
    public function present($data)
    {
        $data = $this->sortByLevel($data->toArray());
        $result = [];
        $model = new Schedule();
        foreach ($data as $key => $value) {
            if ($value['adjusted_work_minutes'] != 0){
                $originMinutes = $model->getWorkMinutes($value['adjusted_checkin_time'],$value['adjusted_checkout_time']) * 60;
                $total = round($value['adjusted_work_minutes']/ 60,2);
                $hours = round(($value['adjusted_work_minutes']- $originMinutes) / 60,2);
            }else{
                $total = $hours = 0;
            }

            $result[$key]['s_id']                   = $value['s_id'];
            $result[$key]['parent_id']              = $value['parent_id'];
            $result[$key]['member_id']              = $value['member_id'];
            $result[$key]['job_employer_admin_id']  = $value['job_employer_admin_id'];
            $result[$key]['employer_name']          = $value['job_employer_company_name'];
            $result[$key]['member_name']            = strtoupper($value['member_name']);
            $result[$key]['member_nric']            = strtoupper($value['member_nric']);
            $result[$key]['member_sex']             = $value['member_sex'] == 1 ? 'M' : 'F';
            $result[$key]['member_mobile']          = $value['member_mobile'];
            $result[$key]['job_date']               = Carbon::createFromTimestamp($value['job_start_date'])->format('M d Y');

            $result[$key]['checkin_time']           = $value['checkin_time'] ? Carbon::createFromTimestamp($value['checkin_time'])->format('H:i') : '';;
            $result[$key]['checkout_time']          = $value['checkout_time'] ? Carbon::createFromTimestamp($value['checkout_time'])->format('H:i') : '';;
            $result[$key]['adjusted_checkin_time']  = Carbon::createFromTimestamp($value['adjusted_checkin_time'])->format('H:i');
            $result[$key]['adjusted_checkout_time'] = Carbon::createFromTimestamp($value['adjusted_checkout_time'])->format('H:i');
            if ($value['parent_id'] == 0){
                $result[$key]['hours'] = $hours;
                $result[$key]['total'] = $total;
            }else{
                $thanPre = $total - $result[$key-1]['origin_total'];
                $result[$key]['hours'] = 0;
                $result[$key]['total'] = $thanPre;
            }
            $result[$key]['origin_total']       = $total;
            $result[$key]['remark']             = $value['employer_remark'];
            $result[$key]['revise_version']     = $value['revise_version'];
        }
        return $result;
    }

    /**
     * 返回Excel地址
     * @param $data
     *
     * @return string
     */
    public function toExcel($data)
    {
        $maxVersion = max(array_column($data,'revise_version'));
        $cellData = [
            ['No. of Staff Applied List'],
            ['Name', 'NRIC', 'Gender', 'Mobile Phone', 'Employer', 'Job Date', 'Start Time', 'Time In', 'End Time', 'Time Out', '+/- Hours', 'Total Hours', 'Remark', 'Revise',],
        ];
        foreach ($data as $key=>$value) {
            $lineData = [
                $value['parent_id'] != 0 ? '         '.$value['member_name'] : $value['member_name'],
                $value['member_nric'],
                $value['member_sex'],
                $value['member_mobile'],
                $value['employer_name'],
                $value['job_date'],
                $value['adjusted_checkin_time'],
                $value['checkin_time'],
                $value['adjusted_checkout_time'],
                $value['checkout_time'],
                $value['hours'],
                $value['total'],
                $value['remark'],
                $value['revise_version'] == 0 ? '' : $value['revise_version'],
            ];
            array_push($cellData,$lineData);
        }

        $fileName = 'No. of Staff Applied List-Revise-'.$maxVersion;
        Excel::create($fileName,function($excel)use($cellData,$maxVersion){
            $excel->sheet('list', function($sheet) use ($cellData,$maxVersion){
                $i = 1;
                $sheet->mergeCells('A1:N1');
                $sheet->setStyle(array('font' => array('name' => 'Calibri', 'size' => 12, 'bold' => false)));
                foreach ((array)$cellData as $record) {
                    $j = 'A';
                    foreach($record as $key=>$value) {
                        $sheet->cell($j.$i, function($cell) use ($key,$value,$i,$j,$record,$maxVersion) {
                            $cell->setValue($value);
                            if ($key == 0 & $i == 1){
                                $cell->setFontSize(20);
                            }
                            if ($i > 2 && $j == 'A'){
                                $cell->setAlignment('left');
                            }else{
                                $cell->setAlignment('center');
                            }
                            if ($i > 2 && $record[13] == $maxVersion){
                                $cell->setFontColor('#FF0000');
                            }
                        });
                        $j++;
                    }
                    $i++;
                }
            });
        })->store('xls',storage_path('excel/confirm_attendance'));
        return storage_path('excel/confirm_attendance'.'/'.$fileName.'.xls');
    }

    /**
     * 根据主副数据进行排序
     * @param array $data
     * @param int   $id
     * @param array $arr
     *
     * @return array
     */
    public function sortByLevel(array $data, $id = 0, &$arr = [])
    {
        foreach ($data as $v) {
            if ($id == $v['parent_id']) {
                $arr[] = $v;
                $this->sortByLevel($data, $v['s_id'], $arr);
            }
        }
        return $arr;
    }
}
