<?php

namespace App\Api\V4\Employer\Mail;

use Excel;
use Carbon\Carbon;
use App\Api\V4\Employer\Entities\Schedule;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendReviseAttendanceEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $date;
    public $employerAdminId;

    public function __construct($date,$employerAdminId)
    {
        $this->date = $date;
        $this->employerAdminId = !is_array($employerAdminId) ? [$employerAdminId] : $employerAdminId;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $data = $this->getData();
        $subject = count($data) ? 'Revised '.$data[0]['job_date'].' - '.$data[0]['employer_name'] : 'Send Revised Attendance Email';
        $excelUri = $this->toExcel($data);
        return $this->subject($subject)->from('xiaowei@hongyegroup.com.sg')->markdown('v4.employer.SendReviseAttendanceEmail')->attach($excelUri);
    }

    /**
     * 获取原始数据
     * @return array
     */
    public function getData()
    {
        $model = new Schedule();
        $between = [
            Carbon::parse($this->date)->getTimestamp(),
            Carbon::parse($this->date)->addDay()->getTimestamp(),
        ];
        $model = $model->join('job as j','job_schedules.job_id','j.job_id')
            ->join('member as m','job_schedules.member_id','m.member_id')
            ->where('job_schedules.is_send',1)
            ->whereIn('j.job_employer_admin_id',$this->employerAdminId)
            ->whereBetween('j.job_start_date', $between);
        $data = $model->get(['job_schedules.s_id', 'm.member_id', 'm.member_name', 'm.member_sex','m.member_nric','m.member_mobile',
                             'job_schedules.checkin_time', 'job_schedules.checkout_time','job_schedules.adjusted_checkin_time',
                             'job_schedules.adjusted_checkout_time',
                             'job_schedules.work_hours', 'job_schedules.adjusted_work_minutes','job_schedules.parent_id','job_schedules.employer_remark',
                             'j.job_id','j.job_start_date', 'j.job_end_date','j.job_employer_company_name', 'j.job_employer_admin_id','j.employer_status','j.confirm_signature'
        ]);
        
        return $this->present($data);
    }

    /**
     * 格式化原始数据
     * @param $data
     *
     * @return array
     */
    public function present($data)
    {
        $dataArray = [];
        $scheduleModel = new Schedule();
        $removes = [];
        $originDataArray = $data->toArray();
        foreach ($data as $dataKey => $dataValue) {
            $dataArray[$dataKey]['s_id']                   = $dataValue['s_id'];
            $dataArray[$dataKey]['parent_id']              = $dataValue['parent_id'];
            $dataArray[$dataKey]['member_id']              = $dataValue['member_id'];
            $dataArray[$dataKey]['job_employer_admin_id']  = $dataValue['job_employer_admin_id'];
            $dataArray[$dataKey]['employer_name']          = $dataValue['job_employer_company_name'];
            $dataArray[$dataKey]['member_name']            = $dataValue['member_name'];
            $dataArray[$dataKey]['member_nric']            = $dataValue['member_nric'];
            $dataArray[$dataKey]['member_sex']             = $dataValue['member_sex'] == 1 ? 'M' : 'F';
            $dataArray[$dataKey]['member_mobile']          = ' '.$dataValue['member_mobile'];
            $dataArray[$dataKey]['adjusted_checkin_time']  = $dataValue['adjusted_checkin_time'] ? Carbon::createFromTimestamp($dataValue['adjusted_checkin_time'])->format('H:i') : '';
            $dataArray[$dataKey]['checkin_time']           = $dataValue['checkin_time'] ? Carbon::createFromTimestamp($dataValue['checkin_time'])->format('H:i') : '';
            $dataArray[$dataKey]['adjusted_checkout_time'] = $dataValue['adjusted_checkout_time'] ? Carbon::createFromTimestamp($dataValue['adjusted_checkout_time'])->format('H:i') : '';
            $dataArray[$dataKey]['checkout_time']          = $dataValue['checkout_time'] ? Carbon::createFromTimestamp($dataValue['checkout_time'])->format('H:i') : '';
            if ($dataValue['adjusted_work_minutes'] == 0){
                $dataArray[$dataKey]['hours'] = 0;
                $dataArray[$dataKey]['total'] = 0;
            }else{
                $originMinutes = $scheduleModel->getWorkMinutes($dataValue['adjusted_checkin_time'],$dataValue['adjusted_checkout_time']) * 60;
                $dataArray[$dataKey]['total'] = round($dataValue['adjusted_work_minutes'] / 60,2);
                $dataArray[$dataKey]['hours'] = round(($dataValue['adjusted_work_minutes'] - $originMinutes) / 60 ,2);
            }

            $dataArray[$dataKey]['remark']                = $dataValue['employer_remark'];
            $dataArray[$dataKey]['job_date']              = Carbon::createFromTimestamp($dataValue['job_start_date'])->format('d M Y');

            //查找是否有旧数据
            if ($dataValue['parent_id'] != 0){
                $removes[] = $dataValue['parent_id'];
                foreach ($originDataArray as $item) {
                    if ($dataValue['job_id'] == $item['job_id']
                        && $item['member_id'] == $dataValue['member_id']
                        && $item['s_id'] != $dataValue['s_id']
                        && $item['s_id'] < $dataValue['s_id']
                    ) {
                        $removes[] = $item['s_id'];
                    }
                }
            }
        }

        //去除旧数据
        foreach ((array)$dataArray as $key => $value) {
            if (in_array($value['s_id'],$removes)){
                unset($dataArray[$key]);
            }
        }

        sort($dataArray);

        return $dataArray;
    }

    /**
     * 返回Excel地址
     * @param $data
     *
     * @return string
     */
    public function toExcel($data)
    {
        $cellData = [
            ['No. of Staff Applied List'],
            ['Employer','Job Date','Name','NRIC','Gender','Mobile Phone','Start Time','Time In','End Time','Time Out','+/- Hours','Total Hours','Remark']];
        $hasParent = [];
        foreach ($data as $key=>$value) {
            $lineData = [$value['employer_name'], $value['job_date'], $value['member_name'], $value['member_nric'], $value['member_sex'], $value['member_mobile'], $value['adjusted_checkin_time'], $value['checkin_time'], $value['adjusted_checkout_time'], $value['checkout_time'], $value['hours'], $value['total'], $value['remark']];
            $hasParent[$key+3] = $value['parent_id'];
            array_push($cellData,$lineData);
        }
        
        $fileName = 'No. of Staff Applied List-'.time();
        Excel::create($fileName,function($excel)use($cellData,$hasParent){
            $excel->sheet('list', function($sheet) use ($cellData,$hasParent){
                $i = 1;
                $sheet->mergeCells('A1:M1');
                $sheet->setStyle(array('font' => array('name' => 'Calibri', 'size' => 12, 'bold' => false)));
                foreach ((array)$cellData as $record) {
                    $j = 'A';
                    foreach($record as $key=>$value) {
                        $sheet->cell($j.$i, function($cell) use ($key,$value,$i,$j,$hasParent) {
                            $cell->setValue($value);
                            $cell->setAlignment('center');
                            if ($key == 0 & $i == 1){$cell->setFontSize(20);}
                            if ($i > 2 && $hasParent[$i] > 0){$cell->setFontColor('#FF0000');}
                        });
                        $j++;
                    }
                    $i++;
                }
            });
        })->store('xls',storage_path('excel/confirm_attendance'));
        return storage_path('excel/confirm_attendance'.'/'.$fileName.'.xls');
    }
}
