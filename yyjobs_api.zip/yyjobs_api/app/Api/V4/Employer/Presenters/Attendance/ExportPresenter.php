<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/3
 * Time: 15:05
 */

namespace App\Api\V4\Employer\Presenters\Attendance;

use App\Api\V4\Employer\Entities\Schedule;
use Carbon\Carbon;
use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Employer\Transformers\Attendance\TodayTransformer;

class ExportPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        //return new TodayTransformer();
        return null;
    }

    public function present($data)
    {
        $dataArray = [];
        $scheduleModel = new Schedule();
        $removes = [];
        foreach ($data as $key => $value) {
            foreach ($data as $k => $v) {
                if ($v->job_id == $value->job_id && $v->member_id == $value->member_id && $v->s_id < $value->s_id){
                    $removes[] = $v->s_id;
                }
            }
        }
        $removes = array_unique($removes);
        foreach ($data as $dataKey => $dataValue) {
            if (in_array($dataValue->s_id,$removes)){continue;}
            $dataArray[$dataKey]['s_id']                   = $dataValue['s_id'];
            $dataArray[$dataKey]['member_id']              = $dataValue['member_id'];
            $dataArray[$dataKey]['member_name']            = strtoupper($dataValue['member_name']);
            $dataArray[$dataKey]['member_nric']            = strtoupper($dataValue['member_nric']);
            $dataArray[$dataKey]['member_sex']             = $dataValue['member_sex'] == 1 ? 'M' : 'F';
            $dataArray[$dataKey]['adjusted_checkin_time']  = $dataValue['adjusted_checkin_time'];
            $dataArray[$dataKey]['adjusted_checkout_time'] = $dataValue['adjusted_checkout_time'];
            $dataArray[$dataKey]['checkin_time']           = $dataValue['checkin_time'];
            $dataArray[$dataKey]['checkin_time']           = Carbon::createFromTimestamp($dataValue['checkin_time'])->format('H:i');
            $dataArray[$dataKey]['checkout_time']          = $dataValue['checkout_time'];
            $dataArray[$dataKey]['checkout_time']          = Carbon::createFromTimestamp($dataValue['checkout_time'])->format('H:i');
            $dataArray[$dataKey]['checkin_signature']      = $dataValue['checkin_signature'];
            $dataArray[$dataKey]['checkout_signature']     = $dataValue['checkout_signature'];
            if ($dataValue['adjusted_work_minutes'] == 0){
                $dataArray[$dataKey]['hours'] = 0;
                $dataArray[$dataKey]['total'] = 0;
            }else{
                $originMinutes = $scheduleModel->getWorkMinutes($dataArray[$dataKey]['adjusted_checkin_time'],$dataArray[$dataKey]['adjusted_checkout_time']) * 60;
                $dataArray[$dataKey]['total'] = round($dataValue['adjusted_work_minutes'] / 60,2);
                $dataArray[$dataKey]['hours'] = round(($dataValue['adjusted_work_minutes'] - $originMinutes) / 60 ,2);
            }
            $dataArray[$dataKey]['adjusted_checkin_time']  = Carbon::createFromTimestamp($dataValue['adjusted_checkin_time'])->format('H:i');
            $dataArray[$dataKey]['adjusted_checkout_time'] = Carbon::createFromTimestamp($dataValue['adjusted_checkout_time'])->format('H:i');
            $dataArray[$dataKey]['remark']                 = $dataValue['employer_remark'];
            $dataArray[$dataKey]['employer_name']          = $dataValue['job_employer_company_name'];
            $dataArray[$dataKey]['job_title']              = $dataValue['job_title'];
            $dataArray[$dataKey]['job_address']            = $dataValue['job_address'];
            $dataArray[$dataKey]['job_date']               = Carbon::createFromTimestamp($dataValue['job_start_date'])->format('d/m/Y');
            $dataArray[$dataKey]['confirm_signature']      = $dataValue['confirm_signature'];
        }

        sort($dataArray);

        return $dataArray;
    }
}