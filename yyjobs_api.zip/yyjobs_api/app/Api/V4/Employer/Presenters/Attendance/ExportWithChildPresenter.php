<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/3
 * Time: 15:05
 */

namespace App\Api\V4\Employer\Presenters\Attendance;

use App\Api\V4\Employer\Entities\Schedule;
use Carbon\Carbon;
use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Employer\Transformers\Attendance\TodayTransformer;

class ExportWithChildPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        //return new TodayTransformer();
        return null;
    }

    public function present($data)
    {
        $data = $this->sortByLevel($data->toArray());
        $result = [];
        $model = new Schedule();
        foreach ($data as $key => $value) {
            if ($value['adjusted_work_minutes'] != 0){
                $originMinutes = $model->getWorkMinutes($value['adjusted_checkin_time'],$value['adjusted_checkout_time']) * 60;
                $total = round($value['adjusted_work_minutes']/ 60,2);
                $hours = round(($value['adjusted_work_minutes']- $originMinutes) / 60,2);
            }else{
                $total = $hours = 0;
            }

            $checkin = $value['checkin_time'] ? Carbon::createFromTimestamp($value['checkin_time'])->format('H:i') : '';
            $checkOut = $value['checkout_time'] ? Carbon::createFromTimestamp($value['checkout_time'])->format('H:i') : '';

            $result[$key]['s_id']                   = $value['s_id'];
            $result[$key]['member_id']              = $value['member_id'];
            $result[$key]['member_name']            = strtoupper($value['member_name']);
            $result[$key]['member_nric']            = strtoupper($value['member_nric']);
            $result[$key]['member_sex']             = $value['member_sex'] == 1 ? 'M' : 'F';
            $result[$key]['employer_name']          = $value['job_employer_company_name'];
            $result[$key]['job_title']              = $value['job_title'];
            $result[$key]['job_address']            = $value['job_address'];
            $result[$key]['job_date']               = Carbon::createFromTimestamp($value['job_start_date'])->format('M/d/Y');
            $result[$key]['checkin_time']           = $checkin;
            $result[$key]['checkout_time']          = $checkOut;
            $result[$key]['checkin_signature']      = $value['checkin_signature'];
            $result[$key]['checkout_signature']     = $value['checkout_signature'];
            $result[$key]['adjusted_checkin_time']  = Carbon::createFromTimestamp($value['adjusted_checkin_time'])->format('H:i');
            $result[$key]['adjusted_checkout_time'] = Carbon::createFromTimestamp($value['adjusted_checkout_time'])->format('H:i');
            if ($value['parent_id'] == 0){
                $result[$key]['hours'] = $hours;
                $result[$key]['total'] = $total;
            }else{
                $thanPre = $total - $result[$key-1]['origin_total'];
                $result[$key]['hours'] = 0;
                $result[$key]['total'] = $thanPre > 0 ? '+'.$thanPre : $thanPre;
            }
            $result[$key]['confirm_signature']  = $value['confirm_signature'];
            $result[$key]['origin_total']       = $total;
            $result[$key]['remark']             = $value['employer_remark'];
            $result[$key]['parent_id']          = $value['parent_id'];
            $result[$key]['revise_version']     = $value['revise_version'];
            $result[$key]['update_time']        = $value['update_time'];
        }
        /*echo '<pre>';
        print_r($result);
        die;*/
        return $result;
    }

    /**
     * 根据主副数据进行排序
     * @param array $data
     * @param int   $id
     * @param array $arr
     *
     * @return array
     */
    public function sortByLevel(array $data, $id = 0, &$arr = [])
    {
        foreach ($data as $v) {
            if ($id == $v['parent_id']) {
                $arr[] = $v;
                $this->sortByLevel($data, $v['s_id'], $arr);
            }
        }
        return $arr;
    }
}