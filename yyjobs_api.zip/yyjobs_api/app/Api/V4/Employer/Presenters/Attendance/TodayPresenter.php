<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/17
 * Time: 14:58
 */

namespace App\Api\V4\Employer\Presenters\Attendance;

use App\Api\V4\Employer\Entities\Schedule;
use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Employer\Transformers\Attendance\TodayTransformer;

class TodayPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        //return new TodayTransformer();
        return null;
    }

    public function present($data)
    {
        $dataArray = [];
        $scheduleModel = new Schedule();
        $removes = [];
        $originDataArray = $data->toArray();
        foreach ($data as $dataKey => $dataValue) {
            $dataArray[$dataKey]['s_id']                   = $dataValue['s_id'];
            $dataArray[$dataKey]['member_id']              = $dataValue['member_id'];
            $dataArray[$dataKey]['member_name']            = $dataValue['member_name'];
            $dataArray[$dataKey]['member_sex']             = $dataValue['member_sex'];
            $dataArray[$dataKey]['member_nric']            = $dataValue['member_nric'];
            $dataArray[$dataKey]['member_avatar']          = $dataValue['member_avatar'];
            $dataArray[$dataKey]['member_birthday']        = $dataValue['member_birthday'];
            $dataArray[$dataKey]['checkin_time']           = $dataValue['checkin_time'];
            $dataArray[$dataKey]['adjusted_checkin_time']  = $dataValue['adjusted_checkin_time'];
            $dataArray[$dataKey]['checkout_time']          = $dataValue['checkout_time'];
            $dataArray[$dataKey]['adjusted_checkout_time'] = $dataValue['adjusted_checkout_time'];
            $dataArray[$dataKey]['checkin_signature']      = $dataValue['checkin_signature'];
            $dataArray[$dataKey]['checkout_signature']     = $dataValue['checkout_signature'];
            if ($dataValue['adjusted_work_minutes'] == 0){
                $dataArray[$dataKey]['hours'] = 0;
                $dataArray[$dataKey]['total'] = 0;
            }else{
                $originMinutes = $scheduleModel->getWorkMinutes($dataArray[$dataKey]['adjusted_checkin_time'],$dataArray[$dataKey]['adjusted_checkout_time']) * 60;
                $dataArray[$dataKey]['total'] = round($dataValue['adjusted_work_minutes'] / 60,2);
                $dataArray[$dataKey]['hours'] = round(($dataValue['adjusted_work_minutes'] - $originMinutes) / 60 ,2);
            }
            if ($dataValue['checkin_time'] && !$dataValue['checkout_time']){
                $dataArray[$dataKey]['total'] = 0;
                $dataArray[$dataKey]['hours'] = $dataValue['extra_work_minutes'] / 60;
            }

            $dataArray[$dataKey]['remark']                = $dataValue['employer_remark'];
            $dataArray[$dataKey]['job_start_date']        = $dataValue['job_start_date'];
            $dataArray[$dataKey]['job_end_date']          = $dataValue['job_end_date'];
            $dataArray[$dataKey]['job_employer_admin_id'] = $dataValue['job_employer_admin_id'];
            $dataArray[$dataKey]['employer_status']       = $dataValue['employer_status'];
            $dataArray[$dataKey]['confirm_signature']     = $dataValue['confirm_signature'];
            $dataArray[$dataKey]['times_job'] = $scheduleModel->join('job as j', 'job_schedules.job_id', 'j.job_id')
                                                ->where('job_schedules.member_id', $dataValue['member_id'])
                                                ->where('j.job_employer_admin_id', $dataValue['job_employer_admin_id'])
                                                ->where('job_schedules.parent_id',0)
                                                ->whereIn('job_schedules.work_status', [6, 8])->count();

            //查找是否有旧数据
            if ($dataValue['parent_id'] != 0){
                $removes[] = $dataValue['parent_id'];
                foreach ($originDataArray as $item) {
                    if ($dataValue['job_id'] == $item['job_id']
                        && $item['member_id'] == $dataValue['member_id']
                        && $item['s_id'] != $dataValue['s_id']
                        && $item['s_id'] < $dataValue['s_id']
                    ) {
                        $removes[] = $item['s_id'];
                    }
                }
            }
        }
        
        //去除旧数据
        foreach ((array)$dataArray as $key => $value) {
            if (in_array($value['s_id'],$removes)){
                unset($dataArray[$key]);
            }
        }
        sort($dataArray);

        return $dataArray;
    }

    public function present_bak2($data)
    {
        $dataArray = [];
        $scheduleModel = new Schedule();
        $removes = [];
        foreach ($data as $dataKey => $dataValue) {
            $dataArray[$dataKey]['s_id']                   = $dataValue['s_id'];
            $dataArray[$dataKey]['member_id']              = $dataValue['member_id'];
            $dataArray[$dataKey]['member_name']            = $dataValue['member_name'];
            $dataArray[$dataKey]['member_sex']             = $dataValue['member_sex'];
            $dataArray[$dataKey]['member_nric']            = $dataValue['member_nric'];
            $dataArray[$dataKey]['checkin_time']           = $dataValue['checkin_time'];
            $dataArray[$dataKey]['adjusted_checkin_time']  = $dataValue['adjusted_checkin_time'];
            $dataArray[$dataKey]['checkout_time']          = $dataValue['checkout_time'];
            $dataArray[$dataKey]['adjusted_checkout_time'] = $dataValue['adjusted_checkout_time'];
            $dataArray[$dataKey]['checkin_signature']      = $dataValue['checkin_signature'];
            $dataArray[$dataKey]['checkout_signature']     = $dataValue['checkout_signature'];
            if ($dataValue['adjusted_work_minutes'] == 0){
                $dataArray[$dataKey]['hours'] = 0;
                $dataArray[$dataKey]['total'] = 0;
            }else{
                $originMinutes = $scheduleModel->getWorkMinutes($dataArray[$dataKey]['adjusted_checkin_time'],$dataArray[$dataKey]['adjusted_checkout_time']) * 60;
                $dataArray[$dataKey]['total'] = round($dataValue['adjusted_work_minutes'] / 60,2);
                $dataArray[$dataKey]['hours'] = round(($dataValue['adjusted_work_minutes'] - $originMinutes) / 60 ,2);
            }

            $dataArray[$dataKey]['remark']                = $dataValue['employer_remark'];
            $dataArray[$dataKey]['job_start_date']        = $dataValue['job_start_date'];
            $dataArray[$dataKey]['job_end_date']          = $dataValue['job_end_date'];
            $dataArray[$dataKey]['job_employer_admin_id'] = $dataValue['job_employer_admin_id'];
            $dataArray[$dataKey]['employer_status']       = $dataValue['employer_status'];
            $dataArray[$dataKey]['confirm_signature']     = $dataValue['confirm_signature'];

            //查找是否有旧数据
            if ($dataValue['parent_id'] != 0){
                $removes[] = $dataValue['parent_id'];
            }
        }

        //去除旧数据
        foreach ((array)$dataArray as $key => $value) {
            if (in_array($value['s_id'],$removes)){
                unset($dataArray[$key]);
            }
        }
        sort($dataArray);
        
        return $dataArray;
    }

    public function present_bak($data)
    {
        $dataArray = [];
        $scheduleModel = new Schedule();
        $removes = [];
        foreach ($data as $dataKey => $dataValue) {
            $dataArray[$dataKey]['s_id']                  = $dataValue['s_id'];
            $dataArray[$dataKey]['member_id']             = $dataValue['member_id'];
            $dataArray[$dataKey]['member_name']           = $dataValue['member_name'];
            $dataArray[$dataKey]['member_sex']            = $dataValue['member_sex'];
            $dataArray[$dataKey]['member_nric']           = $dataValue['member_nric'];

            $dataArray[$dataKey]['checkin']               = $dataValue['adjusted_checkin_time'] != 0
                ? $dataValue['adjusted_checkin_time']
                : $dataValue['checkin_time'];

            $dataArray[$dataKey]['checkout']              = $dataValue['adjusted_checkout_time'] != 0
                ? $dataValue['adjusted_checkout_time']
                : $dataValue['checkout_time'];

            $dataArray[$dataKey]['checkin_signature']     = $dataValue['checkin_signature'];
            $dataArray[$dataKey]['checkout_signature']    = $dataValue['checkout_signature'];

            $origin = $scheduleModel->getWorkMinutes($dataArray[$dataKey]['checkin'],$dataArray[$dataKey]['checkout']) * 60;

            $dataArray[$dataKey]['hours']                 = $dataValue['adjusted_work_minutes'] != 0
                ? ($dataValue['adjusted_work_minutes'] - $origin) / 60
                : ($dataValue['work_hours'] - $origin) / 60;

            $dataArray[$dataKey]['total']                 = $dataValue['adjusted_work_minutes'] != 0
                ? $dataValue['adjusted_work_minutes'] / 60
                : $dataValue['work_hours'] / 60;

            $dataArray[$dataKey]['remark']                = $dataValue['employer_remark'];
            $dataArray[$dataKey]['job_start_date']        = $dataValue['job_start_date'];
            $dataArray[$dataKey]['job_end_date']          = $dataValue['job_end_date'];
            $dataArray[$dataKey]['job_employer_admin_id'] = $dataValue['job_employer_admin_id'];
            $dataArray[$dataKey]['employer_status']       = $dataValue['employer_status'];
            $dataArray[$dataKey]['confirm_signature']     = $dataValue['confirm_signature'];

            //查找是否有旧数据
            if ($dataValue['parent_id'] != 0){
                $removes[] = $dataValue['parent_id'];
            }
        }

        //去除旧数据
        foreach ((array)$dataArray as $key => $value) {
            if (in_array($value['s_id'],$removes)){
                unset($dataArray[$key]);
            }
        }
        sort($dataArray);

        return $dataArray;
    }
}