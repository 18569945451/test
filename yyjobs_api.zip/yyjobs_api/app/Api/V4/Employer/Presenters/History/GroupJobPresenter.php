<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/20
 * Time: 14:07
 */

namespace App\Api\V4\Employer\Presenters\History;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Employer\Transformers\Attendance\TodayTransformer;

class GroupJobPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        //return new TodayTransformer();
        return null;
    }

    public function present($data)
    {
        $returnData = [];
        foreach ($data as $key => $value) {
            echo '<pre>';
            print_r($value->toArray());
            die;
        }
    }
}