<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/13
 * Time: 15:10
 */

namespace App\Api\V4\Employer\Presenters\Requisition;

use Carbon\Carbon;
use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Employer\Transformers\Requisition\DateLimitTransformer;

class DateLimitPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return null;
    }

    /**
     * Prepare data to present
     *
     * @param $data
     *
     * @return array
     */
    public function present($data)
    {
        $dataArray = null;
        foreach ($data as $dataKey=>$dataValue) {
            $key = Carbon::parse($dataValue->job_start)->format('Y-m-d');
            $dataArray[$key][] = $dataValue->toArray();
        }

        return $dataArray;
    }
}