<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/13
 * Time: 15:10
 */

namespace App\Api\V4\Employer\Presenters\Employee;

use Prettus\Repository\Presenter\FractalPresenter;

class SinglePresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return null;
    }

    /**
     * Prepare data to present
     *
     * @param $data
     *
     * @return array
     */
    public function present($data)
    {
        return $data[0]->toArray();
    }
}