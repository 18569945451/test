<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/24
 * Time: 16:30
 */

namespace App\Api\V4\Employer\Presenters\Job;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Employer\Transformers\Job\FutureDetailTransformer;

class FutureDetailPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new FutureDetailTransformer();
    }
}