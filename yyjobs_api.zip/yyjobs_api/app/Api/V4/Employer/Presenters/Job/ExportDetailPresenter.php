<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/25
 * Time: 15:32
 */

namespace App\Api\V4\Employer\Presenters\Job;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Employer\Transformers\Job\ExportDetailTransformer;

class ExportDetailPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new ExportDetailTransformer();
    }
}