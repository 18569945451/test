<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 13:58
 */

namespace App\Api\V4\Employer\Presenters\Job;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Employer\Transformers\Job\TodayTransformer;

class TodayPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new TodayTransformer();
    }
}