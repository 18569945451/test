<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/17
 * Time: 14:59
 */

namespace App\Api\V4\Employer\Transformers\Attendance;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;
use App\Api\V4\Employer\Entities\Schedule;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class TodayTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Employer\Entities\Schedule $model
     *
     * @return array
     */
    public function transform(Schedule $model)
    {
        return $model->toArray();
        /*
        return [
            'job_id'         => (int)$model->job_id,
            'job_start' => Carbon::createFromTimestamp($model->job_start_date)->format('H:i'),
            'job_end'  => Carbon::createFromTimestamp($model->job_end_date)->format('H:i'),
        ];
        */
    }
}