<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/5/22
 * Time: 22:55
 */

namespace App\Api\V4\Employer\Transformers;

use League\Fractal\TransformerAbstract;
use App\Api\V4\Employer\Entities\Admin;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ProfileTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Employer\Entities\Admin $model
     *
     * @return array
     */
    public function transform(Admin $model)
    {
        return [
            'id'    => (int)$model->id,
            'name'  => $model->name,
            'logo'  => $model->employer->e_company_logo,
            'email' => $model->email,
            'contact_no' => $model->employer->e_contact_no,
            'password' => '123456789',
            'industry_id'=>$model->employer->industry->industry_id,
            'industry_name'=>$model->employer->industry->industry_name,
        ];
    }
}