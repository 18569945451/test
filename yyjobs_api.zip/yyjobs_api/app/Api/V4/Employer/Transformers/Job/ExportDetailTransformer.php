<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/25
 * Time: 15:32
 */

namespace App\Api\V4\Employer\Transformers\Job;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;
use App\Api\V4\Employer\Entities\Job;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ExportDetailTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Employer\Entities\Job $model
     *
     * @return array
     */
    public function transform(Job $model)
    {
        return [
            'member_name'            => strtoupper($model->member_name),
            'member_nric'            => strtoupper($model->member_nric),
            'member_sex'             => $model->member_sex == 1 ? 'M' : 'F',
            'adjusted_checkin_time'  => Carbon::createFromTimestamp($model->adjusted_checkin_time)->format('H:i'),
            'checkin_time'           => $model->checkin_time ? $model->checkin_time : '',
            'adjusted_checkout_time' => Carbon::createFromTimestamp($model->adjusted_checkout_time)->format('H:i'),
            'checkout_time'          => $model->checkout_time ? $model->checkout_time : '',
        ];
        return $model->toArray();
    }
}