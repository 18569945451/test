<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/24
 * Time: 16:31
 */

namespace App\Api\V4\Employer\Transformers\Job;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;
use App\Api\V4\Employer\Entities\Job;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class FutureDetailTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Employer\Entities\Job $model
     *
     * @return array
     */
    public function transform(Job $model)
    {
        return $model->toArray();
    }
}