<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/13
 * Time: 15:11
 */

namespace App\Api\V4\Employer\Transformers\Requisition;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;
use App\Api\V4\Employer\Entities\LabourRequisition;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class DateLimitTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Employer\Entities\LabourRequisition $model
     *
     * @return array
     */
    public function transform(LabourRequisition $model)
    {
        return [
            'id'        => (int)$model->id,
            'job_date'  => Carbon::parse($model->job_start)->format('D,d/m/Y'),
            'job_start' => Carbon::parse($model->job_start)->format('H:i'),
            'job_end'   => Carbon::parse($model->job_end)->format('H:i'),
            'job_title' => $model->job_title,
            'need_num'  => $model->need_num,
            'status'    => $model->status,
        ];
    }
}