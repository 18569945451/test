<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/16
 * Time: 14:15
 */

namespace App\Api\V4\Employer\Criteria\Schedules;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;
use App\Api\V4\Employer\Repositories\RequisitionRepository;

class GroupJobCriteria implements CriteriaInterface
{
    public function apply($model,RepositoryInterface $repository)
    {
        $requisitionRep   = app(RequisitionRepository::class);
        $employerAdminIds = $requisitionRep->getEmployerAdminIds(request('employer_admin_id'));

        $startDate = request('start_date', 0);
        $endDate   = request('end_date', 0);
        $hasDate   = !!($startDate && $endDate);

        $curPage  = request('cur_page', 1);
        $pageSize = request('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $status = request('employer_status');

        return $model->select(\DB::raw("count(*) AS total, GROUP_CONCAT(j.job_id) AS job_id, GROUP_CONCAT(FROM_UNIXTIME(j.job_start_date, '%Y%m%d')) as days, j.job_employer_admin_id"))
            ->join('job as j','job_schedules.job_id','j.job_id')
            ->where('job_schedules.parent_id',0)
            ->where('job_schedules.is_send',1)
            ->whereIn('j.job_employer_admin_id',$employerAdminIds)
            ->when($hasDate,function($query)use($startDate,$endDate){
                $between = [
                    Carbon::parse($startDate)->getTimestamp(),
                    Carbon::parse($endDate)->addDay()->getTimestamp(),
                ];
                return $query->whereBetween('j.job_start_date',$between);
            },function ($query){
                return $query->where('j.job_start_date','<',Carbon::today()->addDay()->getTimestamp());
            })
            ->when($status,function($query)use($status){
                return $query->where('j.employer_status',$status);
            })
            ->groupBy('j.job_employer_admin_id')
            ->orderBy('j.job_start_date','DESC')->offset($offset)->limit($pageSize);
    }
}