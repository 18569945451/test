<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/24
 * Time: 14:57
 */

namespace App\Api\V4\Employer\Criteria\Job;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;
use App\Api\V4\Employer\Repositories\RequisitionRepository;

class GroupCriteria implements CriteriaInterface
{
    public function apply($model,RepositoryInterface $repository)
    {
        $requisitionRep   = app(RequisitionRepository::class);
        $employerAdminIds = $requisitionRep->getEmployerAdminIds(request('employer_admin_id'));

        $startDate = request('start_date', 0);
        $endDate   = request('end_date', 0);
        $hasDate   = !!($startDate && $endDate);

        $curPage  = request('cur_page', 1);
        $pageSize = request('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $status = request('status');

        $selectRaw = "FROM_UNIXTIME(job_start_date,'%Y%m%d') as days,group_concat(job_id) as job_ids";

        return $model->selectRaw($selectRaw)->when($hasDate,function($query)use($startDate,$endDate){

            $between = [
                Carbon::parse($startDate)->getTimestamp(),
                Carbon::parse($endDate)->addDay()->getTimestamp(),
            ];

            return $query->whereBetween('job_start_date',$between);

        },function($query){

            return $query->where('job_start_date','>',Carbon::tomorrow()->getTimestamp());

        })->when($employerAdminIds,function ($query)use($employerAdminIds){

            return $query->whereIn('job_employer_admin_id',$employerAdminIds);

        })->when($status,function($query)use($status){

            return $query->where('employer_status',$status);

        })->groupBy('days')->orderBy('job_start_date','ASC')->offset($offset)->limit($pageSize);
    }
}