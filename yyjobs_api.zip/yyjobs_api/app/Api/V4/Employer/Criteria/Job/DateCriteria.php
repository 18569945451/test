<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/24
 * Time: 16:14
 */

namespace App\Api\V4\Employer\Criteria\Job;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;
use App\Api\V4\Employer\Repositories\RequisitionRepository;

class DateCriteria implements CriteriaInterface
{
    public function apply($model,RepositoryInterface $repository)
    {
        $requisitionRep = app(RequisitionRepository::class);

        $employerAdminIds = $requisitionRep->getEmployerAdminIds(request('employer_admin_id'));

        $between = [
            Carbon::parse(request('date'))->getTimestamp(),
            Carbon::parse(request('date'))->addDay()->getTimestamp(),
        ];

        return $model->join('job_schedules as js','job.job_id','js.job_id')
            ->join('member as m','js.member_id','m.member_id')
            ->where('js.is_send',1)
            ->whereIn('job.job_employer_admin_id',$employerAdminIds)
            ->whereBetween('job.job_start_date', $between);
    }
}