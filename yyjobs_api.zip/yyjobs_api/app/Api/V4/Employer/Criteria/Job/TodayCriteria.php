<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 13:57
 */

namespace App\Api\V4\Employer\Criteria\Job;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class TodayCriteria implements CriteriaInterface
{
    public function apply($model,RepositoryInterface $repository)
    {
        if ($date = request('date')){
            $between = [Carbon::parse($date)->getTimestamp(), Carbon::parse($date)->addDay()->getTimestamp()];
        }else{
            $between = [Carbon::today()->getTimestamp(), Carbon::tomorrow()->getTimestamp()];
        }
        $employerStatus  = request('employer_status', 1);
        $employerSymbols = $employerStatus > 1 ? '>' : '=';
        return $model->whereBetween('job_start_date', $between)
                     ->where('job_status',4)
                     ->where('employer_status',$employerSymbols,1)
                     ->orderBy('job_start_date','asc');
    }
}