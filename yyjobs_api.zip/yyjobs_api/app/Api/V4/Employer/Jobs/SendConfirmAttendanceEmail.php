<?php

namespace App\Api\V4\Employer\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SendConfirmAttendanceEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $date;
    public $employerAdminId;

    public function __construct($date,$employerAdminId)
    {
        $this->date = $date;
        $this->employerAdminId = $employerAdminId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        //\Mail::to('xueying@hongyegroup.com.sg')->cc('account@hongyegroup.com.sg')->send(new \App\Api\V4\Employer\Mail\SendConfirmAttendanceEmail($this->date,$this->employerAdminId));
        \Mail::to('account@hongyegroup.com.sg')->send(new \App\Api\V4\Employer\Mail\SendConfirmAttendanceEmail($this->date,$this->employerAdminId));
    }
}
