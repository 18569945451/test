<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/4
 * Time: 14:36
 */

namespace App\Api\V4\Employer\Repositories;

use App\Api\V4\Employer\Entities\Admin;
use Prettus\Repository\Eloquent\BaseRepository;


class ProfileRepository extends BaseRepository
{
    public function model()
    {
        return Admin::class;
    }

    /**
     * @param $id
     *
     * @return mixed
     */
    public function profile($id)
    {
        return $this->with('employer')->find($id);
    }

    /**
     * @param int    $id
     * @param string $registration
     *
     * @return mixed
     */
    public function registration(int $id,string $registration)
    {
        return (int)!!$this->update(['registration_id'=>$registration],$id);
    }

    /**
     * @param $employer
     * @param $newPasswd
     *
     * @return mixed
     */
    public function setPassword($employer, $newPasswd)
    {
        return $this->update(['password' => bcrypt($newPasswd)], $employer->id);
    }

}