<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/20
 * Time: 11:46
 */

namespace App\Api\V4\Employer\Repositories;

use App\Api\V4\Employer\Entities\Job;
use Prettus\Repository\Eloquent\BaseRepository;


class HistoryRepository extends BaseRepository
{
    public function model()
    {
        return Job::class;
    }

    /**
     * @return array
     */
    public function historyList()
    {
        $result = $this->all();
        $jobIds = [];

        foreach ($result->toArray() as $item) {
            $ids = explode(',',$item['job_ids']);
            $jobIds = array_merge($jobIds,$ids);
        }

        $data    = $this->model->withCount(['schedules'=>function($query){return $query->where('parent_id',0)->where('is_send',1);}])->whereIn('job_id', $jobIds)->get();
        
        $jobData = [];
        foreach ($data as $jobKey => $jobValue) {
            $dateKey = date('Ymd', $jobValue->job_start_date);
            $jobData[$dateKey][] = $jobValue->toArray();
        }

        $returnData = [];
        $status     = [];
        foreach ($jobData as $k=> $v) {
            foreach ($v as $key => $value) {
                $employerKey                = $value['job_employer_admin_id'];
                $status[$k][$employerKey][] = $value['employer_status'];

                $returnData[$k][$employerKey]['date']              = $k;
                $returnData[$k][$employerKey]['num']               = isset($returnData[$k][$employerKey]['num']) ? $value['schedules_count'] + $returnData[$k][$employerKey]['num'] : $value['schedules_count'];
                $returnData[$k][$employerKey]['employer_admin_id'] = $value['job_employer_admin_id'];
                $returnData[$k][$employerKey]['employer']          = $value['job_employer_company_name'];
                $returnData[$k][$employerKey]['last_update_time']  = $value['job_update_time'];

                if (count($status[$k][$employerKey]) == 1){
                    $returnData[$k][$employerKey]['employer_status'] = $status[$k][$employerKey][0];
                }else{
                    if (in_array('3',$status[$k][$employerKey])){
                        $returnData[$k][$employerKey]['employer_status'] = 3;
                    }elseif(in_array('2',$status[$k][$employerKey])){
                        $returnData[$k][$employerKey]['employer_status'] = 2;
                    }else{
                        $returnData[$k][$employerKey]['employer_status'] = 1;
                    }
                }
            }
            rsort($returnData[$k]);
        }

        foreach ($returnData as $rk => $rv) {
            foreach ($rv as $k=>$v){
                if ($v['num'] <= 0){
                    unset($returnData[$rk][$k]);
                }
            }
        }

        rsort($returnData);
        return array_filter(array_values($returnData));
    }

    /*public function historyList_bak()
    {
        $result = $this->all();
        $jobIds = [];

        foreach ($result->toArray() as $item) {
            $ids = explode(',',$item['job_ids']);
            $jobIds = array_merge($jobIds,$ids);
        }

        $data       = $this->model->withCount('schedules')->whereIn('job_id', $jobIds)->get();
        $returnData = [];
        $status     = [];

        foreach ($data as $key => $value) {
            $customKey            = date('Ymd', $value->job_start_date);
            $status[$customKey][] = $value->employer_status;

            $returnData[$customKey]['date']       = $customKey;
            $returnData[$customKey]['num']        = isset($returnData[$customKey]['num'])
                ? $value->schedules_count + $returnData[$customKey]['num']
                : $value->schedules_count;

            $returnData[$customKey]['employer_admin_id']   = $value->job_employer_admin_id;
            $returnData[$customKey]['employer']            = $value->job_employer_company_name;

            if (count($status[$customKey]) == 1){
                $returnData[$customKey]['employer_status'] = $status[$customKey][0];
            }else{
                $returnData[$customKey]['employer_status'] = in_array('3',$status[$customKey]) ? 3 : 2;
            }
        }


        return $returnData;
    }*/
}