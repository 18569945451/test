<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/8/21
 * Time: 9:43
 */

namespace App\Api\V4\Employer\Repositories;

use App\Api\V4\Employer\Entities\Admin;
use App\Api\V4\Employer\Entities\RecruiterNotifications;
use Prettus\Repository\Eloquent\BaseRepository;


class RecruiterNotificationsRepository extends BaseRepository
{
    protected $model;

    public function model()
    {
        return RecruiterNotifications::class;
    }

    /**
     * 保存新Job Requisition请求通知
     * @param $recruiter
     * @param $employer
     * @param $requisition
     *
     * @return array
     */
    public function saveNewRequisition($recruiter, $employer, $requisition)
    {
        $data['type'] = 'new_requisition';
        $data['admin_id'] = $recruiter->id;
        $data['title'] = 'You have a new job request to deal with.';
        $data['content'] = "{$employer->name} has just sent you a job request. Please kindly check the details.";
        $data['data'] = json_encode(['requisition_id' => $requisition->id]);
        $data['time'] = time();
        $data['is_read'] = '0';

        if ($data) {
            $this->model->insert($data);

            return [
                'content' => $data['content'],
                'data'    => ['msg_type' => $data['type'], 'requisition_id' => $requisition->id],
            ];
        }
    }

    public function getConfirmNotifyRecruiter($jobs,$date)
    {
        $recruiterIDs = array_column($jobs,'job_recruiter_admin_id');
        $employerIDs = array_column($jobs,'job_employer_admin_id');

        $recruiters = Admin::whereIn('id',$recruiterIDs)->get(['id','registration_id'])->toArray();
        $employers = Admin::whereIn('id',$employerIDs)->get(['id','name'])->toArray();

        $recruiter = array_column($recruiters,null,'id');
        $employer = array_column($employers,null,'id');

        return [$recruiter,$employer];

    }

    /**
     * @param $recruiter
     * @param $employer
     * @param $jobID
     * @param $jobDate
     *
     * @return array
     */
    public function saveConfirmAttendanceNotify($recruiter, $employer, $jobID,$jobDate)
    {
        $data['type'] = 'employer_confirm';
        $data['admin_id'] = $recruiter['id'];
        $data['title'] = 'The job E-attendance list is confirmed by the client.';
        $data['content'] = "The job on {$jobDate} at {$employer['name']} is confirmed and the attendance is sent to YY. Please click to check the details. ";
        $data['data'] = json_encode(['job_id' => $jobID]);
        $data['time'] = time();
        $data['is_read'] = '0';
        
        if ($data) {
            $this->model->insert($data);

            return [
                'content' => $data['content'],
                'data'    => ['msg_type' => $data['type'], 'job_id' => $jobID],
            ];
        }
    }
}