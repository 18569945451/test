<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 13:37
 */

namespace App\Api\V4\Employer\Repositories;

use Excel;
use App\Api\V4\Employer\Entities\Job;
use Carbon\Carbon;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;


class JobRepository extends BaseRepository
{
    public function model()
    {
        return Job::class;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function jobsTime($request)
    {
        $this->applyCriteria();

        /*
        $requisitionRep = app(RequisitionRepository::class);
        $employerAdminIds = $requisitionRep->getEmployerAdminIds($request->employer_admin_id);
        $data = $this->model
                     ->whereIn('job_employer_admin_id',$employerAdminIds)
                     ->get(['job_id','job_start_date','job_end_date']);
        */
        $data = $this->model
            ->where('job_employer_admin_id',$request->employer_admin_id)
            ->get(['job_id','job_start_date','job_end_date']);

        return $this->parserResult($data)['data'];
    }

    /**
     * @return array
     */
    public function future()
    {
        $result = $this->all();
        $jobIds = [];

        foreach ($result->toArray() as $item) {
            $ids = explode(',',$item['job_ids']);
            $jobIds = array_merge($jobIds,$ids);
        }

        $data       = $this->model->withCount(['schedules'=>function($query){
                                        return $query->where('is_send',1);
                                    }])->whereIn('job_id', $jobIds)->get();
        $jobData = [];

        foreach ($data as $jobKey => $jobValue) {
            $dateKey = date('Ymd', $jobValue->job_start_date);
            $jobData[$dateKey][] = $jobValue->toArray();
        }

        $returnData = [];
        foreach ($jobData as $k=> $v) {
            foreach ($v as $key => $value) {
                $employerKey                = $value['job_employer_admin_id'];
                $status[$k][$employerKey][] = $value['employer_status'];

                $returnData[$k][$employerKey]['date']              = $k;
                $returnData[$k][$employerKey]['num']               = isset($returnData[$k][$employerKey]['num']) ? $value['schedules_count'] + $returnData[$k][$employerKey]['num'] : $value['schedules_count'];
                $returnData[$k][$employerKey]['employer_admin_id'] = $value['job_employer_admin_id'];
                $returnData[$k][$employerKey]['employer']          = $value['job_employer_company_name'];
            }
            sort($returnData[$k]);
        }

        foreach ($returnData as $rk => $rv) {
            foreach ($rv as $k=>$v){
                if ($v['num'] <= 0){
                    unset($returnData[$rk][$k]);
                }
            }
        }
        
        return array_values(array_filter($returnData));
        //return array_values($returnData);
    }

    /**
     * @return mixed
     */
    public function futureDetail()
    {
        $column = ['js.s_id','js.adjusted_checkin_time','js.adjusted_checkout_time','js.checkin_time','js.checkout_time','job.job_id', 'job.job_employer_admin_id', 'm.member_id','m.member_nric', 'm.member_name', 'm.member_sex', 'm.member_avatar','m.member_birthday','job.job_start_date', 'job.job_end_date'];
        return $this->all($column)['data'];
    }

    /**
     * 历史Attendance
     * @return array
     */
    public function histories()
    {
        $data   = $this->all()->toArray();
        if (!$data){return [];}

        $jobIds = explode(',',implode(',',array_column($data,'job_ids')));

        $jobs = $this->model->withCount(['schedules'=>function($query){
            return $query->where('parent_id',0)->where('is_send',1);
        }])->whereIn('job_id',$jobIds)->orderBy('job_start_date','DESC')->get();
        
        $returnData = [];
        foreach ($jobs as $jobKey => $jobValue) {
            $dayKey = Carbon::createFromTimestamp($jobValue->job_start_date)->format('Ymd');
            $employerKey = $jobValue->job_employer_admin_id;
            $returnData[$dayKey][$employerKey]['date']              = $dayKey;
            $returnData[$dayKey][$employerKey]['employer']          = $jobValue->job_employer_company_name;
            $returnData[$dayKey][$employerKey]['employer_admin_id'] = $jobValue->job_employer_admin_id;
            $returnData[$dayKey][$employerKey]['num']               = isset($returnData[$dayKey][$employerKey]['num'])
                ? $jobValue->schedules_count + $returnData[$dayKey][$employerKey]['num']
                : $jobValue->schedules_count;
            $returnData[$dayKey][$employerKey]['last_update_time']  = $jobValue->job_update_time;
            $returnData[$dayKey][$employerKey]['employer_status']   = $jobValue->employer_status;
        }

        foreach ($returnData as $key=>$value) {
            rsort($returnData[$key]);
        }
        krsort($returnData);

        $newData = [];
        foreach ($returnData as $value) {
            $newData[] = $value;
        }
        return $newData;
    }

    /**
     * @param array $schedules
     *
     * @return string
     * @throws ValidatorException
     */
    public function futureExport(array $schedules)
    {
        if (!$schedules){throw new ValidatorException(new MessageBag(['No data to send.']));}
        $cellData = [
            ['E-Attendance List'],
            ['Name','NRIC','Gender','Start Time','Time In','End Time','Time Out','+/- Hours','Total','Remark']];

        foreach ($schedules as $key=>$value) {
            $lineData = [$value['member_name'], $value['member_nric'], $value['member_sex'], $value['adjusted_checkin_time'], $value['checkin_time'], $value['adjusted_checkout_time'], $value['checkout_time'], 0, 0, '', '', '',];
            array_push($cellData,$lineData);
        }
        $date     = Carbon::parse(request('date'));
        $filePath = 'public/e-attendance/'.$date->format('Ym').'/'.$date->format('d').'/';
        $fileName = 'New_E-Attendance_'.request('employer_admin_id').'_'.request('date');
        $fullPath = $filePath.$fileName.'.xls';

        Excel::create($fileName,function($excel)use($cellData){
            $excel->sheet('list', function($sheet) use ($cellData){
                $i = 1;
                $sheet->mergeCells('A1:J1');
                $sheet->setStyle(array('font' => array('name' => 'Calibri', 'size' => 12, 'bold' => false)));
                foreach ((array)$cellData as $record) {
                    $j = 'A';
                    foreach($record as $key=>$value) {
                        $sheet->cell($j.$i, function($cell) use ($key,$value,$i,$j) {
                            $cell->setValue($value);
                            $cell->setAlignment('center');
                            if ($key == 0 & $i == 1){$cell->setFontSize(20);}
                        });
                        $j++;
                    }
                    $i++;
                }
            });
        })->store('xls',storage_path('app/'.$filePath));

        return generateFileUrl($fullPath);
    }
}