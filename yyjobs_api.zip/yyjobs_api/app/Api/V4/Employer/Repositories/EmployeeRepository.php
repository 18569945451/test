<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 11:16
 */

namespace App\Api\V4\Employer\Repositories;

use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V4\Employer\Entities\Member;


class EmployeeRepository extends BaseRepository
{
    public function model()
    {
        return Member::class;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function search($request)
    {
        return $this->findWhere(['member_nric' => $request->nric], ['member_id', 'member_name', 'member_sex','member_avatar','member_birthday']);
    }
}