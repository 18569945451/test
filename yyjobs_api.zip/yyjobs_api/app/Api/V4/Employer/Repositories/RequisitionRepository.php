<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/12
 * Time: 14:03
 */

namespace App\Api\V4\Employer\Repositories;

use App\Api\V4\Employer\Entities\Admin;
use App\Traits\Admin\Jpush;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V4\Employer\Entities\LabourRequisition;

class RequisitionRepository extends BaseRepository
{
    use Jpush;

    public function model()
    {
        return LabourRequisition::class;
    }

    /**
     * @param \Illuminate\Http\Request $request
     *
     * @return bool
     */
    public function add($request)
    {
        $remarkRepository = new RequisitionRemarkRepository($this->app);
        $requisitionRepository = new RecruiterNotificationsRepository($this->app);

        $remark           = $remarkRepository->insert($request);

        $employerId = $request->input('employer_admin_id');
        $remarkId   = $remark->id;
        $addTime    = Carbon::now()->toDateTimeString();

        $employer = Admin::find($employerId);
        $recruiter = Admin::whereRaw("FIND_IN_SET('{$employerId}',has_employer)")->first();
        
        foreach ($request->input('data') as $requestKey => $requestValue) {
            $date       = Carbon::parse($requestValue['date'])->format('Y-m-d');
            foreach ($requestValue['requisition'] as $key => $value) {
                $data['employer_admin_id'] = $employerId;
                $data['job_title']         = $value['job_title'];
                $data['need_num']          = $value['need_num'];
                $data['job_start']         = $date.' '.$value['start_time'];
                $data['remark_id']         = $remarkId;
                $data['add_time']          = $addTime;

                $startTimeArray = explode(':',$value['start_time']);
                if (strlen($startTimeArray[0]) != 2){
                    $value['start_time'] = '0'.$value['start_time'];
                }

                $endTimeArray = explode(':',$value['end_time']);
                if (strlen($endTimeArray[0]) != 2){
                    $value['end_time'] = '0'.$value['end_time'];
                }

                if ($value['start_time'] >= $value['end_time']) {
                    $data['job_end'] = Carbon::parse($date)
                        ->addDay()
                        ->addHours(explode(':', $value['end_time'])[0])
                        ->addMinutes(explode(':', $value['end_time'])[1])
                        ->toDateTimeString();
                } else {
                    $data['job_end'] = $date.' '.$value['end_time'];
                }

                $requisition = $this->model->create($data);
                if ($recruiter){
                    $notificationData = $requisitionRepository->saveNewRequisition($recruiter,$employer,$requisition);
                    if ($recruiter->registration_id != ''){
                        $this->notifyNewRequisitionToRecruiter($notificationData,$recruiter->registration_id);
                    }
                }
            }
        }

    }

    /**
     * @param int    $employerAdminId
     * @param string $startDate
     * @param string $endDate
     *
     * @return mixed
     */
    public function getRequisition(int $employerAdminId, string $startDate, string $endDate)
    {
        $employerAdmins = $this->getEmployerAdminIds($employerAdminId);

        $model = $this->model->whereIn('employer_admin_id',$employerAdmins)
                             ->whereBetween('job_start',[$startDate,$endDate])
                             ->orderBy('job_start','asc')
                             ->get(['id','employer_admin_id','job_title','need_num','job_start','job_end','job_id','status']);

        return $this->parserResult($model);
    }

    /*public function getRequisition(int $employerAdminId, string $startDate, string $endDate)
    {
        $data = $this->with(['adminUser'])->findWhere(['employer_admin_id'=>$employerAdminId]);
    }*/

    /**
     * @param Request $request
     * @return mixed
     */
    public function setRequisition($request)
    {
        $data['job_title']         = $request->job_title;
        $data['need_num']          = $request->need_num;

        //job_start
        $startTimeArray = explode(':',$request->start_time);
        if (strlen($startTimeArray[0]) != 2){
            $request->start_time = '0'.$request->start_time;
        }
        $data['job_start'] = Carbon::parse($request->date.' '.$request->start_time)->toDateTimeString();

        $endTimeArray = explode(':',$request->end_time);
        if (strlen($endTimeArray[0]) != 2){
            $request->end_time = '0'.$request->end_time;
        }

        //比较开始时间与结束时间，如果开始时间大于等于结束时间，说明跨天了，那么结束时间+1天
        //job_end
        if ($request->start_time >= $request->end_time) {
            $data['job_end'] = Carbon::parse($request->date)
                ->addDay()
                ->addHours($endTimeArray[0])
                ->addMinutes($endTimeArray[1])
                ->toDateTimeString();
        } else {
            $data['job_end'] = Carbon::parse($request->date.' '.$request->end_time)->toDateTimeString();
        }

        $requisition    = $this->find($request->id);
        $data['status'] = in_array($requisition->status,['approve','update'])
                          ? 'update'
                          : 'pending';

        //是否有签名
        if ($request->hasFile('signature')) {
            $remarkRepository  = new RequisitionRemarkRepository($this->app);
            $remark            = $remarkRepository->insert($request);
            $data['remark_id'] = $remark->id;
        }


        //update
        return $this->update($data,$request->id);

    }

    /**
     * @param array  $where
     * @param string $betweenField
     * @param array  $betweenCondition
     * @param array  $columns
     *
     * @return mixed
     */
    public function findWhereBetween(array $where,string $betweenField,array $betweenCondition,array $columns= ['*'])
    {
        $this->applyCriteria();
        $this->applyScope();

        $this->applyConditions($where);
        $model = $this->model->whereBetween($betweenField,$betweenCondition)->get($columns);
        $this->resetModel();

        return $this->parserResult($model);
    }

    public function getEmployerAdminIds($employerAdminId){
        $adminRep = app(AdminRepository::class);
        $employerAdmin = $adminRep->with(['children'])->find($employerAdminId,['id']);
        if (!count($employerAdmin->children)){
            $employerAdmins = [$employerAdminId];
        }else{
            $employerAdmins = array_merge(
                [$employerAdminId],
                array_map(function ($value){
                    return $value['id'];
                },$employerAdmin->children->toArray())
            );
        }
        return $employerAdmins;
    }

}