<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:31
 */

namespace App\Api\V4\Employer\Repositories;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\MessageBag;
use App\Api\V4\Employer\Entities\Admin;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Employer\Criteria\Admin\EmployerCriteria;

class AdminRepository extends BaseRepository
{
    public function model()
    {
        return Admin::class;
    }


    /**
     * 登陆
     * @param $request
     *
     * @return array
     * @throws ValidatorException
     */
    public function login($request)
    {
        $this->pushCriteria(EmployerCriteria::class);
        $admin = $this->first(['id','name', 'email', 'password', 'status', 'registration_id']);
        if ( ! $admin) {
            throw new ValidatorException(
                new MessageBag(['Can\'t find this e-mail account'])
            );
        }

        if ( ! Hash::check($request->password, $admin->password)) {
            throw new ValidatorException(
                new MessageBag(['Incorrect password for account'])
            );
        }

        if (1 != $admin->status || 1 != $admin->employer->e_status) {
            throw new ValidatorException(
                new MessageBag(['Your account is forbidden to login'])
            );
        }

        $this->setRegistrationId(
            $admin->id,
            $request->registration_id,
            $admin->registration_id
        );

        $token = $this->getToken($admin);

        return ['id' => $admin->id,
                'token' => $token,
                'children'=>$this->children($admin),
                'logo'=>$admin->employer->e_company_logo,
                'name'=>$admin->name,
        ];
    }

    /**
     * 设置用户的RegistrationId
     *
     * @param        $id
     * @param string $newRegistrationId
     * @param string $curRegistrationId
     *
     * @return bool
     */
    private function setRegistrationId($id, $newRegistrationId = '', $curRegistrationId = '')
    {
        //只有id 则清空该id的RegistrationId
        if ($id && ! $newRegistrationId) {
            return $this->update(['registration_id' => ''], $id);
        }

        if ( ! $curRegistrationId) {
            $curRegistrationId = $this->find($id, ['registration_id'])->registration_id;
        }

        //新RegistrationId与旧RegistrationId对比，不同则设置新的
        if ($newRegistrationId && ($newRegistrationId != $curRegistrationId)) {
            $newRegistrationOwner = $this->skipCriteria()
                                         ->findByField('registration_id', $newRegistrationId)
                                         ->first();

            //新RegistrationId之前是否有所有者，有则清空
            if ($newRegistrationOwner) {
                $this->update(['registration_id' => ''], $newRegistrationOwner->id);
            }
            $this->update(['registration_id' => $newRegistrationId], $id);

            return true;
        }

        return true;
    }


    /**
     * 获取token
     *
     * @param Admin $admin
     *
     * @return bool
     */
    private function getToken(Admin $admin)
    {
        return auth('employer')->attempt(['id' => $admin->id]);
    }

    /**
     * 获取子账号，如果没有就返回自己
     *
     * @param $parent
     *
     * @return array|mixed
     */
    public function children($parent)
    {
        if ($parent->id == 0) {
            return [];
        }

        $children = $this->skipCriteria()->findWhere(['parent_id' => $parent->id], ['id', 'name']);

        $child = $children->toArray();
        if ( ! empty($child)) {
            return array_merge(
                [['id' => $parent->id, 'name' => $parent->name]],
                $child
            );
        }

        return [['id' => $parent->id, 'name' => $parent->name]];
    }

}