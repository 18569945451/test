<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/12
 * Time: 14:42
 */

namespace App\Api\V4\Employer\Repositories;

use App\Api\V1\Repositories\FileRepository;
use App\Api\V4\Employer\Entities\LabourRequisitionRemark;
use Prettus\Repository\Eloquent\BaseRepository;


class RequisitionRemarkRepository extends BaseRepository
{
    public function model()
    {
        return LabourRequisitionRemark::class;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return mixed
     */
    public function insert($request)
    {
        $fileRepository = new FileRepository();

        $data['signature'] = $fileRepository->imageReSize(
            $request->file('signature'),
            generateFilePath()
        );
        $data['remark']    = $request->remark;

        return $this->create($data);
    }
}