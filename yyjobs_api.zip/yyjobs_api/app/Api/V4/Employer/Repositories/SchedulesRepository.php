<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/11/16
 * Time: 14:08
 */

namespace App\Api\V4\Employer\Repositories;

use App\Api\V4\Employer\Entities\Schedule;
use Illuminate\Support\Carbon;
use Prettus\Repository\Eloquent\BaseRepository;


class SchedulesRepository extends BaseRepository
{
    public function model()
    {
        return Schedule::class;
    }

    /**
     *
     */
    public function getResult()
    {
        $data   = $this->all()->toArray();
        $days   = '';
        $jobIds = '';
        foreach ($data as $key => $value) {
            $days .= $value['days'].',';
            $jobIds .= $value['job_id'].',';
        }

        $jobIds = array_unique(array_filter(explode(',', $jobIds)));
        $jobRep = new JobRepository($this->app);

        $jobs = $jobRep->model->withCount(['schedules'=>function($query){
                    return $query->where('parent_id',0)->where('is_send',1);
                }])->whereIn('job_id',$jobIds)->orderBy('job_start_date','DESC')->get();

        $returnData = [];
        foreach ($jobs as $jobKey => $jobValue) {
            $dayKey = Carbon::createFromTimestamp($jobValue->job_start_date)->format('Ymd');
            $employerKey = $jobValue->job_employer_admin_id;
            $returnData[$dayKey][$employerKey]['date']              = $dayKey;
            $returnData[$dayKey][$employerKey]['employer']          = $jobValue->job_employer_company_name;
            $returnData[$dayKey][$employerKey]['employer_admin_id'] = $jobValue->job_employer_admin_id;
            $returnData[$dayKey][$employerKey]['num']               = isset($returnData[$dayKey][$employerKey]['num'])
                                                                    ? $jobValue->schedules_count + $returnData[$dayKey][$employerKey]['num']
                                                                    : $jobValue->schedules_count;
            $returnData[$dayKey][$employerKey]['last_update_time']  = $jobValue->job_update_time;
            $returnData[$dayKey][$employerKey]['employer_status']   = $jobValue->employer_status;
        }

        foreach ($returnData as $key=>$value) {
            rsort($returnData[$key]);
        }
        krsort($returnData);
        $newData = [];
        foreach ($returnData as $value) {
            $newData[] = $value;
        }
        return $newData;
    }
}