<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/10/16
 * Time: 16:43
 */

namespace App\Api\V4\Employer\Repositories;

use App\Api\V5\Recruiter\Jobs\CreateChatRoom;
use App\Traits\Admin\Jpush;
use PDF;
use App\Api\V4\Employer\Jobs\SendConfirmAttendanceEmail;
use App\Api\V4\Employer\Jobs\SendReviseAttendanceEmail;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use Illuminate\Support\MessageBag;
use Maatwebsite\Excel\Facades\Excel;
use App\Api\V4\Employer\Entities\Job;
use App\Api\V4\Employer\Entities\Member;
use App\Api\V4\Employer\Entities\Schedule;
use App\Api\V1\Repositories\FileRepository;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;


class AttendanceRepository extends BaseRepository
{
    use Jpush;
    public function model()
    {
        return Schedule::class;
    }

    /**
     * @return mixed
     */
    public function attendanceList()
    {
        $column = ['job_schedules.s_id', 'm.member_id', 'm.member_name', 'm.member_sex','m.member_nric','m.member_avatar','m.member_birthday',
                   'job_schedules.checkin_time', 'job_schedules.checkout_time','job_schedules.adjusted_checkin_time','job_schedules.revise_version',
                   'job_schedules.adjusted_checkout_time','job_schedules.checkin_signature', 'job_schedules.checkout_signature','job_schedules.update_time',
                   'job_schedules.work_hours', 'job_schedules.adjusted_work_minutes','job_schedules.extra_work_minutes','job_schedules.parent_id','job_schedules.employer_remark',
                   'j.job_id','j.job_start_date', 'j.job_end_date', 'j.job_employer_admin_id','j.employer_status','j.confirm_signature',
                   'j.job_employer_company_name','j.job_address','j.job_title'
            ];
        $data   = $this->get($column);
        return $this->skipPresenter()->parserResult($data);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function processUpdate($request)
    {
        $fileRepository = new FileRepository();
        $ids = array_column($request->all()['data'],'s_id');
        $schedules = $this->model->whereIn('s_id',$ids)->get(['s_id','checkin_time','adjusted_checkin_time','checkin_signature','checkout_time','adjusted_checkout_time','checkout_signature','work_hours'])->toArray();
        $schedules = array_column($schedules,null,'s_id');

        $returnData = [];
        foreach ($request->data as $key=>$value) {
            $data = [];
            $hours        = !empty($value['hours']) ? $value['hours'] : 0;
            //签到时间
            $data['checkin_time'] = !empty($value['checkin_time']) ? $value['checkin_time'] : $schedules[$value['s_id']]['checkin_time'];
            //签出时间
            $data['checkout_time'] = !empty($value['checkout_time']) ? $value['checkout_time'] : $schedules[$value['s_id']]['checkout_time'];
            //签到图片
            $data['checkin_signature']  = !empty($value['checkin_signature']) ? $fileRepository->imageReSize($value['checkin_signature'], generateFilePath()) : $schedules[$value['s_id']]['checkin_signature'];
            //签出图片
            $data['checkout_signature'] = !empty($value['checkout_signature']) ? $fileRepository->imageReSize($value['checkout_signature'], generateFilePath()) : $schedules[$value['s_id']]['checkout_signature'];
            //修改后的签到时间
            $data['adjusted_checkin_time']  = !empty($value['adjusted_checkin_time']) ? $this->strTimeToTimestampMinutes($value['adjusted_checkin_time']) : $schedules[$value['s_id']]['adjusted_checkin_time'];
            //修改后的签出时间
            $data['adjusted_checkout_time']  = !empty($value['adjusted_checkout_time']) ? $this->strTimeToTimestampMinutes($value['adjusted_checkout_time']) : $schedules[$value['s_id']]['adjusted_checkout_time'];
            //工时
            if (!empty($data['checkin_time']) && !empty($data['checkout_time'])){
                $data['adjusted_work_minutes']  = $this->model->getWorkMinutes($data['adjusted_checkin_time'],$data['adjusted_checkout_time'],$hours) * 60;
            }
            $this->update($data,$value['s_id']);
            $data['s_id'] = $value['s_id'];
            $returnData[$key][] = $data;
        }
        return $returnData;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function processUpdate_bak2($request)
    {
        $fileRepository = new FileRepository();
        $ids = array_column($request->all()['data'],'s_id');
        $schedules = $this->model->whereIn('s_id',$ids)->get(['s_id','checkin_time','adjusted_checkin_time','checkin_signature','checkout_time','adjusted_checkout_time','checkout_signature','work_hours'])->toArray();
        $schedules = array_column($schedules,null,'s_id');

        $returnData = [];
        foreach ($request->data as $key=>$value) {
            //(工作结束时间(秒)-工作开始时间(秒)) / 60 + 额外时间(小时) * 60
            if (!empty($value['checkin_time']) && !empty($value['checkout_time'])){
                //$value['adjusted_work_minutes'] = ($schedules[$value['s_id']]['adjusted_checkout_time'] - $schedules[$value['s_id']]['adjusted_checkin_time']) / 60 + $value['hours'] * 60;
                $value['adjusted_work_minutes']  = $this->model->getWorkMinutes($schedules[$value['s_id']]['adjusted_checkin_time'],$schedules[$value['s_id']]['adjusted_checkout_time'],$value['hours']) * 60;
            }

            //(修改后的签出(秒)-修改后的签到(秒)) / 60 + 额外时间(小时) * 60
            if (!empty($value['adjusted_checkin_time']) && !empty($value['adjusted_checkout_time'])){
                $value['adjusted_checkin_time']  = $this->strTimeToTimestampMinutes($value['adjusted_checkin_time']);
                $value['adjusted_checkout_time'] = $this->strTimeToTimestampMinutes($value['adjusted_checkout_time']);

                //$value['adjusted_work_minutes']  = ($value['adjusted_checkout_time'] - $value['adjusted_checkin_time']) / 60 + $value['hours'] * 60;
                $value['adjusted_work_minutes']  = $this->model->getWorkMinutes($value['adjusted_checkin_time'],$value['adjusted_checkout_time'],$value['hours']) * 60;
            }

            //签名图片
            if (!empty($value['checkin_signature'])){
                $value['checkin_signature'] = $fileRepository->imageReSize($value['checkin_signature'], generateFilePath());
                $returnData[$key]['checkin_signature']=$value['checkin_signature'];
            }else{
                $returnData[$key]['checkin_signature']= $schedules[$value['s_id']]['checkin_signature'];
            }
            if (!empty($value['checkout_signature'])){
                $value['checkout_signature'] = $fileRepository->imageReSize($value['checkout_signature'], generateFilePath());
                $returnData[$key]['checkout_signature']=$value['checkout_signature'];
            }else{
                $returnData[$key]['checkout_signature']=$schedules[$value['s_id']]['checkout_signature'];
            }

            unset($value['hours']);
            $this->update($value, $value['s_id']);
            $returnData[$key]['s_id'] = $value['s_id'];
        }
        return $returnData;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function processUpdate_bak($request)
    {
        $fileRepository = new FileRepository();
        $ids = array_column($request->all()['data'],'s_id');
        $schedules = $this->model->whereIn('s_id',$ids)->get(['s_id','checkin_time','checkin_signature','checkout_time','checkout_signature','work_hours'])->toArray();
        $schedules = array_column($schedules,null,'s_id');

        $returnData = [];
        foreach ($request->data as $key=>$value) {
            //去除秒数
            if ($value['checkin_time']){
                $value['checkin_time'] = $this->strTimeToTimestampMinutes($value['checkin_time']);
            }
            if ($value['checkout_time']){
                $value['checkout_time'] = $this->strTimeToTimestampMinutes($value['checkout_time']);
            }

            //是否修改过
            if (
                ($schedules[$value['s_id']]['checkin_time'] == 0 || $schedules[$value['s_id']]['checkout_time'] == 0)
                && $schedules[$value['s_id']]['work_hours'] == 0)
            {
                $modified = false;
            }else{
                $modified = true;
            }

            //签名图片
            if (!empty($value['checkin_signature'])){
                $value['checkin_signature'] = $fileRepository->imageReSize($value['checkin_signature'], generateFilePath());
                $returnData[$key]['checkin_signature']=$value['checkin_signature'];
            }else{
                $returnData[$key]['checkin_signature']= $schedules[$value['s_id']]['checkin_signature'];
            }

            if (!empty($value['checkout_signature'])){
                $value['checkout_signature'] = $fileRepository->imageReSize($value['checkout_signature'], generateFilePath());
                $returnData[$key]['checkout_signature']=$value['checkout_signature'];
            }else{
                $returnData[$key]['checkout_signature']=$schedules[$value['s_id']]['checkout_signature'];
            }

            //工作时间
            $hours = $this->model->getWorkMinutes($value['checkin_time'],$value['checkout_time'],$value['hours']) * 60;
            if ( ! $modified) {
                $value['work_hours'] = $hours;
            } else {
                $value['adjusted_checkin_time']  = $value['checkin_time'];
                $value['adjusted_checkout_time'] = $value['checkout_time'];
                $value['adjusted_work_minutes']  = $hours;
                unset($value['checkin_time'], $value['checkout_time']);
            }

            unset($value['hours']);
            $this->update($value,$value['s_id']);
            $returnData[$key]['s_id']=$value['s_id'];
        }
        return $returnData;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function processStore($request)
    {
        $member                         = Member::find($request->member_id);
        $job                            = Job::find($request->job_id);
        $data['job_id']                 = $request->job_id;
        $data['member_id']              = $request->member_id;
        $data['member_name']            = $member->member_name;
        $data['work_status']            = $job->employer_status != 1 ? 13 : 2;
        $data['member_nric']            = $member->member_nric;
        $data['member_sex']             = $member->member_sex;
        $data['adjusted_checkin_time']  = $job->job_start_date;
        $data['adjusted_checkout_time'] = $job->job_end_date;
        $data['job_start_date']         = $job->job_start_date;
        $data['job_end_date']           = $job->job_end_date;
        $data['is_send']                = 1;
        $data['add_time']               = time();
        $data['source']                 = 3;
        if ($result = $this->create($data)){
            CreateChatRoom::dispatch($jobID)->onQueue("api");
            if ($job->employer_status == 2){
                Job::where('job_id',$request->job_id)->update(['job_update_time'=>time(),'employer_status'=>3]);
            }
            $data['s_id'] = $result->s_id;
            return $data;
        }
        return false;
    }

    /**
     * @param $request
     *
     * @return int
     */
    public function processConfirm($request)
    {
        //获取给定日期的开始结束时间
        $between = [
            Carbon::parse($request->date)->getTimestamp(),
            Carbon::parse($request->date)->addDay()->getTimestamp(),
        ];

        //找到相应的工作ID
        $jobs = Job::whereBetween('job_start_date',$between)
                    ->whereIn('job_employer_admin_id',$request->employer_admin_id)
                    ->get(['job_id','job_employer_admin_id','job_recruiter_admin_id']);

        if (!count($jobs)){return null;}

        //签名图片
        $fileRepository = new FileRepository();
        $confirmSignature = $fileRepository->imageReSize($request->confirm_signature, generateFilePath());

        $jobIds = array_column($jobs->toArray(),'job_id');

        //发送通知的数据
        $recruiterNotificationsRepository = new RecruiterNotificationsRepository($this->app);
        list($recruiters,$employers) = $recruiterNotificationsRepository->getConfirmNotifyRecruiter($jobs->toArray(),$request->date);
        foreach ($jobs->toArray() as $job) {
            if (isset($recruiters[$job['job_recruiter_admin_id']]) && $recruiters[$job['job_recruiter_admin_id']]['registration_id'] != ''){
                $data = $recruiterNotificationsRepository->saveConfirmAttendanceNotify($recruiters[$job['job_recruiter_admin_id']],$employers[$job['job_employer_admin_id']],$job['job_id'],$request->date);
                $this->notifyConfirmAttendance($data,$recruiters[$job['job_recruiter_admin_id']]['registration_id']);
            }
        }

        //更改工作状态
        Job::whereIn('job_id',$jobIds)->update(['employer_status'=>2,'job_update_time'=>time(),'confirm_signature'=>$confirmSignature]);

        //发送邮件
        if (env('APP_ENV') == 'production') {
            dispatch(new SendConfirmAttendanceEmail($request->date, $request->employer_admin_id))->onQueue("api");
        }
        return $this->model->whereIn('job_id',$jobIds)->where('work_status',2)->update(['work_status'=>5]);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function processRevise($request)
    {
        $job = $this->model->with('job')->where('s_id',$request->data[0]['s_id'])->first();
        $date = date('Y-m-d',$job->job->job_start_date);
        $between = [
            Carbon::parse($date)->getTimestamp(),
            Carbon::parse($date)->addDay()->getTimestamp(),
        ];
        $sIds = array_column($request->data,'s_id');
        $schedules = $this->model->whereIn('s_id',$sIds)->get();
        $schedules = array_column($schedules->toArray(),null,'s_id');
        
        //revise version
        $reviseVersionResult = Schedule::join('job as j','job_schedules.job_id','j.job_id')->where('j.job_employer_admin_id',$request->employer_admin_id)->whereBetween('j.job_start_date',$between)->orderBy('job_schedules.revise_version','DESC')->first(['revise_version']);
        $preReviseVersion = $reviseVersionResult->revise_version;

        $insertData     = [];
        $fileRepository = new FileRepository();
        foreach ($request->data as $key => $value) {
            $hours        = !empty($value['hours']) ? $value['hours'] : 0;
            //签到时间
            $data['checkin_time'] = !empty($value['checkin_time']) ? $value['checkin_time'] : $schedules[$value['s_id']]['checkin_time'];
            //签出时间
            $data['checkout_time'] = !empty($value['checkout_time']) ? $value['checkout_time'] : $schedules[$value['s_id']]['checkout_time'];
            //签到图片
            $data['checkin_signature']  = !empty($value['checkin_signature']) ? $fileRepository->imageReSize($value['checkin_signature'], generateFilePath()) : $schedules[$value['s_id']]['checkin_signature'];
            //签出图片
            $data['checkout_signature'] = !empty($value['checkout_signature']) ? $fileRepository->imageReSize($value['checkout_signature'], generateFilePath()) : $schedules[$value['s_id']]['checkout_signature'];
            //修改后的签到时间
            $data['adjusted_checkin_time']  = !empty($value['adjusted_checkin_time']) ? $this->strTimeToTimestampMinutes($value['adjusted_checkin_time']) : $schedules[$value['s_id']]['adjusted_checkin_time'];
            //修改后的签出时间
            $data['adjusted_checkout_time']  = !empty($value['adjusted_checkout_time']) ? $this->strTimeToTimestampMinutes($value['adjusted_checkout_time']) : $schedules[$value['s_id']]['adjusted_checkout_time'];

            $insertData[$key]['member_id']              = $schedules[$value['s_id']]['member_id'];
            $insertData[$key]['member_name']            = $schedules[$value['s_id']]['member_name'];
            $insertData[$key]['job_id']                 = $schedules[$value['s_id']]['job_id'];
            $insertData[$key]['work_status']            = 13;
            $insertData[$key]['source']                 = $schedules[$value['s_id']]['source'];
            $insertData[$key]['is_send']                = $schedules[$value['s_id']]['is_send'];
            $insertData[$key]['checkin_time']           = $data['checkin_time'];
            $insertData[$key]['checkout_time']          = $data['checkout_time'];
            $insertData[$key]['checkin_signature']      = $data['checkin_signature'];
            $insertData[$key]['checkout_signature']     = $data['checkout_signature'];
            $insertData[$key]['adjusted_checkin_time']  = $data['adjusted_checkin_time'];
            $insertData[$key]['adjusted_checkout_time'] = $data['adjusted_checkout_time'];
            $insertData[$key]['update_time']            = time();
            $insertData[$key]['revise_version']         = $preReviseVersion + 1;
            //工时
            if ($data['checkin_time'] && $data['checkout_time']){
                $insertData[$key]['adjusted_work_minutes']  = $this->model->getWorkMinutes($data['adjusted_checkin_time'],$data['adjusted_checkout_time'],$hours) * 60;
            }
            //额外时间
            $insertData[$key]['extra_work_minutes']  = $hours * 60;
            /* *
             * 如果上条记录是主记录说明之前没被revise过，那么就使用上条记录的ID作为此条记录的Parent_ID
             * 如果上条记录不是主记录，说明被revise过，如果还是使用上条记录的ID作为此条记录的Parent_ID就会导致分层过多
             * */
            $insertData[$key]['parent_id']              = $schedules[$value['s_id']]['parent_id'] == 0 ? $schedules[$value['s_id']]['s_id'] : $schedules[$value['s_id']]['parent_id'];

            if ($schedules[$value['s_id']]['work_status'] == 2){
                $this->model->where('s_id',$schedules[$value['s_id']]['s_id'])->update(['work_status'=>5]);
            }
        }
        $this->model->insert($insertData);

        $requisitionRep   = app(RequisitionRepository::class);
        $employerAdminIds = $requisitionRep->getEmployerAdminIds($request->employer_admin_id);
        $confirmSignature = $fileRepository->imageReSize($request->confirm_signature, generateFilePath());

        //发送邮件
        if (env('APP_ENV') == 'production'){
            dispatch(new SendReviseAttendanceEmail($date,$request->employer_admin_id))->onQueue("api");
        }


        return job::whereBetween('job_start_date',$between)
            ->whereIn('job_employer_admin_id',$employerAdminIds)
            ->update(['job_update_time' => time(), 'employer_status' => 3, 'confirm_signature' => $confirmSignature]);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function processRevise_bak3($request)
    {
        $job = $this->model->with('job')->where('s_id',$request->data[0]['s_id'])->first();
        $date = date('Y-m-d',$job->job->job_start_date);
        $between = [
            Carbon::parse($date)->getTimestamp(),
            Carbon::parse($date)->addDay()->getTimestamp(),
        ];
        $sIds = array_column($request->data,'s_id');
        $schedules = $this->model->whereIn('s_id',$sIds)->get();
        $schedules = array_column($schedules->toArray(),null,'s_id');
        
        //revise version
        $reviseVersionResult = Schedule::join('job as j','job_schedules.job_id','j.job_id')->where('j.job_employer_admin_id',$request->employer_admin_id)->whereBetween('j.job_start_date',$between)->orderBy('job_schedules.revise_version','DESC')->first(['revise_version']);
        $preReviseVersion = $reviseVersionResult->revise_version;

        $insertData     = [];
        $fileRepository = new FileRepository();
        foreach ($request->data as $key => $value) {
            $hours        = !empty($value['hours']) ? $value['hours'] : 0;
            //签到时间
            $data['checkin_time'] = !empty($value['checkin_time']) ? $value['checkin_time'] : $schedules[$value['s_id']]['checkin_time'];
            //签出时间
            $data['checkout_time'] = !empty($value['checkout_time']) ? $value['checkout_time'] : $schedules[$value['s_id']]['checkout_time'];
            //签到图片
            $data['checkin_signature']  = !empty($value['checkin_signature']) ? $fileRepository->imageReSize($value['checkin_signature'], generateFilePath()) : $schedules[$value['s_id']]['checkin_signature'];
            //签出图片
            $data['checkout_signature'] = !empty($value['checkout_signature']) ? $fileRepository->imageReSize($value['checkout_signature'], generateFilePath()) : $schedules[$value['s_id']]['checkout_signature'];
            //修改后的签到时间
            $data['adjusted_checkin_time']  = !empty($value['adjusted_checkin_time']) ? $this->strTimeToTimestampMinutes($value['adjusted_checkin_time']) : $schedules[$value['s_id']]['adjusted_checkin_time'];
            //修改后的签出时间
            $data['adjusted_checkout_time']  = !empty($value['adjusted_checkout_time']) ? $this->strTimeToTimestampMinutes($value['adjusted_checkout_time']) : $schedules[$value['s_id']]['adjusted_checkout_time'];

            if (!$schedules[$value['s_id']]['checkin_time'] || !$schedules[$value['s_id']]['checkout_time']){
                //工时
                if (!empty($data['checkin_time']) && !empty($data['checkout_time'])){
                    $data['adjusted_work_minutes']  = $this->model->getWorkMinutes($data['adjusted_checkin_time'],$data['adjusted_checkout_time'],$hours) * 60;
                }
                $this->update($data,$value['s_id']);
            }else{
                $insertData[$key]['member_id']              = $schedules[$value['s_id']]['member_id'];
                $insertData[$key]['member_name']            = $schedules[$value['s_id']]['member_name'];
                $insertData[$key]['job_id']                 = $schedules[$value['s_id']]['job_id'];
                $insertData[$key]['work_status']            = 13;
                $insertData[$key]['is_send']                = $schedules[$value['s_id']]['is_send'];
                $insertData[$key]['checkin_time']           = $data['checkin_time'];
                $insertData[$key]['checkout_time']          = $data['checkout_time'];
                $insertData[$key]['checkin_signature']      = $data['checkin_signature'];
                $insertData[$key]['checkout_signature']     = $data['checkout_signature'];
                $insertData[$key]['adjusted_checkin_time']  = $data['adjusted_checkin_time'];
                $insertData[$key]['adjusted_checkout_time'] = $data['adjusted_checkout_time'];
                $insertData[$key]['update_time']            = time();
                $insertData[$key]['revise_version']         = $preReviseVersion + 1;
                //工时
                //if (!empty($value['adjusted_checkin_time']) && !empty($value['adjusted_checkout_time'])){
                    $insertData[$key]['adjusted_work_minutes']  = $this->model->getWorkMinutes($data['adjusted_checkin_time'],$data['adjusted_checkout_time'],$hours) * 60;
                //}
                //$insertData[$key]['adjusted_work_minutes']  = $this->model->getWorkMinutes($insertData[$key]['adjusted_checkin_time'],$insertData[$key]['adjusted_checkout_time'],$hours) * 60;

                /* *
                 * 如果上条记录是主记录说明之前没被revise过，那么就使用上条记录的ID作为此条记录的Parent_ID
                 * 如果上条记录不是主记录，说明被revise过，如果还是使用上条记录的ID作为此条记录的Parent_ID就会导致分层过多
                 * */
                $insertData[$key]['parent_id']              = $schedules[$value['s_id']]['parent_id'] == 0 ? $schedules[$value['s_id']]['s_id'] : $schedules[$value['s_id']]['parent_id'];
            }
        }
        $this->model->insert($insertData);

        $requisitionRep   = app(RequisitionRepository::class);
        $employerAdminIds = $requisitionRep->getEmployerAdminIds($request->employer_admin_id);
        $confirmSignature = $fileRepository->imageReSize($request->confirm_signature, generateFilePath());

        //发送邮件
        if (env('APP_ENV') == 'production'){
            dispatch(new SendReviseAttendanceEmail($date,$request->employer_admin_id))->onQueue("api");
        }


        return job::whereBetween('job_start_date',$between)
            ->whereIn('job_employer_admin_id',$employerAdminIds)
            ->update(['job_update_time' => time(), 'employer_status' => 3, 'confirm_signature' => $confirmSignature]);
    }


    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function processRevise_bak2($request)
    {
        $job = $this->model->with('job')->where('s_id',$request->data[0]['s_id'])->first();
        $date = date('Y-m-d',$job->job->job_start_date);
        $between = [
            Carbon::parse($date)->getTimestamp(),
            Carbon::parse($date)->addDay()->getTimestamp(),
        ];
        $sIds = array_column($request->data,'s_id');
        $schedules = $this->model->whereIn('s_id',$sIds)->get();
        $schedules = array_column($schedules->toArray(),null,'s_id');

        $insertData     = [];
        $fileRepository = new FileRepository();
        foreach ($request->data as $key => $value) {
            $value['hours']                   = isset($value['hours']) ? $value['hours'] : 0;
            //新增加的记录只需修改原记录
            if (!$schedules[$value['s_id']]['checkin_time'] && !$schedules[$value['s_id']]['checkout_time']){
                $updateData                       = [];
                $updateData['update_time']        = time();
                $updateData['work_status']        = 13;

                //签到图片
                $updateData['checkin_signature']  = !empty($value['checkin_signature'])
                                                    ? $fileRepository->imageReSize($value['checkin_signature'], generateFilePath())
                                                    : $schedules[$value['s_id']]['checkin_signature'];
                //签出图片
                $updateData['checkout_signature'] = !empty($value['checkout_signature'])
                                                    ? $fileRepository->imageReSize($value['checkout_signature'], generateFilePath())
                                                    : $schedules[$value['s_id']]['checkout_signature'];

                //修改后的工时
                /*if (!empty($value['checkin_time']) && !empty($value['checkout_time'])){
                    $updateData['adjusted_work_minutes']  = $this->model->getWorkMinutes($schedules[$value['s_id']]['adjusted_checkin_time'],$schedules[$value['s_id']]['adjusted_checkout_time'],$value['hours']) * 60;
                }*/
                //签到时间
                if (!empty($value['checkin_time'])){
                    $updateData['checkin_time'] = $value['checkin_time'];
                }
                //签出时间
                if (!empty($value['checkout_time'])){
                    $updateData['checkout_time'] = $value['checkout_time'];
                }
                //如果传了修改后的签到签出时间并且之前也签到签出了 或者 传了修改后的签到签出时间并且也签到签出了  就需要根据传过来的计算工时
                if ((!empty($value['adjusted_checkin_time']) && !empty($value['adjusted_checkout_time']) && $schedules[$value['s_id']]['checkin_time'] != 0 && $schedules[$value['s_id']]['checkout_time'] != 0)
                    ||(!empty($value['adjusted_checkin_time']) && !empty($value['adjusted_checkout_time']) && !empty($value['checkin_time']) && !empty($value['checkout_time']))){
                    $updateData['adjusted_checkin_time']  = $this->strTimeToTimestampMinutes($value['adjusted_checkin_time']);
                    $updateData['adjusted_checkout_time'] = $this->strTimeToTimestampMinutes($value['adjusted_checkout_time']);
                    $updateData['adjusted_work_minutes']  = $this->model->getWorkMinutes($updateData['adjusted_checkin_time'],$updateData['adjusted_checkout_time'],$value['hours']) * 60;
                }elseif(!empty($value['adjusted_checkin_time']) && !empty($value['adjusted_checkout_time'])){
                    $updateData['adjusted_checkin_time']  = $this->strTimeToTimestampMinutes($value['adjusted_checkin_time']);
                    $updateData['adjusted_checkout_time'] = $this->strTimeToTimestampMinutes($value['adjusted_checkout_time']);
                }

                $this->update($updateData,$value['s_id']);
            }else{/*****有签到签出的记录说明工时已经计算出来了，需要添加一条新的*****/
                $insertData[$key]['member_id']              = $schedules[$value['s_id']]['member_id'];
                $insertData[$key]['member_name']            = $schedules[$value['s_id']]['member_name'];
                $insertData[$key]['job_id']                 = $schedules[$value['s_id']]['job_id'];
                $insertData[$key]['checkin_signature']      = $schedules[$value['s_id']]['checkin_signature'];
                $insertData[$key]['checkout_signature']     = $schedules[$value['s_id']]['checkout_signature'];
                $insertData[$key]['work_status']            = $schedules[$value['s_id']]['work_status'];
                $insertData[$key]['is_send']                = $schedules[$value['s_id']]['is_send'];
                $insertData[$key]['checkin_time']           = $schedules[$value['s_id']]['checkin_time'];
                $insertData[$key]['checkout_time']          = $schedules[$value['s_id']]['checkout_time'];
                $insertData[$key]['adjusted_checkin_time']  = $this->strTimeToTimestampMinutes($value['adjusted_checkin_time']);
                $insertData[$key]['adjusted_checkout_time'] = $this->strTimeToTimestampMinutes($value['adjusted_checkout_time']);
                $insertData[$key]['adjusted_work_minutes']  = $this->model->getWorkMinutes($insertData[$key]['adjusted_checkin_time'],$insertData[$key]['adjusted_checkout_time'],$value['hours']) * 60;
                $insertData[$key]['update_time']            = time();

                /* *
                 * 如果上条记录是主记录说明之前没被revise过，那么就使用上条记录的ID作为此条记录的Parent_ID
                 * 如果上条记录不是主记录，说明被revise过，如果还是使用上条记录的ID作为此条记录的Parent_ID就会导致分层过多
                 * */
                $insertData[$key]['parent_id']              = $schedules[$value['s_id']]['parent_id'] == 0 ? $value['s_id'] : $schedules[$value['s_id']]['parent_id'];
            }
        }

        $this->model->insert($insertData);

        $requisitionRep   = app(RequisitionRepository::class);
        $employerAdminIds = $requisitionRep->getEmployerAdminIds($request->employer_admin_id);
        $confirmSignature = $fileRepository->imageReSize($request->confirm_signature, generateFilePath());
        return job::whereBetween('job_start_date',$between)
            ->whereIn('job_employer_admin_id',$employerAdminIds)
            ->update(['job_update_time' => time(), 'employer_status' => 3, 'confirm_signature' => $confirmSignature]);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function processRevise_bak($request)
    {
        //1、获取employer_admin_id当天所有工作id
        //2、修改当天所有工作状态并且修改签名图片
        //3、循环data里的数据
        //3-1、如果只有remark就不进行插入
        $job = $this->model->with('job')->where('s_id',$request->data[0]['s_id'])->first();
        $date = date('Y-m-d',$job->job->job_start_date);
        $between = [
            Carbon::parse($date)->getTimestamp(),
            Carbon::parse($date)->addDay()->getTimestamp(),
        ];
        $sIds = array_column($request->data,'s_id');
        $schedules = $this->model->whereIn('s_id',$sIds)->get(['s_id','member_id','member_name','job_id','checkin_time','checkout_time','checkin_signature','checkout_signature','work_status','is_send']);
        $schedules = array_column($schedules->toArray(),null,'s_id');

        $insertData = [];

        foreach ($request->data as $key => $value) {
            $insertData[$key]['member_id']              = $schedules[$value['s_id']]['member_id'];
            $insertData[$key]['member_name']            = $schedules[$value['s_id']]['member_name'];
            $insertData[$key]['job_id']                 = $schedules[$value['s_id']]['job_id'];
            $insertData[$key]['checkin_signature']      = $schedules[$value['s_id']]['checkin_signature'];
            $insertData[$key]['checkout_signature']     = $schedules[$value['s_id']]['checkout_signature'];
            $insertData[$key]['work_status']            = $schedules[$value['s_id']]['work_status'];
            $insertData[$key]['is_send']                = $schedules[$value['s_id']]['is_send'];
            $insertData[$key]['checkin_time']           = $schedules[$value['s_id']]['checkin_time'];
            $insertData[$key]['checkout_time']          = $schedules[$value['s_id']]['checkout_time'];
            $insertData[$key]['adjusted_checkin_time']  = $value['checkin_time'];
            $insertData[$key]['adjusted_checkout_time'] = $value['checkout_time'];
            $insertData[$key]['adjusted_work_minutes']  = $this->model->getWorkMinutes($value['checkin_time'],$value['checkout_time'],$value['hours']) * 60;
            /* *
             * 如果上条记录是主记录说明之前没被revise过，那么就使用上条记录的ID作为此条记录的Parent_ID
             * 如果上条记录不是主记录，说明被revise过，如果还是使用上条记录的ID作为此条记录的Parent_ID就会导致分层过多
             * */
            $insertData[$key]['parent_id']              = $value['s_id'] == 0 ? $value['s_id'] : $value['parent_id'];
        }

        $this->model->insert($insertData);

        $requisitionRep = app(RequisitionRepository::class);
        $employerAdminIds = $requisitionRep->getEmployerAdminIds($request->employer_admin_id);
        job::whereBetween('job_start_date',$between)
             ->whereIn('job_employer_admin_id',$employerAdminIds)
             ->update(['job_update_time'=>time(),'employer_status'=>3]);

        return true;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function remark($request)
    {
        return $this->model->where('s_id',$request->s_id)->update(['employer_remark'=>$request->remark]);
    }

    /**
     * @param array $data
     * @param \Illuminate\Http\Request $request
     * @return array
     * @throws ValidatorException
     */
    public function export(array $data,$request)
    {
        if (!$data){throw new ValidatorException(new MessageBag(['No data to send.']));}

        $cellData = [
            ['E-Attendance List'],
            ['Name','NRIC','Gender','Start Time','Time In','End Time','Time Out','+/- Hours','Total','Remark','Revise']];

        foreach ($data as $key=>$value) {
            $lineData = [
                $value['parent_id'] != 0 ? '         '.$value['member_name'] : $value['member_name'],
                $value['member_nric'],
                $value['member_sex'],
                $value['adjusted_checkin_time'],
                $value['checkin_time'],
                $value['adjusted_checkout_time'],
                $value['checkout_time'],
                $value['hours'],
                $value['total'],
                $value['remark'],
                $value['update_time'] != 0 ? Carbon::createFromTimestamp($value['update_time'])->format('M d Y H:i') : '',
                $value['checkin_signature'],
                $value['checkout_signature'],
            ];
            array_push($cellData,$lineData);
        }

        $date     = Carbon::parse($request->date);
        $filePath = 'public/e-attendance/'.$date->format('Ym').'/'.$date->format('d').'/';
        $fileName = 'E-Attendance_'.$request->employer_admin_id.'_'.$request->date;
        $fullPath = $filePath.$fileName.'.xls';
        $pdfFullPath = $filePath.$fileName.'.pdf';

        //generateFileUrl($fullPath)

        Excel::create($fileName,function($excel)use($cellData){
            $excel->sheet('list', function($sheet) use ($cellData){
                $i = 1;
                $sheet->mergeCells('A1:K1');
                $sheet->setStyle(array('font' => array('name' => 'Calibri', 'size' => 12, 'bold' => false)));
                foreach ((array)$cellData as $record) {
                    $j = 'A';
                    foreach($record as $key=>$value) {
                        if ($j > 'K'){
                            continue;
                        }
                        if ($i > 2 && $j == 'E'){
                            $sheet->getCell($j.$i)->getHyperlink()->setUrl($record[11]);
                        }
                        if ($i > 2 && $j == 'G'){
                            $sheet->getCell($j.$i)->getHyperlink()->setUrl($record[12]);
                        }
                        $sheet->cell($j.$i, function($cell) use ($key,$value,$i,$j) {
                            $cell->setValue($value);
                            $cell->setAlignment('center');
                            if ($key == 0 & $i == 1){$cell->setFontSize(20);}
                            if ($j == 'A' && $i > 2){$cell->setAlignment('left');}
                        });
                        $j++;
                    }
                    $i++;
                }
            });
        })->store('xls',storage_path('app/'.$filePath));

        $pdf = PDF::loadView('v4.employer.EAttendanceList', ['result'=>$data]);

        //显示页码
        $pdf->output();
        $dom_pdf = $pdf->getDomPDF();
        $canvas = $dom_pdf ->get_canvas();
        $canvas->page_text(282, 770, "Page {PAGE_NUM} of {PAGE_COUNT}", null, 10, array(0, 0, 0));

        $pdf->save(storage_path('app/'.$pdfFullPath));

        return [
            generateFileUrl($fullPath),
            generateFileUrl($pdfFullPath),
        ];
    }

    /**
     * @param array $data
     * @param \Illuminate\Http\Request $request
     * @return string
     * @throws ValidatorException
     */
    public function exportPDF(array $data,$request)
    {
        if (!$data){throw new ValidatorException(new MessageBag(['No data to send.']));}
        $pdf = PDF::loadView('v4.employer.EAttendanceList', ['result'=>$data]);

        //显示页码
        $pdf->output();
        $dom_pdf = $pdf->getDomPDF();
        $canvas = $dom_pdf ->get_canvas();
        $canvas->page_text(282, 770, "Page {PAGE_NUM} of {PAGE_COUNT}", null, 10, array(0, 0, 0));

        return $pdf->save($request->date.'.pdf');
    }

    /**
     * 将日期时间转换为不带秒数的时间戳
     * @param $dateTime
     *
     * @return false|int 整分钟
     */
    private function strTimeToTimestampMinutes($dateTime)
    {
        return strtotime(date('Y-m-d H:i', $dateTime).':00');
    }

}