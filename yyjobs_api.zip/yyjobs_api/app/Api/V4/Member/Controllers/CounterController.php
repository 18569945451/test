<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 10:29
 */

namespace App\Api\V4\Member\Controllers;

use App\Api\V4\Member\Criteria\Counter\IndexCriteria;
use App\Api\V4\Member\Presenters\Counter\IndexPresenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V4\Member\Validators\CounterValidator;
use App\Api\V4\Member\Repositories\CounterRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class CounterController extends Controller
{
    protected $validator;
    protected $repository;

    public function __construct(CounterRepository $repository, CounterValidator $validator)
    {
        $this->validator  = $validator;
        $this->repository = $repository;
    }
    /**
     * @SWG\Post(path="/index.php/api/employee/counter/apply",
     *   tags={"employee/counter"},
     *   summary="柜台提现申请",
     *   description="柜台提现申请",
     *   operationId="counter/apply",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData", name="payment_password",type="string",  description="支付密码", required=true),
     *   @SWG\Parameter(in="formData", name="salary_amount",type="number",  description="提现金额", required=true),
     *   @SWG\Parameter(in="formData", name="counter_date",type="string",  description="柜台提现日期(2018-12-05)", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function apply(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('apply');
            $this->validator->workDay($request->counter_date);

            $data     = $this->repository->apply($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/counter/index",
     *   tags={"employee/counter"},
     *   summary="counter index",
     *   description="counter index",
     *   operationId="counter/index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index()
    {
        $this->repository->pushCriteria(IndexCriteria::class);
        $this->repository->setPresenter(IndexPresenter::class);
        $data = $this->repository->first()['data'] ? $this->repository->first()['data'] : null;
        return apiReturn($data);
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/counter/scan",
     *   tags={"employee/counter"},
     *   summary="扫码后提交",
     *   description="扫码后提交",
     *   operationId="counter/scan",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData", name="payment_password",type="string",  description="支付密码", required=true),
     *   @SWG\Parameter(in="formData", name="type",type="string",  description="扫码类型（counter:柜台扫码）", required=true),
     *   @SWG\Parameter(in="formData", name="amount",type="number",  description="数额", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function scan(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('scan');

            $data     = $this->repository->scan($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

}
