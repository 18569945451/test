<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/6
 * Time: 14:08
 */

namespace App\Api\V4\Member\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V4\Member\Validators\ReportIssuesValidator;
use App\Api\V4\Member\Repositories\ReportIssuesRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class ReportIssuesController extends Controller
{
    protected $validator;
    protected $repository;

    public function __construct(ReportIssuesRepository $repository, ReportIssuesValidator $validator)
    {
        $this->validator  = $validator;
        $this->repository = $repository;
    }
    /**
     * @SWG\Post(path="/index.php/api/employee/issues/report",
     *   tags={"employee/issues"},
     *   summary="报告问题 (status 1:Pending，2:Processed)",
     *   description="报告问题",
     *   operationId="issues/report",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData", name="salary_transaction_id",type="string",  description="交易ID", required=true),
     *   @SWG\Parameter(in="formData", name="report_salary",type="number",  description="报告金额", required=true),
     *   @SWG\Parameter(in="formData", name="desc",type="string",  description="问题描述", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function report(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('report');
            $data     = $this->repository->report($request);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}
