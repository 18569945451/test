<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 14:48
 */

namespace App\Api\V4\Member\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Member\Validators\EvaluateValidator;
use App\Api\V4\Member\Repositories\EvaluateRepository;

class EvaluateController extends Controller
{
    protected $validator;
    protected $repository;

    public function __construct(EvaluateRepository $repository, EvaluateValidator $validator)
    {
        $this->validator  = $validator;
        $this->repository = $repository;
    }
    /**
     * @SWG\Post(path="/index.php/api/employee/evaluate/rate",
     *   tags={"employee/evaluate"},
     *   summary="评分",
     *   description="评分",
     *   operationId="evaluate/rate",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData", name="recruiter_id",type="string",  description="recruiter ID", required=true),
     *   @SWG\Parameter(in="formData", name="apply",type="number",  description="Application Response (0~4)", required=true),
     *   @SWG\Parameter(in="formData", name="efficiency",type="string",  description="Efficiency in Response (0~4)", required=true),
     *   @SWG\Parameter(in="formData", name="detail",type="string",  description="Detailed and Accurate Information (0~4)", required=true),
     *   @SWG\Parameter(in="formData", name="attitude",type="string",  description="Attitude (0~4)", required=true),
     *   @SWG\Parameter(in="formData", name="problem",type="string",  description="Problem Management (0~4)", required=true),
     *   @SWG\Parameter(in="formData", name="overall",type="string",  description="Overall Service Level (0~4)", required=true),
     *   @SWG\Parameter(in="formData", name="recommend",type="string",  description="Will you recommend your recruiter to you friends (0,1)", required=true),
     *   @SWG\Parameter(in="formData", name="comment",type="string",  description="Any other comments you wish to provide", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function rate(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('rate');
            $data = $this->repository->rate($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

}
