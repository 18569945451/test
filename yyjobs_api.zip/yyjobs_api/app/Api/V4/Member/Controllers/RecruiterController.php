<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 15:14
 */

namespace App\Api\V4\Member\Controllers;

use App\Api\V4\Member\Criteria\Recruiter\IndexCriteria;
use App\Api\V4\Member\Criteria\Recruiter\DetailCriteria;
use App\Api\V4\Member\Presenters\Recruiter\IndexPresenter;
use App\Api\V4\Member\Presenters\Recruiter\DetailPresenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V4\Member\Repositories\RecruiterRepository;

class RecruiterController extends Controller
{
    protected $repository;

    public function __construct(RecruiterRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/recruiter/list",
     *   tags={"employee/recruiter"},
     *   summary="recruiter列表",
     *   description="recruiter列表",
     *   operationId="recruiter/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(Request $request)
    {
        $this->repository->pushCriteria(IndexCriteria::class);
        $this->repository->setPresenter(IndexPresenter::class);

        return apiReturn($this->repository->all(['id','name','email','avatar'])['data']);
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/recruiter/employers",
     *   tags={"employee/recruiter"},
     *   summary="recruiter employers",
     *   description="recruiter employers",
     *   operationId="recruiter/employers",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="recruiter_id",type="string",  description="recruiter ID", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function employers(Request $request)
    {
        $this->repository->pushCriteria(DetailCriteria::class);
        $this->repository->setPresenter(DetailPresenter::class);

        return apiReturn($this->repository->all(['id','name','email'])['data']);
    }

}
