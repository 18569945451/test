<?php

namespace App\Api\V4\Member\Controllers;

use App\Api\V4\Member\Criteria\Job\DetailCriteria;
use App\Api\V4\Member\Presenters\Job\DetailPresenter;
use Illuminate\Http\Request;
use App\Api\V4\Member\Validators\JobValidator;
use App\Api\V4\Member\Criteria\Job\ListCriteria;
use App\Api\V4\Member\Repositories\JobRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class JobController extends EnableGuestController
{
    protected $repository;
    protected $validator;

    public function __construct(JobRepository $repository, JobValidator $validator)
    {
        parent::__construct();
        $this->repository = $repository;
        $this->validator  = $validator;
    }
    /**
     * @SWG\Get(path="/index.php/api/employee/job/list",
     *   tags={"employee/job"},
     *   summary="工作列表",
     *   description="工作列表",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="query",  name="lat",type="string",  description="纬度", required=false),
     *   @SWG\Parameter(in="query",  name="lng",type="string",  description="经度", required=false),
     *   @SWG\Parameter(in="query",  name="publish_date_sort",type="string",  description="发布日期排序（nearest：早到晚，farthest：晚到早）", required=false),
     *   @SWG\Parameter(in="query",  name="distance_sort",type="string",  description="距离排序（nearest：从近到远，farthest：从远到近）", required=false),
     *   @SWG\Parameter(in="query",  name="hourly_rate_sort",type="string",  description="时薪高低（high：从高到低，low：从低到高）", required=false),
     *   @SWG\Parameter(in="query",  name="job_date_sort",type="string",  description="时薪高低（nearest：早到晚，farthest：晚到早）", required=false),
     *   @SWG\Parameter(in="query",  name="industry_id[]",type="string",  description="行业id", required=false),
     *   @SWG\Parameter(in="query",  name="employer_id[]",type="string",  description="雇主id", required=false),
     *   @SWG\Parameter(in="query",  name="start_time",type="string",  description="工作开始时间", required=false),
     *   @SWG\Parameter(in="query",  name="end_time",type="string",  description="工作结束时间", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=false),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function lists(Request $request)
    {
        try {
            $parameter = $this->validator->listQueryParameter($request);
            $this->repository->setQueryParameter($parameter);

            $this->repository->pushCriteria(ListCriteria::class);

            return apiReturn($this->repository->search());
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}
