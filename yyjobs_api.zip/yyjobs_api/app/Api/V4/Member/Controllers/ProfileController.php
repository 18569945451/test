<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/3
 * Time: 10:55
 */

namespace App\Api\V4\Member\Controllers;

use App\Api\V4\Member\Repositories\MemberInfoRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V4\Member\Validators\ProfileValidator;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Member\Repositories\ProfileRepository;
use Illuminate\Container\Container as Application;

class ProfileController extends Controller
{
    protected $validator;
    protected $repository;

    public function __construct(ProfileRepository $repository, ProfileValidator $validator)
    {
        $this->validator  = $validator;
        $this->repository = $repository;
    }
    /**
     * @SWG\Post(path="/index.php/api/employee/payment/password/set",
     *   tags={"employee/payment"},
     *   summary="设置支付密码",
     *   description="设置支付密码",
     *   operationId="password/set",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="payment_password",type="string",  description="支付密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function setPaymentPassword(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('setPaymentPassword');

            $memberId = auth('member')->user()->member_id;
            $data     = $this->repository->setPaymentPassword($request->payment_password, $memberId);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/payment/password/valid",
     *   tags={"employee/payment"},
     *   summary="验证旧支付密码",
     *   description="验证旧支付密码",
     *   operationId="payment/password/valid",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="payment_password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function validPaymentPassword(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('validPaymentPassword');

            $memberId = auth('member')->user()->member_id;
            $data     = $this->repository->validPaymentPassword($request->payment_password, $memberId);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/payment/password/forget",
     *   tags={"employee/payment"},
     *   summary="忘记支付密码",
     *   description="忘记支付密码",
     *   operationId="payment/password/forget",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="member_nric",type="string",  description="身份证号", required=true),
     *   @SWG\Parameter(in="formData",  name="member_mobile",type="string",  description="手机号(例+8617671757687)", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="formData",  name="password_confirmation",type="string",  description="确认密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function forgetPaymentPassword(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('forgetPaymentPassword');
            $memberId = auth('member')->user()->member_id;
            $data     = $this->repository->forgetPaymentPassword($request,$memberId);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/profile/edit_additional",
     *   tags={"employee/profile"},
     *   summary="修改附加信息",
     *   description="修改附加信息",
     *   operationId="edit",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="gender",type="string",  description="性别(1:男，2：女)", required=true),
     *   @SWG\Parameter(in="formData",  name="birthdate",type="string",  description="生日(时间戳)", required=true),
     *   @SWG\Parameter(in="formData",  name="religion",type="string",  description="宗教", required=false),
     *   @SWG\Parameter(in="formData",  name="address",type="string",  description="详细地址", required=true),
     *   @SWG\Parameter(in="formData",  name="school",type="string",  description="学校id", required=true),
     *   @SWG\Parameter(in="formData",  name="school_pass_expiry_date",type="string",  description="学生证到期时间", required=true),
     *   @SWG\Parameter(in="formData",  name="bank_account",type="string",  description="银行卡号", required=false),
     *   @SWG\Parameter(in="formData",  name="bank_account_img",type="file",  description="银行卡号照片", required=false),
     *   @SWG\Parameter(in="formData",  name="language",type="string",  description="语言（多个用,隔开）", required=true),
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=false),
     *   @SWG\Parameter(in="formData",  name="emergency_name",type="string",  description="紧急联系人", required=true),
     *   @SWG\Parameter(in="formData",  name="emergency_contact_no",type="string",  description="紧急联系人电话", required=true),
     *   @SWG\Parameter(in="formData",  name="emergency_relationship",type="string",  description="与紧急联系人的关系", required=true),
     *   @SWG\Parameter(in="formData",  name="emergency_address",type="string",  description="紧急联系人地址", required=true),
     *   @SWG\Parameter(in="formData",  name="contact_method",type="string",  description="本人联系方式[sms,phone,email,other]多个用,分隔", required=true),
     *   @SWG\Parameter(in="formData",  name="criminal_record",type="string",  description="犯罪记录", required=false),
     *   @SWG\Parameter(in="formData",  name="medication",type="string",  description="药物治疗史", required=false),
     *   @SWG\Parameter(in="formData",  name="ic_front",type="file",  description="身份证正面照", required=true),
     *   @SWG\Parameter(in="formData",  name="ic_back",type="file",  description="身份证反面照", required=true),
     *   @SWG\Parameter(in="formData",  name="signature",type="file",  description="签名图片", required=true),
     *   @SWG\Parameter(in="formData",  name="nationality",type="string",  description="国籍", required=true),
     *   @SWG\Parameter(in="formData",  name="employement_status",type="string",  description="就业状况[Singaporean, SPR, LTVP, DP, EP, SP, WP, Student Pass, Other]", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function editAdditional(Request $request)
    {
        try {
            $repository = new MemberInfoRepository(new Application());
            $this->validator->with($request->all())->passesOrFail('editAdditional');
            $formatData = $this->validator->formatEditAdditionalData($request);
            $data     = $repository->editMemberInfo($formatData);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }


}
