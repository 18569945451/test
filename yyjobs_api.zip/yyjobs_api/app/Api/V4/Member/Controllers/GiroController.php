<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/3
 * Time: 15:53
 */

namespace App\Api\V4\Member\Controllers;

use App\Api\V4\Member\Criteria\Giro\IndexCriteria;
use App\Api\V4\Member\Presenters\Giro\IndexPresenter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V4\Member\Validators\GiroValidator;
use App\Api\V4\Member\Repositories\GiroRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class GiroController extends Controller
{
    protected $validator;
    protected $repository;

    public function __construct(GiroRepository $repository, GiroValidator $validator)
    {
        $this->validator  = $validator;
        $this->repository = $repository;
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/giro/apply",
     *   tags={"employee/giro"},
     *   summary="银行卡提现申请",
     *   description="银行卡提现申请",
     *   operationId="giro/apply",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData", name="payment_password",type="string",  description="支付密码", required=true),
     *   @SWG\Parameter(in="formData", name="salary_amount",type="number",  description="提现金额", required=true),
     *   @SWG\Parameter(in="formData", name="bank_account",type="string",  description="银行卡号", required=true),
     *   @SWG\Parameter(in="formData", name="receive_name",type="string",  description="收款人姓名", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function apply(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('apply');
            $data     = $this->repository->apply($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/giro/index",
     *   tags={"employee/giro"},
     *   summary="Giro index",
     *   description="Giro index",
     *   operationId="giro/index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index()
    {
        $this->repository->pushCriteria(IndexCriteria::class);
        $this->repository->setPresenter(IndexPresenter::class);
        $data = $this->repository->first()['data'] ? $this->repository->first()['data'] : null;
        return apiReturn($data);
    }
}
