<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 15:45
 */

namespace App\Api\V4\Member\Controllers;

use App\Api\V4\Member\Presenters\SalaryTransaction\ListPresenter;
use App\Http\Controllers\Controller;
use App\Api\V4\Member\Validators\SalaryTransactionValidator;
use App\Api\V4\Member\Repositories\SalaryTransactionRepository;
use Illuminate\Http\Request;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V4\Member\Criteria\SalaryTransaction\ListCriteria;
class SalaryTransactionController extends Controller
{
    protected $validator;
    protected $repository;

    public function __construct(SalaryTransactionRepository $repository, SalaryTransactionValidator $validator)
    {
        $this->validator  = $validator;
        $this->repository = $repository;
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/transaction/detail",
     *   tags={"employee/transaction"},
     *   summary="交易详情",
     *   description="交易详情",
     *   operationId="transaction/detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="id",  type="number",  description="交易ID",required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('detail');
            $data = $this->repository->detail(auth('member')->user()->member_id,$request->id);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/transaction/list",
     *   tags={"employee/transaction"},
     *   summary="交易历史列表",
     *   description="交易历史列表",
     *   operationId="transaction/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="query",  name="start_date",type="string",  description="开始日期(2018-10-14)", required=false),
     *   @SWG\Parameter(in="query",  name="end_date",type="string",  description="结束日期(2018-10-20)", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function transactionList(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('transactionList');
            $this->repository->pushCriteria(ListCriteria::class);
            //$this->repository->setPresenter(ListPresenter::class);
            $data = $this->repository->transactionList($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}
