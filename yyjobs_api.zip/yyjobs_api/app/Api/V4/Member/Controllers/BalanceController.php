<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 15:01
 */

namespace App\Api\V4\Member\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V4\Member\Validators\ProfileValidator;
use App\Api\V4\Member\Repositories\ProfileRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class BalanceController extends Controller
{
    protected $validator;
    protected $repository;

    public function __construct(ProfileRepository $repository, ProfileValidator $validator)
    {
        $this->validator  = $validator;
        $this->repository = $repository;
    }
    /**
     * @SWG\Get(path="/index.php/api/employee/balance/index",
     *   tags={"employee/balance"},
     *   summary="balance index",
     *   description="balance index",
     *   operationId="balance/index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v4+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(Request $request)
    {
        $data     = $this->repository->balanceIndex(auth('member')->user()->member_id);
        return apiReturn($data);
    }
}
