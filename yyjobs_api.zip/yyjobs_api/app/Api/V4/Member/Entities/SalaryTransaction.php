<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 15:27
 */

namespace App\Api\V4\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class SalaryTransaction extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'salary_transaction';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable
        = [
            'member_id',
            'salary_amount',
            'transaction_name',
            'transaction_time',
            'transaction_id',
            'transaction_type',
        ];

    public $timestamps = false;

    /**
     * 获得拥有此评论的模型。
     */
    public function transaction()
    {
        return $this->morphTo();
    }

    public function issues()
    {
        return $this->hasOne(ReportIssues::class,'salary_transaction_id','id');
    }
}