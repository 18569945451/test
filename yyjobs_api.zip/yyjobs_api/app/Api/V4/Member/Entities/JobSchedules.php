<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 15:33
 */

namespace App\Api\V4\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class JobSchedules extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'job_schedules';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 's_id';

    /**
     * @var array
     */
    protected $fillable = ['member_id', 'member_name', 'job_id', 'is_assigned', 'cancel_status', 'cancel_reason', 'cancel_image', 'cancel_time', 'checkin_time', 'adjusted_checkin_time', 'checkin_signature', 'checkin_address', 'checkout_time', 'adjusted_checkout_time', 'checkout_signature', 'checkout_address', 'work_hours', 'adjusted_work_minutes', 'adjusted_hourly_rate', 'employer_rate', 'job_salary', 'job_rating', 'reviews', 'process_date', 'payment_methods', 'add_time', 'update_time', 'member_current_lat', 'member_current_long', 'deduction', 'cpf', 'cpf_deduction', 'remark', 'processor', 'work_status', 'check_status', 'is_send', 'parent_id',];

    public $timestamps = false;

    public function getWorkMinutes($timeIn = 0,$timeOut = 0 ,$adjustedHours = 0)
    {
        if ( ! $timeIn || ! $timeOut) {return 0;}

        $diff = ($timeOut - $timeIn) / 60;
        return $diff / 60 + $adjustedHours;
        //return (($diff - ($diff % 15)) / 15 * 0.25) + $adjustedHours;
    }

    public function salaryTransaction()
    {
        return $this->morphMany(SalaryTransaction::class, 'job','transaction_type','transaction_id','s_id');
    }

    public function job()
    {
        return $this->belongsTo(Job::class,'job_id','job_id');
    }

    public function member()
    {
        return $this->belongsTo(Member::class,'member_id','member_id');
    }

    public function pairsChild()
    {
        return $this->hasMany(self::class,'parent_id','s_id');
    }

    public function reportIssues()
    {
        return $this->hasOne(ReportIssues::class,'transaction_id','s_id');
    }
}