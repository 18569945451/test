<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 14:46
 */

namespace App\Api\V4\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class RecruiterEvaluate extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'recruiter_evaluate';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable
        = [
            'member_id',
            'recruiter_id',
            'apply',
            'efficiency',
            'detail',
            'attitude',
            'problem',
            'overall',
            'recommend',
            'comment',
            'created_at',
        ];

    public $timestamps = false;

    public function member()
    {
        return $this->belongsTo(Member::class, 'member_id', 'member_id');
    }
}