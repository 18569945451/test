<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/3
 * Time: 15:50
 */

namespace App\Api\V4\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class Giro extends Model
{
    //表名
    protected $table = 'giro';

    //主键
    protected $primaryKey = 'id';

    //fillable
    protected $fillable = ['member_id', 'giro_date', 'salary_amount', 'bank_name', 'bank_account', 'receive_name', 'request_time', 'process_time', 'processor', 'status',];

    //status
    public $giroStatus = [
        1 => 'Scheduled',
        2 => 'Processed',
        3 => 'Failed',
    ];

    //timestamps
    public $timestamps = false;

    public function member()
    {
        return $this->belongsTo(Member::class, 'member_id', 'member_id');
    }

    public function salaryTransaction()
    {
        return $this->morphMany(SalaryTransaction::class, 'giro','transaction_type','transaction_id','id');
    }
}