<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/6
 * Time: 13:58
 */

namespace App\Api\V4\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class ReportIssues extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'report_issues';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable
        = [
            'salary_transaction_id',
            'transaction_id',
            'report_salary',
            'report_minutes',
            'member_id',
            'ticket_num',
            'report_time',
            'desc',
            'remark',
            'status',
        ];

    public $timestamps = false;

    public function schedule()
    {
        return $this->hasOne(JobSchedules::class,'s_id','transaction_id');
    }

    public function salaryTransaction()
    {
        return $this->hasOne(SalaryTransaction::class,'id','salary_transaction_id');
    }
}