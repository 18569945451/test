<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 10:33
 */

namespace App\Api\V4\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class Counter extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'counter';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable
        = [
            'member_id',
            'queue_num',
            'counter_date',
            'salary_amount',
            'request_time',
            'process_time',
            'processor',
            'type',
            'status',
        ];

    public $timestamps = false;

    public function member()
    {
        return $this->belongsTo(Member::class, 'member_id', 'member_id');
    }

    public function salaryTransaction()
    {
        return $this->morphMany(SalaryTransaction::class, 'counter','transaction_type','transaction_id','id');
    }
}