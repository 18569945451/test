<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 17:15
 */

namespace App\Api\V4\Member\Criteria\Giro;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class IndexCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $memberID = auth('member')->user()->member_id;
        return $model->where('member_id',$memberID)->where('status',1);
    }
}