<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 11:51
 */

namespace App\Api\V4\Member\Criteria\SalaryTransaction;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $memberID  = auth('member')->user()->member_id;
        $keyword   = request()->input('keyword');
        $startDate = request()->input('start_date');
        $endDate   = request()->input('end_date');

        return $model->with('transaction')
            ->when($keyword,function ($query)use($keyword){
                return $query->where(function($subQuery)use($keyword){
                    return $subQuery->where('transaction_name','like',"%{$keyword}%")
                        ->orWhere('search_value1','like',"%{$keyword}%")
                        ->orWhere('search_value2','like',"%{$keyword}%")
                        ->orWhere('search_value3','like',"%{$keyword}%")
                        ->orWhere('transaction_type','like',"%{$keyword}%");
                });

            })
            ->when($startDate && $endDate,function ($query)use ($startDate,$endDate){
                $between = [
                    Carbon::parse($startDate),
                    Carbon::parse($endDate)->addDay()
                ];
                return $query->whereBetween('transaction_time',$between);
            })
            ->where('member_id',$memberID);
    }
}