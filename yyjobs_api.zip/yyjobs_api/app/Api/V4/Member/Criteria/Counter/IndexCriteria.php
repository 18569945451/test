<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 17:26
 */

namespace App\Api\V4\Member\Criteria\Counter;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class IndexCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $memberID = auth('member')->user()->member_id;
        return $model->where('member_id',$memberID)->where('counter_date','>=',Carbon::today()->format('Y-m-d'))->whereIn('status',[1,2]);
    }
}