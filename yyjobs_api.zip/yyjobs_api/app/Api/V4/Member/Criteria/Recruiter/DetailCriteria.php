<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 16:45
 */

namespace App\Api\V4\Member\Criteria\Recruiter;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class DetailCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $recruiter = $model->find(request('recruiter_id'));
        if ($recruiter->has_employer) {
            $employerIDs = explode(',', $recruiter->has_employer);
            //$hasEmployer = array_slice($employerIDs,0,3);
            $hasEmployer = $employerIDs;
        } else {
            $hasEmployer = [0];
        }

        return $model->where('type',1)->whereIn('id',$hasEmployer);
    }
}