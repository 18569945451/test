<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 15:20
 */

namespace App\Api\V4\Member\Criteria\Recruiter;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class IndexCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $notIn = [
            173,190,191,305,153,66
        ];
        return $model->where('type',2)->whereNotIn('id',$notIn)->orderBy('name','ASC');
    }
}