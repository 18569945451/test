<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/3
 * Time: 10:59
 */

namespace App\Api\V4\Member\Validators;

use App\Api\V1\Repositories\FileRepository;
use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class ProfileValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'setPaymentPassword'    => [
                'payment_password' => 'required|string|size:6',
            ],
            'validPaymentPassword'  => [
                'payment_password' => 'required|string|size:6',
            ],
            'forgetPaymentPassword' => [
                'member_nric'   => 'required|string',
                'member_mobile' => 'required|string',
                'password'      => 'required|string|size:6|confirmed',
            ],
            'editAdditional'        => [
                'gender'                  => 'required|integer|in:1,2',
                'birthdate'               => 'required|integer',
                'religion'                => 'sometimes|string|max:255',
                'address'                 => 'required|string|max:512',
                'school'                  => 'required|integer',
                'school_pass_expiry_date' => 'required|integer',
                'bank_account'            => 'sometimes|string',
                'bank_account_img'        => 'sometimes|image',
                'language'                => 'required|string',
                'email'                   => 'sometimes|email',
                'emergency_name'          => 'required|string',
                'emergency_contact_no'    => 'required|string',
                'emergency_relationship'  => 'required|string',
                'emergency_address'       => 'required|string',
                'contact_method'          => 'required|string',
                'criminal_record'         => 'sometimes|string',
                'medication'              => 'sometimes|string',
                'ic_front'                => 'required|image',
                'ic_back'                 => 'required|image',
                'signature'               => 'required|image',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    public function formatEditAdditionalData($request)
    {
        $memberId = auth('member')->user()->member_id;
        $data     = [
            'member_id' => $memberId,
            'member'    => [
                'member_sex'       => $request->gender,
                'member_birthday'  => $request->birthdate,
                'member_school_id' => $request->school,
                'member_email'     => $request->email,
                'member_id'        => $memberId,
            ],
            'info'      => [
                'member_id'                   => $memberId,
                'info_religion'               => $request->input('religion', 'none'),
                'info_address'                => $request->address,
                'info_school_expiry_date'     => $request->school_pass_expiry_date,
                'info_bank_statement'         => $request->input('bank_account', ''),
                'info_language'               => strtolower(str_replace('，', ',', $request->input('language'))),
                'info_emergency_name'         => $request->emergency_name,
                'info_emergency_phone'        => $request->emergency_contact_no,
                'info_emergency_relationship' => $request->emergency_relationship,
                'info_emergency_address'      => $request->emergency_address,
                'info_contact_method'         => strtolower(str_replace('，', ',', $request->contact_method)),
                'info_criminal_record'        => $request->input('criminal_record', 'none'),
                'info_medication'             => $request->input('medication', 'none'),
                'info_nationality'            => $request->nationality,
                'employement_status'          => $request->input('employement_status','Other'),
            ],
        ];

        $fileRepository = app(FileRepository::class);
        $filePath       = generateFilePath();
        if ($request->file('ic_front')) {
            $data['info']['info_nric_zheng'] = $fileRepository->imageReSize($request->file('ic_front'), $filePath);
        }
        if ($request->file('ic_back')) {
            $data['info']['info_nric_fan'] = $fileRepository->imageReSize($request->file('ic_back'), $filePath);
        }
        if ($request->file('signature')) {
            $data['info']['info_signature'] = $fileRepository->imageReSize($request->file('signature'), $filePath);
        }
        if ($request->file('bank_account_img')) {
            $data['info']['info_bank_statement_img'] = $fileRepository->imageReSize($request->file('bank_account_img'), $filePath);
        }

        return $data;
    }
}