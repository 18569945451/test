<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/3
 * Time: 15:56
 */

namespace App\Api\V4\Member\Validators;

use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class GiroValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'apply' => [
                'payment_password' => 'required|string|size:6',
                'salary_amount'    => 'required|numeric|min:0.01',
                'bank_account'     => 'required|string',
                'receive_name'     => 'required|string',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];
}