<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/1
 * Time: 10:49
 */

namespace App\Api\V4\Member\Validators;

use Illuminate\Http\Request;
use \Prettus\Validator\Contracts\ValidatorInterface;
use \Prettus\Validator\LaravelValidator;

class JobValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'lists'  => [
                'cur_page'  => 'numeric|min:1',
                'page_size' => 'numeric|min:1',
                'start_time' => 'numeric|min:1',
            ],
            'detail' => [
                'job_id' => 'required|numeric',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    /**
     * @param Request $request
     * @return array
     */
    public function listQueryParameter(Request $request)
    {
        $query = [
            'cur_page'   => $request->input('cur_page', 1),
            'page_size'  => $request->input('page_size', 15),
            'start_time' => $request->input('start_time', time()-3600*2),
            'end_time'   => $request->input('end_time'),
        ];

        //行业
        $industryId = $request->input('industry_id',[]);
        $query['industry_id'] = !is_array($industryId)
                                ? explode(',',$industryId)
                                : $request->industry_id;

        //雇主
        $employerId = $request->input('employer_id',[]);
        $query['employer_id'] = !is_array($employerId)
                                ? explode(',',$employerId)
                                : $request->employer_id;

        //关键字
        $query['keyword']     = $request->input('keyword','');

        //发布日期
        $publishDateSort = $request->input('publish_date_sort','');
        if ($publishDateSort){
            $query['order']['field'] = 'job_add_time';
            if ($publishDateSort == 'nearest'){
                $query['order']['sort'] = 'asc';
            }
            if ($publishDateSort == 'farthest'){
                $query['order']['sort'] = 'desc';
            }
        }

        //坐标距离
        $query['lat']         = $request->input('lat','');
        $query['lng']         = $request->input('lng','');
        $query['has_gps']     = $query['lat'] && $query['lng'] ? 1 : 0;
        if ($query['has_gps']){
            $distanceSort = $request->input('distance_sort','');
            if ($distanceSort){
                $query['order']['field'] = 'distance';
                if ($distanceSort == 'nearest'){
                    $query['order']['sort'] = 'asc';
                }
                if ($distanceSort == 'farthest'){
                    $query['order']['sort'] = 'desc';
                }
            }
        }


        //时薪
        $hourlyRateOrderBy = $request->input('hourly_rate_sort','');
        if ($hourlyRateOrderBy){
            $query['order']['field'] = 'job_hour_rate';
            if ($hourlyRateOrderBy == 'high'){
                $query['order']['sort'] = 'desc';
            }
            if ($hourlyRateOrderBy == 'low'){
                $query['order']['sort'] = 'asc';
            }
        }

        //工作早晚
        $jobDateSort = $request->input('job_date_sort','');
        if ($jobDateSort){
            $query['order']['field'] = 'job_start_date';
            if ($jobDateSort == 'nearest'){
                $query['order']['sort'] = 'asc';
            }
            if ($jobDateSort == 'farthest'){
                $query['order']['sort'] = 'desc';
            }
        }

        if (!isset($query['order'])){
            $query['order']['field'] = 'job_start_date';
            $query['order']['sort'] = 'asc';
        }

        return $query;

    }
}