<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 10:31
 */

namespace App\Api\V4\Member\Validators;

use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;
use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class CounterValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'apply' => [
                'payment_password' => 'required|string|size:6',
                'salary_amount'    => 'required|numeric|min:0.01',
                'counter_date'     => 'required|date',
            ],
            'scan'  => [
                'payment_password' => 'required|string|size:6',
                'type'             => 'required|string|in:counter',
                'amount'           => 'required|numeric|min:0.01',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    /**
     * @param string $date
     *
     * @return bool
     * @throws ValidatorException
     */
    public function workDay(string $date)
    {
        $day = date('w', strtotime($date));
        if (in_array($day, [0, 6])) {
            throw new ValidatorException(new MessageBag(['Please choose the date from Monday to Friday.']));
        }

        return true;
    }
}