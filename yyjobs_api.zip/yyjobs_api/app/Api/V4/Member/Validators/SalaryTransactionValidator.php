<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 15:46
 */

namespace App\Api\V4\Member\Validators;

use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class SalaryTransactionValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'detail'          => [
                'id' => 'required|integer',
            ],
            'transactionList' => [
                'keyword'    => 'sometimes|string|max:32',
                'start_date' => 'sometimes|date',
                'end_date'   => 'sometimes|date',
                'cur_page'   => 'sometimes|integer|min:0',
                'page_size'  => 'sometimes|integer|min:1',
            ],
        ];

    protected $messages
        = [
            'cur_page.integer'=>'current page parameters must be integers',
            'page_size.integer'=>'the number of entries per page must be an integer',
        ];
}