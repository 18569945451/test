<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/6
 * Time: 14:07
 */

namespace App\Api\V4\Member\Validators;

use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class ReportIssuesValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'apply' => [
                'salary_transaction_id' => 'required|integer',
                'report_salary'         => 'required|numeric',
                'desc'                  => 'required|string|max:1024',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];
}