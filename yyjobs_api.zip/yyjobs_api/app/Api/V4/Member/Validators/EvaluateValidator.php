<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/50
 * Time: 14:50
 */

namespace App\Api\V4\Member\Validators;

use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class EvaluateValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'rate' => [
                'apply'      => 'required|integer|between:0,4',
                'efficiency' => 'required|integer|between:0,4',
                'detail'     => 'required|integer|between:0,4',
                'attitude'   => 'required|integer|between:0,4',
                'problem'    => 'required|integer|between:0,4',
                'overall'    => 'required|integer|between:0,4',
                'recommend'  => 'required|integer',
                'comment'    => 'sometimes|string|between:0,1000',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];
}