<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 17:26
 */

namespace App\Api\V4\Member\Transformers\Counter;

use App\Api\V4\Member\Entities\Counter;
use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class IndexTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Member\Entities\Counter $model
     *
     * @return array
     */
    public function transform($model)
    {
        if(!$model){
            return [];
        }
        return [
            'id'            => $model->id,
            'member_id'     => $model->member_id,
            'queue_num'     => $model->queue_num,
            'salary_amount' => $model->salary_amount,
            'counter_date'  => Carbon::parse($model->counter_date)->getTimestamp(),
            'request_time'  => Carbon::parse($model->request_time)->getTimestamp(),
        ];
    }
}