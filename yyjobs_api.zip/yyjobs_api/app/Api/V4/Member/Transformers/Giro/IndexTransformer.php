<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 17:13
 */

namespace App\Api\V4\Member\Transformers\Giro;

use App\Api\V4\Member\Entities\Giro;
use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class IndexTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Member\Entities\Giro $model
     *
     * @return array
     */
    public function transform($model)
    {
        if(!$model){
            return [];
        }
        return [
            'id'            => $model->id,
            'member_id'     => $model->member_id,
            'giro_date'     => Carbon::parse($model->giro_date)->getTimestamp(),
            'salary_amount' => $model->salary_amount,
            'bank_name'     => $model->bank_name,
            'bank_account'  => $model->bank_account,
            'receive_name'  => $model->receive_name,
            'request_time'  => Carbon::parse($model->request_time)->getTimestamp(),
            'status'        => $model->giroStatus[$model->status],
        ];
    }
}