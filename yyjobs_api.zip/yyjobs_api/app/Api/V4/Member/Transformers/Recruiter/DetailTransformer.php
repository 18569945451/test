<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 16:55
 */

namespace App\Api\V4\Member\Transformers\Recruiter;

use App\Api\V4\Member\Entities\Recruiter;
use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class DetailTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Member\Entities\Recruiter $model
     *
     * @return array
     */
    public function transform(Recruiter $model)
    {
        return $model->toArray();
    }
}