<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 15:22
 */

namespace App\Api\V4\Member\Transformers\Recruiter;

use App\Api\V4\Member\Entities\Recruiter;
use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class IndexTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Member\Entities\Recruiter $model
     *
     * @return array
     */
    public function transform(Recruiter $model)
    {
        return $model->toArray();
        /*return [
            'id'            => $model->id,
            'member_id'     => $model->member_id,
            'queue_num'     => $model->queue_num,
            'salary_amount' => $model->salary_amount,
            'counter_date'  => Carbon::parse($model->counter_date)->getTimestamp(),
            'request_time'  => Carbon::parse($model->request_time)->getTimestamp(),
        ];*/
    }
}