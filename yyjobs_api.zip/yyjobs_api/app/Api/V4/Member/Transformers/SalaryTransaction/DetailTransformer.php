<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 18:26
 */

namespace App\Api\V4\Member\Transformers\SalaryTransaction;

use App\Api\V4\Member\Entities\JobSchedules;
use App\Api\V4\Member\Entities\ReportIssues;
use App\Api\V4\Member\Entities\SalaryTransaction;
use Carbon\Carbon;

/**
 * Class DetailTransformer
 *
 * @package App\Api\V4\Member\Transformers\Job
 */
class DetailTransformer
{
    /**
     * giro类型转换
     * @param SalaryTransaction $model
     *
     * @return mixed
     */
    public function giroTransform(SalaryTransaction $model)
    {
        $data['id']                = $model->id;
        $data['type']              = $model->transaction_type;
        $data['member_id']         = $model->member_id;
        $data['processed_time']    = Carbon::parse($model->transaction_time)->getTimestamp();
        $data['salary_amount']     = $model->salary_amount;
        $data['giro_date']         = $model->transaction->giro_date;
        $data['bank_account']      = $model->transaction->bank_account;
        $data['bank_receive_name'] = $model->transaction->receive_name;
        $data['status']            = $model->transaction->giroStatus[$model->transaction->status];
        $data['employer']          = 'Hong Ye Group Pte.Ltd';
        return $data;
    }

    /**
     * job类型转换
     * @param SalaryTransaction $model
     *
     * @return mixed
     */
    public function jobTransform(SalaryTransaction $model)
    {
        $data['id']                = $model->id;
        $data['type']              = $model->transaction_type;
        $data['member_id']         = $model->member_id;
        $data['processed_time']    = Carbon::parse($model->transaction_time)->getTimestamp();
        $data['salary_amount']     = $model->salary_amount;
        $data['payable_amount']    = $model->payable_amount;
        $data['cpf_deduction']     = $model->payable_amount - $model->salary_amount;
        $data['employer']          = $model->search_value1;
        $data['custom']            = $model->custom;
        $data['remark']            = $model->remark;

        //获取所有跟此条相关的
        $schedules = JobSchedules::with(['job','member'])->where('job_id',$model->transaction->job->job_id)
                    ->where('member_id',$model->member_id)
                    ->whereIn('work_status',[6,8])
                    ->orderBy('parent_id','ASC')
                    ->orderBy('s_id','ASC')->get();

        $result = [];

        //根据父子关系计算工时
        foreach ($schedules as $key => $schedule) {

            $originMinutes = $model->transaction->getWorkMinutes($schedule->adjusted_checkin_time,$schedule->adjusted_checkout_time) * 60;
            $total         = round($schedule->adjusted_work_minutes / 60,2);
            $hours         = round(($schedule->adjusted_work_minutes- $originMinutes) / 60,2);

            $result[$key]['s_id']               = $schedule->s_id;
            $result[$key]['job_id']             = $schedule->job_id;
            $result[$key]['job_date']           = Carbon::createFromTimestamp($schedule->job->job_start_date)->format('Y-m-d H:i:s');
            $result[$key]['employer_name']      = $schedule->job->job_employer_company_name;
            $result[$key]['job_title']          = $schedule->job->job_title;
            $result[$key]['job_image']          = $schedule->job->job_image;
            $result[$key]['job_start_date']     = Carbon::createFromTimestamp($schedule->adjusted_checkin_time)->format('H:i');
            $result[$key]['job_end_date']       = Carbon::createFromTimestamp($schedule->adjusted_checkout_time)->format('H:i');
            $result[$key]['checkin']            = $schedule->checkin_time ? Carbon::createFromTimestamp($schedule->adjusted_checkin_time)->format('H:i') : '';
            $result[$key]['checkout']           = $schedule->checkout_time ? Carbon::createFromTimestamp($schedule->adjusted_checkout_time)->format('H:i') : '';

            if ($schedule->parent_id == 0){
                $result[$key]['hours'] = $hours;
                $result[$key]['total'] = $total;
            }else{
                $thanPre = $total - $result[$key-1]['origin_total'];
                $result[$key]['hours'] = 0;
                $result[$key]['total'] = $thanPre;
            }

            $result[$key]['deduction']          = $schedule->deduction;
            $result[$key]['cpf_deduction']      = $schedule->cpf_deduction;
            $result[$key]['hourly_rate']        = $schedule->adjusted_hourly_rate ? $schedule->adjusted_hourly_rate : $schedule->member->member_salary_rate;
            $result[$key]['origin_total']       = $total;
            $result[$key]['remark']             = $schedule->remark;
            $result[$key]['parent_id']          = $schedule->parent_id;

        }

        //返回指定的一条记录
        $jobSchedule = array_column($result,null,'s_id');
        $data['schedule'] = $jobSchedule[$model->transaction_id];

        //remark 修改 2019-05-09 10:32
        if ($model->remark){
            $data['schedule']['remark'] = $model->remark;
        }

        $data['report'] = $model->issues;

        return $data;
    }

    /**
     * counter类型转换
     * @param SalaryTransaction $model
     *
     * @return mixed
     */
    public function counterTransform(SalaryTransaction $model)
    {
        $data['id']                = $model->id;
        $data['type']              = $model->transaction_type;
        $data['member_id']         = $model->member_id;
        $data['processed_time']    = Carbon::parse($model->transaction_time)->getTimestamp();
        $data['salary_amount']     = $model->salary_amount;
        $data['employer']          = 'Hong Ye Group Pte.Ltd';
        return $data;
    }

    /**
     * @param $models
     *
     * @return array
     */
    public function listTransform($models)
    {
        $data = [];
        foreach ($models as $key => $transaction) {
            $data[$key]['id']             = $transaction->id;
            $data[$key]['type']           = $transaction->transaction_type;
            $data[$key]['salary_amount']  = $transaction->salary_amount;
            $data[$key]['processed_time'] = Carbon::parse($transaction->transaction_time)->getTimestamp();
            $data[$key]['image'] = '';
            $data[$key]['employer'] = 'Hong Ye Group Pte.Ltd';
            switch ($transaction->transaction_type) {
                case 'giro':    $data[$key]['title'] = 'Giro';break;
                case 'job':
                    $data[$key]['title'] = $transaction->transaction->job->job_title;
                    $data[$key]['image'] = $transaction->transaction->job->job_image;
                    $data[$key]['employer'] = $transaction->search_value1;
                    break;
                case 'counter': $data[$key]['title'] = 'Cash Collection';break;
                default:break;
            }
        }
        return $data;
    }
}