<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 11:54
 */

namespace App\Api\V4\Member\Transformers\SalaryTransaction;

use League\Fractal\TransformerAbstract;
use App\Api\V4\Member\Entities\SalaryTransaction;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V4\Member\Entities\SalaryTransaction $model
     *
     * @return SalaryTransaction
     */
    public function transform(SalaryTransaction $model)
    {
        return $model->toArray();
    }
}