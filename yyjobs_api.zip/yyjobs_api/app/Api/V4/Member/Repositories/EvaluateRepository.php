<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 14:49
 */

namespace App\Api\V4\Member\Repositories;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V4\Member\Entities\RecruiterEvaluate;

class EvaluateRepository extends BaseRepository
{
    public function model()
    {
        return RecruiterEvaluate::class;
    }

    /**
     * @param Request $request
     *
     * @return mixed
     */
    public function rate(Request $request)
    {
        $request->request->add([
            'member_id'  => auth('member')->user()->member_id,
            'created_at' => Carbon::now(),
        ]);

        return $this->create($request->all());
    }
}