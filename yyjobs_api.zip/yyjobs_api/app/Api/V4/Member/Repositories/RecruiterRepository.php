<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 15:15
 */

namespace App\Api\V4\Member\Repositories;

use App\Api\V4\Member\Entities\Recruiter;
use Prettus\Repository\Eloquent\BaseRepository;

class RecruiterRepository extends BaseRepository
{
    public function model()
    {
        return Recruiter::class;
    }
}