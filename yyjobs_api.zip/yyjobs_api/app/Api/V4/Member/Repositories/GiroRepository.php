<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/3
 * Time: 15:55
 */

namespace App\Api\V4\Member\Repositories;

use DB;
use Carbon\Carbon;
use App\Api\V4\Member\Entities\Giro;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class GiroRepository extends BaseRepository
{
    public function model()
    {
        return Giro::class;
    }

    /**
     * @param $request
     *
     * @return mixed
     * @throws ValidatorException
     */
    public function apply($request)
    {
        $member = auth('member')->user();

        //验证支付密码
        $profileRep = new ProfileRepository($this->app);
        $profileRep->validPaymentPassword($request->payment_password,$member->member_id);
        
        //验证金额是否足够
        if ($request->salary_amount > $member->salary){
            throw new ValidatorException(new MessageBag(["You don't have enough money to withdraw."]));
        }

        //是否有未处理的提现申请
        if ($this->hasUntreated($member->member_id)){
            throw new ValidatorException(new MessageBag(["You have an unprocessed application for giro. You can't repeat the application."]));
        }

        $giro = [
            'member_id'     => $member->member_id,
            'giro_date'     => $this->nextGiroDate(),
            'salary_amount' => $request->salary_amount,
            'bank_account'  => $request->bank_account,
            'receive_name'  => $request->receive_name,
            'request_time'  => Carbon::now()->format('Y-m-d H:i:s'),
        ];
        DB::beginTransaction();
        try {
            //冻结金额
            $profileRep->setFrozenSalary($request->salary_amount,$member->member_id);
            $res = $this->create($giro);
            DB::commit();
            return $res;
        } catch(\Exception $e) {
            DB::rollback();
            throw new ValidatorException(new MessageBag(["Application failure."]));
        }
    }

    /**
     * 正在转账流程中的数据
     * @param $memberID
     */
    public function inExec($memberID)
    {
        return $this->model->where('member_id',$memberID)->where('status',1)->first();
    }

    /**
     * 获取下次Giro转账处理日期
     * @return string
     */
    protected function nextGiroDate(){
        $today = date('w');
        if ($today == 1){
            return Carbon::today()->modify('Tuesday')->format('Y-m-d');
        }elseif($today  > 1 && $today < 4){
            return Carbon::today()->modify('Thursday')->format('Y-m-d');
        }else{
            return Carbon::today()->modify('next Tuesday')->format('Y-m-d');
        }
    }

    /**
     * 是否有未处理的提现申请
     * @param $memberID
     *
     * @return bool
     */
    protected function hasUntreated($memberID)
    {
        return !!$this->model->where(['member_id'=>$memberID,'status'=>1])->count();
    }
}