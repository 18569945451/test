<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/1/14
 * Time: 11:14
 */

namespace App\Api\V4\Member\Repositories;

use App\Api\V4\Member\Entities\MemberInfo;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class MemberInfoRepository extends BaseRepository
{
    public function model()
    {
        return MemberInfo::class;
    }

    /**
     * @param array $formatData
     *
     * @throws ValidatorException
     */
    public function editMemberInfo(array $formatData)
    {
        try{
            $memberRep = new ProfileRepository($this->app);
            $memberRep->update($formatData['member'], $formatData['member_id']);
            $info = $this->model->whereMemberId($formatData['member_id'])->first();
            if ($info){
                $result = $this->model->whereMemberId($formatData['member_id'])->update($formatData['info']);
            }else{
                $result = $this->model->create($formatData['info']);
            }
            return $result;
        }catch (\Exception $e){
            throw new ValidatorException(new MessageBag([$e->getMessage()]));
        }
    }
}