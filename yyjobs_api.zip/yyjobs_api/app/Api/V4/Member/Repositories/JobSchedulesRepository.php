<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/03
 * Time: 16:10
 */

namespace App\Api\V4\Member\Repositories;

use App\Api\V4\Member\Entities\JobSchedules;
use Prettus\Repository\Eloquent\BaseRepository;


class JobSchedulesRepository extends BaseRepository
{
    public function model()
    {
        return JobSchedules::class;
    }

    /**
     * @param $model
     *
     * @return string
     */
    public function getHours($model)
    {
        if ($model->parent_id == 0){
            $workTime = $model->adjusted_work_minutes ? $model->adjusted_work_minutes : $model->member->work_hours;
            return $workTime;
        }

        $parent = $this->find($model->parent_id);
        $pairsChild = $parent->pairsChild()->get();

        $pairsChilds = array_column($pairsChild->toArray(),null,'s_id');
        $ids = array_column($pairsChilds,'s_id');
        foreach ($ids as $key=>$value) {
            if ($value >= $model->s_id){
                unset($ids[$key]);
            }
        }

        if ($ids){
            $preSchedule = $pairsChilds[max($ids)];
            return $model->adjusted_work_minutes - $preSchedule['adjusted_work_minutes'];
        }else{
            return $model->adjusted_work_minutes - $parent->adjusted_work_minutes;
        }
    }
}