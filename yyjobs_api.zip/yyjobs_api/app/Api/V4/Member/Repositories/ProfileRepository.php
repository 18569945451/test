<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/3
 * Time: 11:10
 */

namespace App\Api\V4\Member\Repositories;

use Hash;
use App\Api\V4\Member\Entities\Member;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;


class ProfileRepository extends BaseRepository
{
    public function model()
    {
        return Member::class;
    }

    /**
     * @param $paymentPassword
     * @param $memberId
     *
     * @return bool
     * @throws ValidatorException
     */
    public function setPaymentPassword($paymentPassword, $memberId)
    {
        $member = $this->find($memberId);
        if ($member->member_payment_password) {
            throw new ValidatorException(
                new MessageBag(['You have set the payment password, please do not repeat the settings.'])
            );
        }

        return ! ! $this->update(['member_payment_password' => bcrypt($paymentPassword)], $memberId);
    }

    /**
     * @param $paymentPassword
     * @param $memberId
     *
     * @return bool
     * @throws ValidatorException
     */
    public function validPaymentPassword($paymentPassword, $memberId)
    {
        $member = $this->find($memberId);
        if ( ! Hash::check($paymentPassword, $member->member_payment_password)) {
            throw new ValidatorException(new MessageBag(['Incorrect payment password.']));
        }

        return true;
    }

    /**
     * @param $request
     * @param $memberId
     *
     * @return bool
     * @throws ValidatorException
     */
    public function forgetPaymentPassword($request, $memberId)
    {
        $member = $this->find($memberId);
        if ($request->member_mobile != $member->member_mobile) {
            throw new ValidatorException(new MessageBag(['Verify that the phone number is incorrect.']));
        }
        if ($request['member_nric'] != $member->member_nric) {
            throw new ValidatorException(new MessageBag(['Verify that the NRIC is incorrect.']));
        }

        return ! ! $this->update(
            ['member_payment_password' => bcrypt($request->password)],
            $member->member_id
        );
    }

    /**
     * 设置冻结金额
     * @param $salary
     * @param $memberId
     *
     * @return bool
     */
    public function setFrozenSalary($salary, $memberId)
    {
        return $this->model->where('member_id', $memberId)->decrement('salary', $salary)
            && $this->model->where('member_id', $memberId)->increment('frozen_salary', $salary);
    }

    /**
     * 设置冻结金额
     * @param $salary
     * @param $memberId
     *
     * @return bool
     */
    public function decrementSalary($salary, $memberId)
    {
        return $this->model->where('member_id', $memberId)->decrement('salary', $salary);
    }

    /**
     * 找最近的三条交易记录
     * @param $memberID
     *
     * @return mixed
     */
    public function balanceIndex($memberID)
    {
        $info = $this->find($memberID);
        $data['salary'] = [
            'salary' => $info->salary,
            'frozen_salary' => $info->frozen_salary,
        ];

        $salaryTransactionRep = new SalaryTransactionRepository($this->app);

        $data['transaction'] = $salaryTransactionRep->latest($memberID,3);
        return $data;
    }

}