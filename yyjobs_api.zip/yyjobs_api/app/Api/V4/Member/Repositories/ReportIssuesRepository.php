<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/6
 * Time: 14:06
 */

namespace App\Api\V4\Member\Repositories;

use App\Api\V4\Member\Entities\ReportIssues;
use App\Api\V4\Member\Entities\SalaryTransaction;
use Carbon\Carbon;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class ReportIssuesRepository extends BaseRepository
{
    public function model()
    {
        return ReportIssues::class;
    }

    /**
     * 新增报告
     * @param $request
     *
     * @return mixed
     * @throws ValidatorException
     */
    public function report($request)
    {
        $memberID = auth('member')->user()->member_id;
        $transaction = SalaryTransaction::with('transaction')->find($request->salary_transaction_id);

        if (!$transaction || $transaction->transaction_type != 'job' || $transaction->member_id != $memberID){
            throw new ValidatorException(new MessageBag(['Report error.']));
        }

        $report = $this->findWhere(['member_id'=>$memberID,'salary_transaction_id'=>$request->salary_transaction_id ])->count();
        if ($report){
            throw new ValidatorException(new MessageBag(['You have already reported it. Please wait patiently for our reply.']));
        }

        $jobSchedulesRep = new JobSchedulesRepository($this->app);
        $data = [
            'member_id'             => $memberID,
            'salary_transaction_id' => $request->salary_transaction_id,
            'transaction_id'        => $transaction->transaction_id,
            'report_salary'         => $request->report_salary,
            'report_minutes'        => $jobSchedulesRep->getHours($transaction->transaction),
            'ticket_num'            => $this->nextTicketNum(),
            'report_time'           => Carbon::now()->format('Y-m-d H:i:s'),
            'desc'                  => $request->desc,
        ];

        return $this->create($data);
    }

    /**
     * 生成Ticket号码
     * @return string
     */
    public function nextTicketNum()
    {
        $between = [
            Carbon::now()->firstOfMonth()->format('Y-m-d H:i:s'),
            Carbon::now()->lastOfMonth()->addDay()->format('Y-m-d H:i:s'),
        ];
        
        $count = $this->model->whereBetween('report_time',$between)->count();
        $countPad = str_pad($count + 1,'4',0,STR_PAD_LEFT);
        return Carbon::now()->format('ym').$countPad;
    }
}