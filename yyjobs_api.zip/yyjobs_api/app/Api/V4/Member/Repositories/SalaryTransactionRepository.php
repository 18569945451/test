<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 15:45
 */

namespace App\Api\V4\Member\Repositories;

use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V4\Member\Entities\SalaryTransaction;
use App\Api\V4\Member\Transformers\SalaryTransaction\DetailTransformer;

class SalaryTransactionRepository extends BaseRepository
{
    public function model()
    {
        return SalaryTransaction::class;
    }

    /**
     * 获取指定雇员的最后指定条交易数据
     * @param $memberID
     * @param $number
     *
     * @return array
     */
    public function latest($memberID, $number)
    {
        $transactions = $this->model
            ->with('transaction')
            ->where('member_id', $memberID)
            ->orderBy('id', 'DESC')->limit($number)->get();

        $transformer = new DetailTransformer();

        return $transformer->listTransform($transactions);
    }

    /**
     * 交易详细
     * @param $memberID
     * @param $id
     * @return bool|array
     */
    public function detail($memberID, $id)
    {
        /** @var SalaryTransaction $transaction */
        $transaction = $this->model
            ->with('transaction')
            ->where('member_id', $memberID)
            ->find($id);

        if ( ! $transaction) {return null;}
        $data = null;

        $transformer = new DetailTransformer();
        switch ($transaction->transaction_type) {
            case 'giro':
                $data = $transformer->giroTransform($transaction);
                break;
            case 'job':
                $data = $transformer->jobTransform($transaction);
                break;
            case 'counter':
                $data = $transformer->counterTransform($transaction);
                break;
            default:break;
        }
        return $data;
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    public function transactionList($request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $result = $condition->orderBy('id','DESC')->offset($offset)->limit($pageSize)->get();

        $transformer = new DetailTransformer();
        $data['list']        = $transformer->listTransform($result);

        return $data;
    }


}