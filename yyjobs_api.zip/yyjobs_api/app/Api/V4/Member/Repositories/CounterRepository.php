<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/4
 * Time: 10:32
 */

namespace App\Api\V4\Member\Repositories;

use App\Api\V4\Member\Entities\Member;
use DB;
use App\Api\V4\Member\Entities\Counter;
use Carbon\Carbon;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class CounterRepository extends BaseRepository
{
    public function model()
    {
        return Counter::class;
    }

    /**
     * @param $request
     * @return mixed
     * @throws ValidatorException
     */
    public function apply($request)
    {
        $member = auth('member')->user();

        //验证支付密码
        $profileRep = new ProfileRepository($this->app);
        $profileRep->validPaymentPassword($request->payment_password, $member->member_id);

        //验证金额是否足够
        if ($request->salary_amount > $member->salary) {
            throw new ValidatorException(new MessageBag(["You don't have enough money to withdraw."]));
        }

        //是否有未处理的提现申请
        if ($this->hasUntreated($member->member_id)) {
            throw new ValidatorException(
                new MessageBag(
                    ["You have an unprocessed application for cash withdrawal. You can't repeat the application."]
                )
            );
        }

        $counter = [
            'member_id'     => $member->member_id,
            'queue_num'     => $this->nextQueueNum($request->counter_date),
            'counter_date'  => $request->counter_date,
            'salary_amount' => $request->salary_amount,
            'request_time'  => Carbon::now()->format('Y-m-d H:i:s'),
        ];

        return $this->create($counter);
    }

    public function scan($request)
    {
        $member = auth('member')->user();

        //验证支付密码
        $profileRep = new ProfileRepository($this->app);
        $profileRep->validPaymentPassword($request->payment_password, $member->member_id);

        //验证金额是否足够
        if ($request->amount > $member->salary) {
            throw new ValidatorException(new MessageBag(["You don't have enough money to withdraw."]));
        }

        $counter = $this->model->where('member_id', $member->member_id)->where('counter_date',Carbon::today())->whereIn('status', [1, 2])->first();
        if ($counter){
            if ($counter->status == 1){
                return $this->scanWithdrawal($counter,$request->amount);
            }else{
                throw new ValidatorException(new MessageBag(['Your withdrawal operation is in progress.']));
            }
        }else{
            $data = [
                'member_id'     => $member->member_id,
                'queue_num'     => $this->nextQueueNum($request->counter_date, 2),
                'counter_date'  => Carbon::now()->format('Y-m-d'),
                'salary_amount' => $request->amount,
                'request_time'  => Carbon::now()->format('Y-m-d H:i:s'),
                'type'          => 2,
            ];
            $unReserveCounter = $this->create($data);
            return $this->scanWithdrawal($unReserveCounter,$request->amount);
        }
    }

    public function scanWithdrawal($counter,$amount)
    {
        $data = [
            'status'        => 2,
            'salary_amount' => $amount,
        ];

        DB::beginTransaction();
        try {
            $memberRep = new ProfileRepository($this->app);
            $memberRep->decrementSalary($amount, $counter->member_id);
            $res = $this->update($data, $counter->id);
            DB::commit();

            return $res;
        } catch (\Exception $e) {
            DB::rollback();
            throw new ValidatorException(new MessageBag(["Application failure."]));
        }

    }

    /**
     * @param $date
     * @param $type
     * @return int
     * @throws ValidatorException
     */
    protected function nextQueueNum($date,$type = 1)
    {
        if (!$date){
            $date = Carbon::now()->format('Y-m-d');
        }
        $count = $this->model->where('counter_date', $date)->where('type',$type)->count();
        if ($type == 1){
            if ($count >= 100) {
                throw new ValidatorException(
                    new MessageBag(["{$date} The reservation is full. Please choose another date."])
                );
            }
            return $count + 1;
        }

        if ($type == 2){
            return $count + 101;
        }
    }

    /**
     * 是否有未处理的提现申请
     *
     * @param $memberID
     *
     * @return bool
     */
    protected function hasUntreated($memberID)
    {
        return ! ! $this->model->where('member_id', $memberID)
                               ->whereIn('status', [1, 2])
                               ->where('counter_date', '>=', Carbon::today())
                               ->count();
    }
}