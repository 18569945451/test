<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 11:53
 */

namespace App\Api\V4\Member\Presenters\SalaryTransaction;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Member\Transformers\SalaryTransaction\ListTransformer;

class ListPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new ListTransformer();
    }
}