<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 17:10
 */

namespace App\Api\V4\Member\Presenters\Giro;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Member\Transformers\Giro\IndexTransformer;

class IndexPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new IndexTransformer();
    }
}