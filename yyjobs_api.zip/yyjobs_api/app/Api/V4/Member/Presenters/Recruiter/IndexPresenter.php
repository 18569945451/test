<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 15:22
 */

namespace App\Api\V4\Member\Presenters\Recruiter;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Member\Transformers\Recruiter\IndexTransformer;

class IndexPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new IndexTransformer();
    }
}