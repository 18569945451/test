<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/26
 * Time: 16:46
 */

namespace App\Api\V4\Member\Presenters\Recruiter;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Member\Transformers\Recruiter\DetailTransformer;

class DetailPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new DetailTransformer();
    }
}