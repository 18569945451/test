<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/5/22
 * Time: 22:53
 */

namespace App\Api\V4\Member\Presenters\Job;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Member\Transformers\Job\ListTransformer;

class ListPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new ListTransformer();
    }
}