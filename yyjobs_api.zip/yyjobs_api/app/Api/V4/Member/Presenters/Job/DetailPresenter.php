<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/5
 * Time: 12:53
 */

namespace App\Api\V4\Member\Presenters\Job;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Member\Transformers\Job\DetailTransformer;

class DetailPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new DetailTransformer();
    }
}