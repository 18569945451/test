<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/12/5
 * Time: 17:26
 */

namespace App\Api\V4\Member\Presenters\Counter;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V4\Member\Transformers\Counter\IndexTransformer;

class IndexPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new IndexTransformer();
    }
}