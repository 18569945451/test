<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/5/22
 * Time: 22:55
 */

namespace App\Api\V3\Employer\Transformers\Job;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;
use App\Api\V3\Employer\Entities\Job;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V3\Employer\Entities\Job $model
     *
     * @return array
     */
    public function transform(Job $model)
    {
        $jobAlreadyNum = ($model->contrasts_count > 0) ? $model->contrasts_count : $model->schedules_count;

        return [
            'job_id'                    => (int)$model->job_id,
            'job_date'                  => Carbon::createFromTimestamp($model->job_start_date)->format('Ymd'),
            'job_start_time'            => Carbon::createFromTimestamp($model->job_start_date)->format('H:i'),
            'job_end_time'              => Carbon::createFromTimestamp($model->job_end_date)->format('H:i'),
            'job_title'                 => $model->job_title,
            'job_image'                 => $model->job_image,
            'job_need_num'              => $model->job_need_people_count,
            'job_already_num'           => $jobAlreadyNum,
        ];
    }
}