<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/12
 * Time: 15:55
 */

namespace App\Api\V3\Employer\Transformers\Job;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;
use App\Api\V3\Employer\Entities\Job;
use App\Api\V3\Employer\Entities\ScheduleContrast;
/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class DetailTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V3\Employer\Entities\Job $model
     *
     * @return array
     */
    public function transform(Job $model)
    {
        $jobAlreadyNum = ($model->contrasts_count > 0) ? $model->contrasts_count : count($model->members);
        $isSubmit      = ($model->contrasts_count > 0) ? 1 : 0;

        return [
            'job_id'          => $model->job_id,
            'job_date_time'   => Carbon::createFromTimestamp($model->job_start_date)->format('d M Y').'('
                                .Carbon::createFromTimestamp($model->job_start_date)->format('H:i').'-'
                                .Carbon::createFromTimestamp($model->job_end_date)->format('H:i').')',
            'job_is_submit'   => $isSubmit,
            'job_already_num' => $jobAlreadyNum,
            'remark'          => $this->remark($model->job_id),
            'members'         => ! $isSubmit
                                 ? $this->transformMembers($model->members)
                                 : $this->transformContrastMembers($model->contrasts),

        ];
    }

    /**
     * @param $members
     *
     * @return array
     */
    private function transformMembers($members)
    {
        if ( ! $members) {
            return [];
        }
        $data = [];
        foreach ($members as $key => $member) {
            $data[$key]['member_name']   = $member->member_name;
            $data[$key]['member_nric']   = $member->member_nric;
            $data[$key]['member_avatar'] = $member->member_avatar;
            $data[$key]['checkin_time']  = $member->checkin_time ? date('H:i',$member->checkin_time) : '';
            $data[$key]['checkout_time'] = $member->checkout_time ? date('H:i',$member->checkout_time) : '';
            $data[$key]['extra_minutes'] = 0;
            $data[$key]['explain']       = '';
        }

        return $data;
    }

    /**
     * @param $members
     *
     * @return array
     */
    private function transformContrastMembers($members)
    {
        if ( ! $members) {
            return [];
        }
        $data = [];
        foreach ($members as $key => $member) {
            $data[$key]['member_name']   = $member->name;
            $data[$key]['member_avatar'] = $member->avatar;
            $data[$key]['member_nric']   = $member->nric;
            $data[$key]['checkin_time']  = $member->checkin_time ? Carbon::parse($member->checkin_time)->format('H:i') : '';
            $data[$key]['checkout_time'] = strtotime($member->checkout_time) > 0  ? Carbon::parse($member->checkout_time)->format('H:i') : '';
            $data[$key]['extra_minutes'] = $member->extra_minutes;
            $data[$key]['explain']       = $member->explain;
        }

        return $data;
    }

    /**
     * @param $jobId
     *
     * @return mixed
     */
    private function remark($jobId)
    {
        $result = ScheduleContrast::leftJoin('job_schedule_contrast_remarks as r', 'job_schedule_contrast.remark_id', 'r.id')
            ->where('job_schedule_contrast.job_id', $jobId)
            ->first(['r.remark','r.signature']);

        return ['remark_content' => $result->remark ?? '', 'signature' => $result->signature ?? ''];
    }
}