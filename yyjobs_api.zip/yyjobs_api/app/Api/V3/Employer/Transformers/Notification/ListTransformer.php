<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/8/2
 * Time: 14:25
 */

namespace App\Api\V3\Employer\Transformers\Notification;

use League\Fractal\TransformerAbstract;
use App\Api\V3\Employer\Entities\EmployerNotifications;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V3\Employer\Entities\EmployerNotifications $model
     *
     * @return array
     */

    public function transform(EmployerNotifications $model)
    {
        //return $model->toArray();
        return [
            'id'             => $model->id,
            'type'           => $model->type,
            'employer_id'    => $model->employer_admin_id,
            'requisition_id' => $this->getRequisitionId($model->data),
            'title'          => $model->title,
            'content'        => $model->content,
            'is_read'        => $model->is_read,
            'time'           => date('H:i a. D,d/m/Y',$model->time),
        ];
    }

    public function getRequisitionId($json)
    {
        $res = json_decode($json);
        if(isset($res->requisition_id)){
            return $res->requisition_id;
        }
        return 0;
    }
}