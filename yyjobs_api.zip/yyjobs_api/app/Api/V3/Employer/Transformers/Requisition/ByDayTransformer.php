<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/5/22
 * Time: 22:55
 */

namespace App\Api\V3\Employer\Transformers\Requisition;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;
use App\Api\V3\Employer\Entities\LabourRequisition;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ByDayTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V3\Employer\Entities\LabourRequisition $model
     *
     * @return array
     */
    public function transform(LabourRequisition $model)
    {
        return [
            'id'        => (int)$model->id,
            'job_date'  => Carbon::parse($model->job_start)->format('D,d/m/Y'),
            'job_start' => Carbon::parse($model->job_start)->format('H:i'),
            'job_end'   => Carbon::parse($model->job_end)->format('H:i'),
            'job_title' => $model->job_title,
            'need_num'  => $model->need_num,
            'status'    => $model->status,
        ];
    }
}