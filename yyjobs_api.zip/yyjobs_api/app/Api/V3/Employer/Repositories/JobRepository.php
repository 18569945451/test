<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/11
 * Time: 14:18
 */

namespace App\Api\V3\Employer\Repositories;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V3\Employer\Entities\Job;


class JobRepository extends BaseRepository
{
    public function model()
    {
        return Job::class;
    }

    /**
     * @param Request $request
     *
     * @return array
     */
    public function search(Request $request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count'] = $condition->count();

        $data['countPage'] = ceil($data['count'] / $pageSize);

        $parserResult = $this->parserResult($condition->offset($offset)->limit($pageSize)->get());

        $data['list'] = $parserResult['data'];

        return $data;
    }

    /**
     *
     * @return mixed
     */
    public function detail()
    {
        return $this
            ->with(
                ['members' => function ($query) {
                return $query->whereIn('job_schedules.work_status',[2,5,6,8,11])->select(['member.member_id', 'member.member_name', 'member.member_nric','member.member_avatar','job_schedules.checkin_time','job_schedules.checkout_time']);
                },]
            )
            ->with('contrasts')
            ->withCount('contrasts')
            ->first();
    }

    /**
     * @param array  $where
     * @param string $betweenField
     * @param array  $betweenCondition
     * @param array  $columns
     *
     * @return mixed
     */
    public function findWhereBetween(array $where, string $betweenField, array $betweenCondition, array $columns = ['*'])
    {
        $this->applyCriteria();
        $this->applyScope();

        $this->applyConditions($where);
        $model = $this->model->whereBetween($betweenField, $betweenCondition)->get($columns);
        $this->resetModel();

        return $this->parserResult($model);
    }

    /**
     * @param Request $request
     */
    public function add(Request $request)
    {
        $remarkRepository = new ScheduleContrastRemarkRepository($this->app);

        $remark = $remarkRepository->insert($request);

        $jobId    = $request->job_id;
        $date     = Carbon::parse($request->date)->format('Y-m-d');
        $remarkId = $remark->id;
        $addTime  = Carbon::now()->toDateTimeString();
        $hourRate = $this->getHourlyRate($date);

        foreach ($request->members as $key => $value) {

            $data[$key]['job_id']       = $jobId;
            $data[$key]['name']         = $value['name'];
            $data[$key]['avatar']       = isset($value['avatar']) ? $value['avatar']: '';
            $data[$key]['nric']         = $value['nric'];
            $data[$key]['checkin_time'] = $date.' '.$value['checkin_time'];

            //region checkin time
            $checkInTimeArray = explode(':',$value['checkin_time']);
            if (strlen($checkInTimeArray[0]) != 2){
                $value['checkin_time'] = '0'.$value['checkin_time'];
            }
            //endregion

            //region checkout time
            if (isset($value['checkout_time']) && !empty($value['checkout_time'])){
                $checkOutTimeArray = explode(':',$value['checkout_time']);
                if (strlen($checkOutTimeArray[0]) != 2){
                    $value['checkout_time'] = '0'.$value['checkout_time'];
                }
                if ($value['checkin_time'] >= $value['checkout_time']) {
                    $data[$key]['checkout_time'] = Carbon::parse($date)
                        ->addDay()
                        ->addHours(explode(':', $value['checkout_time'])[0])
                        ->addMinutes(explode(':', $value['checkout_time'])[1])
                        ->toDateTimeString();
                } else {
                    $data[$key]['checkout_time'] = $date.' '.$value['checkout_time'];
                }
            }else{
                $data[$key]['checkout_time'] = '';
            }
            //endregion


            $data[$key]['remark_id']     = $remarkId;
            $data[$key]['add_time']      = $addTime;
            $data[$key]['hourly_rate']   = $hourRate;
            $data[$key]['rest_minutes']  = $this->restMinutes($data[$key]['checkin_time'],$data[$key]['checkout_time']);
            $data[$key]['extra_minutes'] = $value['extra_minutes'] ?? 0;
            $data[$key]['explain']       = $value['explain'] ?? '';
        }

        $contrastRepository = new ScheduleContrastRepository($this->app);
        $contrastRepository->model->insert($data);

    }

    /**
     * 根据今天周几获取employer的时薪
     *
     * @param string $date
     *
     * @return mixed
     */
    public function getHourlyRate(string $date)
    {
        $employer  = (new ProfileRepository($this->app))->profile(auth('employer')->user()->id);
        $timestamp = strtotime($date);
        $weekDay   = date('N', $timestamp);

        if ($weekDay <= 4) {
            return $employer->employer->e_hourly_rate_working
                 ? $employer->employer->e_hourly_rate_working
                 : $employer->employer->e_hourly_rate;
        }

        return $employer->employer->e_hourly_rate_weekend
             ? $employer->employer->e_hourly_rate_weekend
             : $employer->employer->e_hourly_rate;
    }


    /**
     * 根据checkin与checkout时间计算休息时间
     *
     * @param string $checkIn
     * @param string $checkOut
     *
     * @return int
     */
    public function restMinutes($checkIn = '', $checkOut = '')
    {
        if (!$checkOut){return 0;}

        $dif = (strtotime($checkOut) - strtotime($checkIn)) / 60;

        if ($dif >= 480 && $dif < 600) { /*>=8 && < 12, 扣0.5 小时*/
            return 30;
        } elseif ($dif >= 600) { /*如果>=12, 扣1个小时*/
            return 60;
        } else {
            return 0;
        }
    }

}