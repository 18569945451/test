<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/4
 * Time: 14:36
 */

namespace App\Api\V3\Employer\Repositories;

use App\Api\V1\Repositories\FileRepository;
use App\Api\V3\Employer\Entities\LabourRequisitionRemark;
use Prettus\Repository\Eloquent\BaseRepository;


class RequisitionRemarkRepository extends BaseRepository
{
    public function model()
    {
        return LabourRequisitionRemark::class;
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return mixed
     */
    public function insert($request)
    {
        $fileRepository = new FileRepository();

        $data['signature'] = $fileRepository->imageReSize(
            $request->file('signature'),
            generateFilePath()
        );
        $data['remark']    = $request->remark;

        return $this->create($data);
    }
}