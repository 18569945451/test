<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:31
 */

namespace App\Api\V3\Employer\Repositories;

use App\Api\V3\Employer\Jobs\SendOTPCodeEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\MessageBag;
use App\Api\V3\Employer\Entities\Admin;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V3\Employer\Criteria\Admin\EmployerCriteria;

class AdminRepository extends BaseRepository
{
    public function model()
    {
        return Admin::class;
    }


    /**
     * 登陆
     * @param $request
     *
     * @return array
     * @throws ValidatorException
     */
    public function login($request)
    {
        $this->pushCriteria(EmployerCriteria::class);
        $admin = $this->first(['id', 'email', 'password', 'status', 'registration_id']);
        if ( ! $admin) {
            throw new ValidatorException(
                new MessageBag(['Can\'t find this e-mail account'])
            );
        }

        if ( ! Hash::check($request->password, $admin->password)) {
            throw new ValidatorException(
                new MessageBag(['Incorrect password for account'])
            );
        }

        if (1 != $admin->status || 1 != $admin->employer->e_status) {
            throw new ValidatorException(
                new MessageBag(['Your account is forbidden to login'])
            );
        }

        $this->setRegistrationId(
            $admin->id,
            $request->registration_id,
            $admin->registration_id
        );

        $token = $this->getToken($admin);

        return ['id' => $admin->id, 'token' => $token];
    }

    /**
     * 发送邮件队列
     * @param $request
     *
     * @return bool|string
     * @throws ValidatorException
     */
    public function forgetPasswordSendMail($request)
    {
        $this->pushCriteria(EmployerCriteria::class);
        $admin = $this->first(['id', 'email', 'password', 'status', 'registration_id']);
        if ( ! $admin) {
            throw new ValidatorException(
                new MessageBag(['Can\'t find this e-mail account'])
            );
        }
        //生成验证码
        $code = substr(strtoupper(uniqid()), -6);

        //清除上一次
        cache()->forget($request->email);
        cache()->put($request->email, $code, 5);

        //发送邮件队列
        dispatch(new SendOTPCodeEmail($request->email, $code))->onQueue("api");

        return $code;
    }

    /**
     * 忘记密码：修改密码
     * @param $request
     *
     * @return mixed
     * @throws ValidatorException
     */
    public function forgetPassword($request)
    {
        $this->pushCriteria(EmployerCriteria::class);
        $admin = $this->first(['id', 'email', 'password', 'status', 'registration_id']);

        if ( ! $admin) {
            throw new ValidatorException(
                new MessageBag(['Can\'t find this e-mail account'])
            );
        }

        if (!$this->validCaptcha($request->email, $request->captcha)) {
            throw new ValidatorException(
                new MessageBag(['Incorrect verification code'])
            );
        }

        return !!$this->setPassword($admin->id, $request->password);
    }

    /**
     * 根据原密码修改密码
     * @param Request $request
     *
     * @return mixed
     * @throws ValidatorException
     */
    public function updatePassword($request)
    {
        $admin = auth('employer')->user();
        if ( ! $admin || $admin->type != 1 || $admin->status != 1) {
            throw new ValidatorException(
                new MessageBag(['Account exception'])
            );
        }

        if ( ! Hash::check($request->old_password, $admin->password)) {
            throw new ValidatorException(
                new MessageBag(['The old password is incorrect'])
            );
        }

        return ! ! $this->setPassword($admin->id, $request->password);
    }


    /**
     * 设置密码
     * @param $id
     * @param $password
     *
     * @return mixed
     */
    private function setPassword($id, $password)
    {
        $data['password'] = bcrypt($password);
        return $this->update($data, $id);
    }

    /**
     * @param $email
     * @param $captcha
     *
     * @return bool
     */
    private function validCaptcha($email, $captcha)
    {
        $cacheCode = cache()->get($email);
        if (!$cacheCode || $cacheCode != $captcha){
            return false;
        }
        cache()->forget($email);
        return true;
    }

    /**
     * 设置用户的RegistrationId
     *
     * @param        $id
     * @param string $newRegistrationId
     * @param string $curRegistrationId
     *
     * @return bool
     */
    private function setRegistrationId($id, $newRegistrationId = '', $curRegistrationId = '')
    {
        //只有id 则清空该id的RegistrationId
        if ($id && ! $newRegistrationId) {
            return $this->update(['registration_id' => ''], $id);
        }

        if ( ! $curRegistrationId) {
            $curRegistrationId = $this->find($id, ['registration_id'])->registration_id;
        }

        //新RegistrationId与旧RegistrationId对比，不同则设置新的
        if ($newRegistrationId && ($newRegistrationId != $curRegistrationId)) {
            $newRegistrationOwner = $this->skipCriteria()
                                         ->findByField('registration_id', $newRegistrationId)
                                         ->first();

            //新RegistrationId之前是否有所有者，有则清空
            if ($newRegistrationOwner) {
                $this->update(['registration_id' => ''], $newRegistrationOwner->id);
            }
            $this->update(['registration_id' => $newRegistrationId], $id);

            return true;
        }

        return true;
    }


    /**
     * 获取token
     *
     * @param Admin $admin
     *
     * @return bool
     */
    private function getToken(Admin $admin)
    {
        return auth('employer')->attempt(['id' => $admin->id]);
    }

}