<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/4
 * Time: 14:36
 */

namespace App\Api\V3\Employer\Repositories;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V3\Employer\Entities\ScheduleContrast;


class ScheduleContrastRepository extends BaseRepository
{
    public function model()
    {
        return ScheduleContrast::class;
    }

}