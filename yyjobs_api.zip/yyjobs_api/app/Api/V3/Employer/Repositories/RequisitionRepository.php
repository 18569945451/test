<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/4
 * Time: 14:36
 */

namespace App\Api\V3\Employer\Repositories;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V3\Employer\Entities\LabourRequisition;


class RequisitionRepository extends BaseRepository
{
    public function model()
    {
        return LabourRequisition::class;
    }

    /**
     * @param \Illuminate\Http\Request $request
     *
     * @return bool
     */
    public function add($request)
    {
        $remarkRepository = new RequisitionRemarkRepository($this->app);
        $remark           = $remarkRepository->insert($request);

        $employerId = auth('employer')->user()->id;
        $date       = Carbon::parse($request->date)->format('Y-m-d');
        $remarkId   = $remark->id;
        $addTime    = Carbon::now()->toDateTimeString();

        foreach ($request->requisition as $key => $value) {
            $data[$key]['employer_admin_id'] = $employerId;
            $data[$key]['job_title']         = $value['job_title'];
            $data[$key]['need_num']          = $value['need_num'];
            $data[$key]['job_start']         = $date.' '.$value['start_time'];

            $startTimeArray = explode(':',$value['start_time']);
            if (strlen($startTimeArray[0]) != 2){
                $value['start_time'] = '0'.$value['start_time'];
            }

            $endTimeArray = explode(':',$value['end_time']);
            if (strlen($endTimeArray[0]) != 2){
                $value['end_time'] = '0'.$value['end_time'];
            }
            
            if ($value['start_time'] >= $value['end_time']) {
                $data[$key]['job_end'] = Carbon::parse($date)
                    ->addDay()
                    ->addHours(explode(':', $value['end_time'])[0])
                    ->addMinutes(explode(':', $value['end_time'])[1])
                    ->toDateTimeString();
            } else {
                $data[$key]['job_end'] = $date.' '.$value['end_time'];
            }

            $data[$key]['remark_id'] = $remarkId;
            $data[$key]['add_time']  = $addTime;
        }

        return $this->model->insert($data);

    }

    /**
     * @param $employerId
     * @param $date
     *
     * @return mixed
     */
    public function getRequisition($employerId,$date)
    {
        $startDate = Carbon::parse($date)->toDateTimeString();
        $endDate   = Carbon::parse($date)->addDay()->toDateTimeString();

        return $this->findWhereBetween(
            ['employer_admin_id' => $employerId],
            'job_start',
            [$startDate, $endDate]
        );
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function setRequisition($request)
    {
        $data['job_title']         = $request->job_title;
        $data['need_num']          = $request->need_num;

        //job_start
        $startTimeArray = explode(':',$request->start_time);
        if (strlen($startTimeArray[0]) != 2){
            $request->start_time = '0'.$request->start_time;
        }
        $data['job_start'] = Carbon::parse($request->date.' '.$request->start_time)->toDateTimeString();

        $endTimeArray = explode(':',$request->end_time);
        if (strlen($endTimeArray[0]) != 2){
            $request->end_time = '0'.$request->end_time;
        }

        //比较开始时间与结束时间，如果开始时间大于等于结束时间，说明跨天了，那么结束时间+1天
        //job_end
        if ($request->start_time >= $request->end_time) {
            $data['job_end'] = Carbon::parse($request->date)
                ->addDay()
                ->addHours($endTimeArray[0])
                ->addMinutes($endTimeArray[1])
                ->toDateTimeString();
        } else {
            $data['job_end'] = Carbon::parse($request->date.' '.$request->end_time)->toDateTimeString();
        }

        $requisition    = $this->find($request->id);
        $data['status'] = in_array($requisition->status,['approve','update'])
                          ? 'update'
                          : 'pending';

        //是否有签名
        if ($request->hasFile('signature')) {
            $remarkRepository  = new RequisitionRemarkRepository($this->app);
            $remark            = $remarkRepository->insert($request);
            $data['remark_id'] = $remark->id;
        }


        //update
        return $this->update($data,$request->id);

    }

    /**
     * @param array  $where
     * @param string $betweenField
     * @param array  $betweenCondition
     * @param array  $columns
     *
     * @return mixed
     */
    public function findWhereBetween(array $where,string $betweenField,array $betweenCondition,array $columns= ['*'])
    {
        $this->applyCriteria();
        $this->applyScope();

        $this->applyConditions($where);
        $model = $this->model->whereBetween($betweenField,$betweenCondition)->get($columns);
        $this->resetModel();

        return $this->parserResult($model);
    }

}