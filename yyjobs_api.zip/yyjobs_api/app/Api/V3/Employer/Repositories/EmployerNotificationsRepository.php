<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/8/2
 * Time: 14:12
 */

namespace App\Api\V3\Employer\Repositories;

use Illuminate\Http\Request;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V3\Employer\Entities\EmployerNotifications;


class EmployerNotificationsRepository extends BaseRepository
{
    public function model()
    {
        return EmployerNotifications::class;
    }

    /**
     * @param Request $request
     *
     * @return array
     */
    public function search(Request $request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['unreadCount'] = ($this->model())::where('is_read',0)
                               ->where('employer_admin_id',auth('employer')->user()->id)
                               ->count();
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $parserResult = $this->parserResult(
            $condition->orderBy('time','DESC')->offset($offset)->limit($pageSize)->get()
        );
        $data['list']        = $parserResult['data'];

        return $data;
    }

    /**
     * @param $msgId
     *
     * @return bool
     */
    public function read($msgId)
    {
        $this->applyCriteria();
        $condition = $this->model;
        if ($msgId != 0) {
            return (int) ! ! $condition->where('id', $msgId)->update(['is_read' => 1]);
        }

        return (int) ! ! $condition->update(['is_read' => 1]);
    }
}