<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:37
 */

namespace App\Api\V3\Employer\Criteria\Job;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class DetailCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $employerId = auth('employer')->user()->id;
        $jobId      = request('job_id');

        return $model->where('job_employer_admin_id',$employerId)->where('job_id',$jobId);

    }
}