<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:37
 */

namespace App\Api\V3\Employer\Criteria\Job;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $employerId = auth('employer')->user()->id;
        $date       = request()->input('date');
        if ($date) {
            $startDate = strtotime($date);
            $endDate   = Carbon::parse($date)->addDay()->getTimestamp();

            return $model
                    ->withCount(['schedules'=>function($query){
                        return $query->whereIn('work_status',[2,5,6,8,11]);
                    },'contrasts'])
                    ->where('job_employer_admin_id', $employerId)
                    ->where('job_status',4)
                    ->whereBetween('job_start_date', [$startDate, $endDate])
                    ->orderBy('job_start_date', 'asc');
        } else {
            return $model
                    ->withCount(['schedules'=>function($query){
                        return $query->whereIn('work_status',[2,5,6,8,11]);
                    },'contrasts'])
                    ->where('job_status',4)
                    ->whereRaw("(SELECT count(*) FROM `job_schedule_contrast` WHERE `job`.`job_id` = `job_schedule_contrast`.`job_id`)<=0")
                    ->where('job_employer_admin_id', $employerId)
                    ->orderBy('job_start_date', 'asc');
        }

    }
}