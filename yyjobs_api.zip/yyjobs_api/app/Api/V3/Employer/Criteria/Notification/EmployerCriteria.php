<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/8/2
 * Time: 14:22
 */

namespace App\Api\V3\Employer\Criteria\Notification;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class EmployerCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $employerAdminId = auth('employer')->user()->id;
        return $model->where('employer_admin_id',$employerAdminId);
    }
}