<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:37
 */

namespace App\Api\V3\Employer\Criteria\Requisition;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ByDayCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $startDate = request('date');
        $endDate   = Carbon::parse($startDate)->addDay()->toDateTimeString();

        return $model->whereBetween('job_start', [$startDate, $endDate]);
    }
}