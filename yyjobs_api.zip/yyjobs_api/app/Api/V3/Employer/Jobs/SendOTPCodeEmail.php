<?php

namespace App\Api\V3\Employer\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Api\V3\Employer\Mail\SendOTPCodeEmail as OTPCodeMail;
class SendOTPCodeEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $email;
    public $code;

    /**
     * SendOTPCodeEmail constructor.
     *
     * @param $email
     * @param $code
     */
    public function __construct($email,$code)
    {
        $this->email = $email;
        $this->code = $code;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        \Mail::to($this->email)->send(new OTPCodeMail(['code'=>$this->code]));
    }
}
