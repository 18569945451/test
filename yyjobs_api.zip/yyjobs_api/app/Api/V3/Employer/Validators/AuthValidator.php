<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:49
 */

namespace App\Api\V3\Employer\Validators;

use \Prettus\Validator\Contracts\ValidatorInterface;
use \Prettus\Validator\LaravelValidator;

class AuthValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules= [
            'login' => [
                'email' => 'required|email|min:5',
                'password'=>'required|between:8,20',
            ],
            'forgetPasswordSendMail'=>[
                'email'=>'required|email|min:5'
            ],
            'forgetPassword'=>[
                'email'=>'required|email|min:5',
                'captcha'=>'required|size:6',
                'password'=>'required|between:8,20|confirmed',
            ],
            'updatePassword'=>[
                'old_password'=>'required||between:8,20',
                'password'=>'required|between:8,20|confirmed',
            ],
        ];

    protected $messages = [
        //'email.email'=>'1111111111111'
    ];

}