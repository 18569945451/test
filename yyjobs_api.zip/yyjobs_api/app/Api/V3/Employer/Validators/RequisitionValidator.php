<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:49
 */

namespace App\Api\V3\Employer\Validators;

use Illuminate\Support\MessageBag;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use \Prettus\Validator\LaravelValidator;

class RequisitionValidator extends LaravelValidator implements ValidatorInterface
{
    protected $earlierThan = 12 * 3600;
    protected $rules
        = [
            'add'            => [
                'remark'                   => 'between:0,255',
                'signature'                => 'required|image|between:0,256',
                'date'                     => 'required|date|max:10',
                'requisition'              => 'required|array',
                'requisition.*.start_time' => 'required',
                'requisition.*.end_time'   => 'required',
                'requisition.*.job_title'  => 'required|between:0,255',
                'requisition.*.need_num'   => 'required|numeric|min:1|max:65535',
            ],
            'getRequisition' => [
                'date' => 'required|date|max:10',
            ],
            'update'         => [
                'id'         => 'required|numeric|min:1',
                'remark'     => 'between:0,255',
                'signature'  => 'image|between:0,256',
                'date'       => 'required|date|max:10',
                'start_time' => 'required',
                'end_time'   => 'required',
                'job_title'  => 'required|between:0,255',
                'need_num'   => 'required|numeric|min:1|max:65535',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    /**
     * @throws ValidatorException
     */
    public function addAction()
    {
        $date        = $this->data['date'];
        $requisition = $this->data['requisition'];
        
        $now = time();
        foreach ($requisition as $key => $value) {

            //start_time
            if (count($startTimeArray = explode(':', $value['start_time'])) != 2) {
                throw new ValidatorException(
                    new MessageBag(['No.'.($key + 1).' Job start time incorrect format'])
                );
            } else {
                foreach ($startTimeArray as $item) {
                    if ( ! is_numeric($item) || strlen($item) > 2 || $item > 59 || $startTimeArray[0] > 23) {
                        throw new ValidatorException(
                            new MessageBag(['No.'.($key + 1).' Job start time incorrect format'])
                        );
                    }
                }
            }

            //end_time
            if (count($endTimeArray = explode(':', $value['end_time'])) != 2) {
                throw new ValidatorException(
                    new MessageBag(['No.'.($key + 1).' Job end time incorrect format'])
                );
            } else {
                foreach ($endTimeArray as $item) {
                    if ( ! is_numeric($item) || strlen($item) > 2 || $item > 59 || $endTimeArray[0] > 23) {
                        throw new ValidatorException(
                            new MessageBag(['No.'.($key + 1).' Job end time incorrect format'])
                        );
                    }
                }
            }


            $startTime = strtotime($date.' '.$value['start_time']);

            if ($startTime - $now < $this->earlierThan) {
                $message = 'No.'.($key + 1).' Job start time cannot be earlier than '.date(
                        'Y-m-d H:i:s',
                        $now + $this->earlierThan
                    );
                throw new ValidatorException(new MessageBag([$message]));
            }
        }

        return;

    }

    /**
     * @throws ValidatorException
     */
    public function updateAction()
    {
        $date            = $this->data['date'];
        $startTimeString = $this->data['start_time'];
        $endTimeString   = $this->data['end_time'];

        $now = time();

        if (count($startTimeArray = explode(':', $startTimeString)) != 2) {
            throw new ValidatorException(new MessageBag(['Job start time incorrect format']));
        } else {
            foreach ($startTimeArray as $item) {
                if ( ! is_numeric($item) || strlen($item) > 2 || $item > 59 || $startTimeArray[0] > 23) {
                    throw new ValidatorException(new MessageBag(['Job start time incorrect format']));
                }
            }
        }

        if (count($endTimeArray = explode(':', $endTimeString)) != 2) {
            throw new ValidatorException(new MessageBag(['Job end time incorrect format']));
        } else {
            foreach ($endTimeArray as $item) {
                if ( ! is_numeric($item) || strlen($item) > 2 || $item > 59 || $endTimeArray[0] > 23) {
                    throw new ValidatorException(new MessageBag(['Job end time incorrect format']));
                }
            }
        }

        $startTime = strtotime($date.' '.$startTimeString);
        
        if ($startTime - $now < $this->earlierThan) {
            $message = 'Job start time cannot be earlier than '.date(
                    'Y-m-d H:i:s',
                    $now + $this->earlierThan
                );
            throw new ValidatorException(
                new MessageBag([$message])
            );
        }

        /*$requisitions = DB::table('labour_requisitions')->find($this->data['id']);

        if (!$requisitions){
            throw new ValidatorException(
                new MessageBag(['The selected id is invalid.'])
            );
        }

        if ($requisitions->status == 'approve'){
            throw new ValidatorException(
                new MessageBag(['This request has been approved by the administrator and cannot be modified.'])
            );
        }

        if ($requisitions->status == 'reject'){
            throw new ValidatorException(
                new MessageBag(['This request has been rejected by the administrator and cannot be modified.'])
            );
        }*/

        return;
    }

}