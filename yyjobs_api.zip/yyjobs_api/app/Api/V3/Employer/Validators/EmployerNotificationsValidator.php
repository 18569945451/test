<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/8/2
 * Time: 14:15
 */

namespace App\Api\V3\Employer\Validators;

use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;

class EmployerNotificationsValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'lists' => [
                'cur_page'  => 'numeric|min:1',
                'page_size' => 'numeric|min:1',
            ],
            'read'  => [
                'msg_id' => 'required|numeric',
            ],
        ];
}