<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:49
 */

namespace App\Api\V3\Employer\Validators;

use Illuminate\Support\MessageBag;
use \Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;
use \Prettus\Validator\LaravelValidator;

class JobValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'lists'  => [
                'date'      => 'date|max:10',
                'cur_page'  => 'numeric|min:1',
                'page_size' => 'numeric|min:1',
            ],
            'detail' => [
                'job_id' => 'required|numeric|min:1',
            ],
            'add'    => [
                'job_id'                  => 'required|numeric|min:1',
                'remark'                  => 'between:0,255',
                'signature'               => 'required|image|between:0,256',
                'date'                    => 'required|date|max:10',
                'members'                 => 'required|array',
                'members.*.name'          => 'required|between:0,255',
                'members.*.avatar'        => 'between:0,255|url',
                'members.*.nric'          => 'required|between:0,20',
                'members.*.checkin_time'  => 'required',
                //'members.*.checkout_time' => 'required',
                'members.*.extra_minutes' => 'numeric',
                'members.*.explain'       => 'between:0,512',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    public function addAction()
    {
        $members = $this->data['members'];

        foreach ($members as $key => $value) {

            //checkin_time
            if (count($startTimeArray = explode(':', $value['checkin_time'])) != 2) {
                throw new ValidatorException(
                    new MessageBag(['No.'.($key + 1).' Checkin time incorrect format'])
                );
            } else {
                foreach ($startTimeArray as $item) {
                    if ( ! is_numeric($item) || strlen($item) > 2 || $item > 59 || $startTimeArray[0] > 23) {
                        throw new ValidatorException(
                            new MessageBag(['No.'.($key + 1).' Checkin time incorrect format'])
                        );
                    }
                }
            }

            //checkout_time
            if (isset($value['checkout_time']) && !empty($value['checkout_time'])){
                if (count($endTimeArray = explode(':', $value['checkout_time'])) != 2) {
                    throw new ValidatorException(
                        new MessageBag(['No.'.($key + 1).' Checkout time incorrect format'])
                    );
                } else {
                    foreach ($endTimeArray as $item) {
                        if ( ! is_numeric($item) || strlen($item) > 2 || $item > 59 || $endTimeArray[0] > 23) {
                            throw new ValidatorException(
                                new MessageBag(['No.'.($key + 1).' Checkout time incorrect format'])
                            );
                        }
                    }
                }
            }

        }

        $job = \DB::table('job_schedule_contrast')->where('job_id',request('job_id'))->first(['id']);
        if ($job){
            throw new ValidatorException(
                new MessageBag(['Can\'t submit duplicates'])
            );
        }

        return;

    }
}