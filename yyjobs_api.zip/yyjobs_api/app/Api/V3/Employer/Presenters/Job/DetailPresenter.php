<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/5/22
 * Time: 22:53
 */

namespace App\Api\V3\Employer\Presenters\Job;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V3\Employer\Transformers\Job\DetailTransformer;

class DetailPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new DetailTransformer();
    }
}