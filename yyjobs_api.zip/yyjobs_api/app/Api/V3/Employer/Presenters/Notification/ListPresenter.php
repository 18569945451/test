<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/8/2
 * Time: 15:23
 */

namespace App\Api\V3\Employer\Presenters\Notification;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V3\Employer\Transformers\Notification\ListTransformer;

class ListPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new ListTransformer();
    }
}