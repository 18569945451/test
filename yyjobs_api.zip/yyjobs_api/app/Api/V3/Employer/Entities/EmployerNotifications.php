<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/8/2
 * Time: 14:11
 */

namespace App\Api\V3\Employer\Entities;


use Illuminate\Database\Eloquent\Model;

class EmployerNotifications extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'employer_notifications';
    public $timestamps = false;

}