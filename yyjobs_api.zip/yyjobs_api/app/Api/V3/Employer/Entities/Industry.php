<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/8/14
 * Time: 14:28
 */
namespace App\Api\V3\Employer\Entities;

use Illuminate\Database\Eloquent\Model;

class Industry extends Model
{
    /**
     * 表名
     * @var string
     */
    protected $table = 'industry';


    /**
     * 主键
     * @var string
     */
    protected $primaryKey = 'industry_id';

    public $timestamps = false;

}
