<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/4
 * Time: 18:00
 */

namespace App\Api\V3\Employer\Entities;


use Illuminate\Database\Eloquent\Model;

class ScheduleContrastRemark extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'job_schedule_contrast_remarks';

    /**
     * @var array
     */
    protected $fillable = ['remark', 'signature',];

    public $timestamps = false;

    public function scheduleContrast()
    {
        return $this->hasMany(ScheduleContrast::class,'remark_id','id');
    }
}