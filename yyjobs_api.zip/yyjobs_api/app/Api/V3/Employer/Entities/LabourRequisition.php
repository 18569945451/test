<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/4
 * Time: 18:00
 */

namespace App\Api\V3\Employer\Entities;


use Illuminate\Database\Eloquent\Model;

class LabourRequisition extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'labour_requisitions';


    /**
     * @var array
     */
    protected $fillable
        = [
            'employer_admin_id',
            'job_title',
            'need_num',
            'job_start',
            'job_end',
            'job_id',
            'remark_id',
            'status',
            'created_at',
        ];


    public $timestamps = false;

    public function requisitionRemark()
    {
        return $this->belongsTo(LabourRequisitionRemark::class, 'id', 'remark_id');
    }
}