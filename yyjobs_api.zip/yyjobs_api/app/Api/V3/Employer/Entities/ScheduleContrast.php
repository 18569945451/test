<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/11
 * Time: 14:11
 */

namespace App\Api\V3\Employer\Entities;


use Illuminate\Database\Eloquent\Model;

class ScheduleContrast extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'job_schedule_contrast';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable
        = [
            'job_id',
            'name',
            'avatar',
            'nric',
            'checkin_time',
            'checkout_time',
            'rest_minutes',
            'extra_minutes',
            'explain',
            'remark_id',
            'add_time',
        ];

    public $timestamps = false;

    public function job()
    {
        return $this->belongsTo(Job::class,'job_id','job_id');
    }

    public function scheduleContrastRemark()
    {
        return $this->belongsTo(ScheduleContrastRemark::class,'id','remark_id');
    }


}