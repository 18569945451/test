<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/4
 * Time: 14:39
 */

namespace App\Api\V3\Employer\Controllers;

use App\Http\Controllers\Controller;
use App\Api\V3\Employer\Presenters\ProfilePresenter;
use App\Api\V3\Employer\Repositories\ProfileRepository;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    protected $repository;

    public function __construct(ProfileRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/profile/info",
     *   tags={"employer/profile"},
     *   summary="个人信息",
     *   description="个人信息",
     *   operationId="profile/info",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function info()
    {
        try {
            $id = auth('employer')->user()->id;

            $this->repository->setPresenter(ProfilePresenter::class);
            $response = $this->repository->profile($id);

            return apiReturn($response['data']);

        } catch (ModelNotFoundException $e) {
            return apiReturn([], 404, 'Not Find');
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/profile/registration",
     *   tags={"employer/profile"},
     *   summary="设置设备id",
     *   description="设置设备id",
     *   operationId="profile/registration",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",name="registration_id",type="string",  description="设备id", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function registration(Request $request)
    {
        try {
            $id           = auth('employer')->user()->id;
            $registration = $request->input('registration_id', '');

            return apiReturn(
                $this->repository->registration($id, $registration)
            );

        } catch (ModelNotFoundException $e) {
            return apiReturn([], 404, 'Not Find');
        }
    }

}