<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/8/2
 * Time: 9:51
 */

namespace App\Api\V3\Employer\Controllers;

use App\Api\V3\Employer\Criteria\Notification\EmployerCriteria;
use App\Api\V3\Employer\Presenters\Notification\ListPresenter;
use App\Api\V3\Employer\Repositories\EmployerNotificationsRepository;
use App\Api\V3\Employer\Validators\EmployerNotificationsValidator;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Prettus\Validator\Exceptions\ValidatorException;

class NotificationController extends Controller
{
    protected $repository;
    protected $validator;
    public function __construct(EmployerNotificationsRepository $repository,EmployerNotificationsValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/notification/list",
     *   tags={"employer/notification"},
     *   summary="通知列表",
     *   description="通知列表",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="integer",  description="当前页(默认1)", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="integer",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function lists(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('lists');

            $this->repository->pushCriteria(EmployerCriteria::class);
            $this->repository->setPresenter(ListPresenter::class);

            return apiReturn($this->repository->search($request));
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/notification/read",
     *   tags={"employer/notification"},
     *   summary="消息设置为已读",
     *   description="消息设置为已读",
     *   operationId="read",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="msg_id",type="integer",  description="0:全部已读", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function read(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('read');
            $this->repository->pushCriteria(EmployerCriteria::class);

            return apiReturn($this->repository->read($request->msg_id));
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}