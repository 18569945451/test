<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:29
 */

namespace App\Api\V3\Employer\Controllers;

use App\Api\V3\Employer\Repositories\AdminRepository;
use App\Api\V3\Employer\Validators\AuthValidator;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    protected $repository;

    protected $validator;

    public function __construct(AdminRepository $repository, AuthValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/auth/login",
     *   tags={"employer/auth"},
     *   summary="登录",
     *   description="登录",
     *   operationId="login",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="formData",  name="registration_id",type="string",  description="设备id", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function login(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('login');
            $data = $this->repository->login($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/auth/password/forget/email",
     *   tags={"employer/auth"},
     *   summary="忘记密码:发送验证码邮件",
     *   description="忘记密码:发送验证码邮件",
     *   operationId="password/forget/email",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function forgetPasswordSendMail(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('forgetPasswordSendMail');
            $data = $this->repository->forgetPasswordSendMail($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/auth/password/forget",
     *   tags={"employer/auth"},
     *   summary="忘记密码:修改密码",
     *   description="忘记密码:修改密码",
     *   operationId="password/forget",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=true),
     *   @SWG\Parameter(in="formData",  name="captcha",type="string",  description="验证码", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="新密码", required=true),
     *   @SWG\Parameter(in="formData",  name="password_confirmation",type="string",  description="确认新密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function forgetPassword(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('forgetPassword');
            $data = $this->repository->forgetPassword($request);

            return apiReturn($data,null ,'Password reset complete');
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/auth/password/update",
     *   tags={"employer/auth"},
     *   summary="根据原密码修改密码",
     *   description="根据原密码修改密码",
     *   operationId="password/update",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",name="old_password",type="string",  description="原密码", required=true),
     *   @SWG\Parameter(in="formData",name="password",type="string",  description="新密码", required=true),
     *   @SWG\Parameter(in="formData",name="password_confirmation",type="string",  description="确认新密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function updatePassword(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('updatePassword');
            return apiReturn(
                $this->repository->updatePassword($request)
            );

        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}