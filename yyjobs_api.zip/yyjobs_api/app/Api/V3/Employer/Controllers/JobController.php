<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/11
 * Time: 14:11
 */

namespace App\Api\V3\Employer\Controllers;

use App\Api\V3\Employer\Criteria\Job\DetailCriteria;
use App\Api\V3\Employer\Criteria\Job\ListCriteria;
use App\Api\V3\Employer\Presenters\Job\DetailPresenter;
use App\Api\V3\Employer\Presenters\Job\ListPresenter;
use App\Http\Controllers\Controller;
use App\Api\V3\Employer\Repositories\JobRepository;
use App\Api\V3\Employer\Validators\JobValidator;
use Illuminate\Http\Request;
use Prettus\Validator\Exceptions\ValidatorException;

class JobController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(JobRepository $repository, JobValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/jobs/list",
     *   tags={"employer/jobs"},
     *   summary="我的工作列表",
     *   description="我的工作列表",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="date",type="string",  description="日期（2018-06-11）", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="integer",  description="当前页(默认1)", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="integer",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function lists(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('lists');

            $this->repository->pushCriteria(ListCriteria::class);
            $this->repository->setPresenter(ListPresenter::class);

            return apiReturn($this->repository->search($request));
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Get(path="/index.php/api/employer/jobs/detail",
     *   tags={"employer/jobs"},
     *   summary="我的工作详情",
     *   description="我的工作详情",
     *   operationId="detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="job_id",type="string",  description="工作id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('detail');

            $this->repository->pushCriteria(DetailCriteria::class);
            $this->repository->setPresenter(DetailPresenter::class);
            $result = $this->repository->detail();

            return apiReturn($result['data']);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employer/jobs/add",
     *   tags={"employer/jobs"},
     *   summary="提交工作确认",
     *   description="提交工作确认",
     *   operationId="add",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="job_id",type="string",  description="工作id", required=true),
     *   @SWG\Parameter(in="formData",  name="remark",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="formData",  name="signature",type="file",  description="签名", required=true),
     *   @SWG\Parameter(in="formData",  name="date",type="string",  description="日期(2018-06-12)", required=true),
     *   @SWG\Parameter(in="formData",  name="members[0][name]",type="string",  description="用户名", required=true),
     *   @SWG\Parameter(in="formData",  name="members[0][avatar]",type="string",  description="头像", required=false),
     *   @SWG\Parameter(in="formData",  name="members[0][nric]",type="string",  description="身份证号", required=true),
     *   @SWG\Parameter(in="formData",  name="members[0][checkin_time]",type="string",  description="CheckIn时间(09:00)", required=true),
     *   @SWG\Parameter(in="formData",  name="members[0][checkout_time]",type="string",  description="CheckOut时间(19:00)", required=false),
     *   @SWG\Parameter(in="formData",  name="members[0][extra_minutes]",type="number",  description="额外时间分钟（正数增加 负数扣减）", required=false),
     *   @SWG\Parameter(in="formData",  name="members[0][explain]",type="string",  description="说明", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function add(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('add');
            $this->validator->addAction();

            $result = $this->repository->add($request);

            return apiReturn($result['data']);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}