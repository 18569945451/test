<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/6
 * Time: 14:29
 */

namespace App\Api\V3\Member\Transformers\Employer;

use League\Fractal\TransformerAbstract;
use App\Api\V3\Member\Entities\Employer;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V3\Member\Entities\Employer $model
     *
     * @return array
     */
    public function transform(Employer $model)
    {
        return [
            'e_admin_id'      => $model->e_admin_id,
            'e_company_name'  => $model->e_company_name,
            'e_company_logo'  => $model->e_company_logo,
            'e_industry_name' => isset($model->industry->industry_name)
                                 ? $model->industry->industry_name
                                 : '',
        ];
    }
}