<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 15:45
 */

namespace App\Api\V3\Member\Transformers\Member;

use App\Api\V3\Member\Entities\Industry;
use App\Api\V3\Member\Entities\Member;
use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class InfoTransformer extends TransformerAbstract
{

    public function transform(Member $model)
    {
        $info = [];
        if ($memberInfo = $model->info()->first()) {
            $info = [
                'info_id'                     => $memberInfo->info_id,
                'info_religion'               => $memberInfo->info_religion,
                'info_address'                => $memberInfo->info_address,
                'info_school_expiry_date'     => $memberInfo->info_school_expiry_date,
                'info_emergency_name'         => $memberInfo->info_emergency_name,
                'info_emergency_phone'        => $memberInfo->info_emergency_phone,
                'info_emergency_relationship' => $memberInfo->info_emergency_relationship,
                'info_emergency_address'      => $memberInfo->info_emergency_address,
                'info_contact_method'         => $memberInfo->info_contact_method,
                'info_criminal_record'        => $memberInfo->info_criminal_record,
                'info_medication'             => $memberInfo->info_medication,
                'info_bank_statement'         => $memberInfo->info_bank_statement,
                'info_bank_statement_img'     => $memberInfo->info_bank_statement_img,
                'info_language'               => $memberInfo->info_language,
                'info_is_uploaded'            => $memberInfo->info_is_uploaded,
                'info_signature'              => $memberInfo->info_signature,
                'info_nationality'            => $memberInfo->info_nationality,
                'info_nric_zheng'             => $memberInfo->info_nric_zheng,
                'info_nric_fan'               => $memberInfo->info_nric_fan,
                'info_industry'               => Industry::whereIn('industry_id',explode(',',$memberInfo->info_industry))->get(['industry_id','industry_name']),
                'employement_status'          => $memberInfo->employement_status,
            ];
        }

        $model->availability->all();

        $earned = $model->schedules()->whereIn('work_status', [6, 8])->sum('job_salary');
        $deduction = $model->schedules()->whereIn('work_status', [6, 8])->sum('deduction');
        $relEarned = $earned-$deduction;
        $statistics = [
            'earned'        => sprintf("%.2f",$relEarned),
            'completeTotal' => $model->schedules()->whereIn('work_status', [5, 6, 7, 8])->count(),
            'pending'       => $model->schedules()->whereIn('work_status', [1, 2])->count(),
        ];


        return array_merge($model->toArray(),$info,$statistics);
    }

}