<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/5/22
 * Time: 22:55
 */

namespace App\Api\V3\Member\Transformers\Job;

use League\Fractal\TransformerAbstract;
use App\Api\V3\Member\Entities\Job;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V3\Member\Entities\Job $model
     *
     * @return Job
     */
    public function transform(Job $model)
    {
        return $model;
    }
}