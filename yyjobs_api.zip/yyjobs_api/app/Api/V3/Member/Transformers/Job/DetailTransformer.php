<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/5
 * Time: 12:53
 */

namespace App\Api\V3\Member\Transformers\Job;

use App\Api\V3\Member\Entities\RecipientGroupsMember;
use App\Api\V3\Member\Entities\Job;
use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class DetailTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V3\Member\Entities\Job $model
     *
     * @return array
     */
    public function transform(Job $model)
    {
        $modelArray = $model->toArray();
        $job = [
            'job'=>[
                'job_id'                => $model->job_id,
                'job_title'             => $model->job_title,
                'description'           => [
                    'job_image'         => $model->job_image,
                    'job_type'          => $model->job_employer_company_name,
                    'job_location'      => $model->job_address,
                    'job_date'          => date('d/M/Y', $model->job_start_date).'('.date('H:ia', $model->job_start_date).' - '.date('H:ia', $model->job_end_date).')',
                    'job_start'         => $model->job_start_date,
                    'job_end'           => $model->job_end_date,
                    'description'       => $model->job_description,
                    'job_industry_name' => $model->job_industry_name,
                    'hourly_rate'       => $model->job_hour_rate,
                ],
                'job_role'              => $model->job_post,
                'required'              => [
                    'age'               => $model->job_people_age ? $model->job_people_age : 'Any',
                    'language'          => str_replace(' ', ',', ucwords(str_replace(',', ' ', $model->job_people_language))),
                    'gender'            => $model->job_people_sex == 0 ? 'Both' : ($model->job_people_sex == 1 ? 'Male' : 'Female'),
                    'nationality'       => $model->job_people_nationality,
                ],
                'remarks'               => $model->job_note,
                'requirements'          => $model->job_requirements,
                'display_apply_button'  => $this->isApply($modelArray),
                'recruiter_identifier'  => $this->recruiterIdentifier($model),
                'employer_id'           => $model->job_employer_admin_id,
                'employer_under_hy'     => $model->employer_admin->under_hy,
            ],
        ];

        if (!isset($modelArray['schedules']) || empty($modelArray['schedules'])){
            return $job;
        }

        return array_merge($job, ['schedules' => array_first($modelArray['schedules'])]);
    }

    /**
     * @param $model
     *
     * @return bool
     */
    private function isApply($model)
    {
        $member = auth('member')->user();
        if ($model['recipient_id'] === null || $model['recipient_id'] == 0 || ! isset($model['schedules'])) {
            return 1;
        } else {
            //$schedules = array_first($model['schedules']);
            $recMember = RecipientGroupsMember::where('member_id', $member->member_id)->where(
                'recipient_group_id',
                $model['recipient_id']
            )->first();

            return $recMember ? 1 : 0;
        }
    }

    /**
     * @param $model
     *
     * @return string
     */
    private function recruiterIdentifier($model)
    {
        if ($model->job_recruiter_admin_id){
            return 'r'.$model->job_recruiter_admin_id;
        }
        $recruiter = \DB::table('admins')->whereRaw('FIND_IN_SET(?, has_employer)',[$model->job_employer_admin_id])->first(['id']);
        if (!$recruiter){
            return '';
        }
        return 'r'.$recruiter->id;
    }
}