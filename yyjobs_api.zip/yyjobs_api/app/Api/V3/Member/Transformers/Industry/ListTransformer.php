<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/9
 * Time: 14:29
 */

namespace App\Api\V3\Member\Transformers\Industry;

use League\Fractal\TransformerAbstract;
use App\Api\V3\Member\Entities\Industry;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V3\Member\Entities\Industry $model
     *
     * @return array
     */
    public function transform(Industry $model)
    {
        return [
            'industry_id'        => $model->industry_id,
            'industry_name'      => $model->industry_name,
            'industry_image'     => $model->industry_image ? $model->industry_image : '',
            'industry_image_new' => $model->industry_image_new ? $model->industry_image_new : '',
            'jobs_count'         => 0,
        ];
    }
}