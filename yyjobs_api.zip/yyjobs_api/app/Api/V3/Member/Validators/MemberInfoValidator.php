<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 11:19
 */

namespace App\Api\V3\Member\Validators;

use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\LaravelValidator;

class MemberInfoValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'saveIndustry' => [
                'industry'   => 'array|max:5',
                'industry.*' => 'numeric|distinct',
            ],
        ];
}