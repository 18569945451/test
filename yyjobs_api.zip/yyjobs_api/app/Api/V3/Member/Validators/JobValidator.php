<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/1
 * Time: 10:49
 */

namespace App\Api\V3\Member\Validators;

use Illuminate\Http\Request;
use \Prettus\Validator\Contracts\ValidatorInterface;
use \Prettus\Validator\LaravelValidator;

class JobValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'lists'  => [
                'cur_page'  => 'numeric|min:1',
                'page_size' => 'numeric|min:1',
                'start_time' => 'numeric|min:1',
            ],
            'detail' => [
                'job_id' => 'required|numeric',
            ],
        ];

    protected $messages
        = [
            //'email.email'=>'1111111111111'
        ];

    /**
     * @param Request $request
     * @return array
     */
    public function listQueryParameter(Request $request)
    {
        $query = [
            'cur_page'   => $request->input('cur_page', 1),
            'page_size'  => $request->input('page_size', 15),
            'start_time' => $request->input('start_time', time() - 3600 * 2),
        ];

        $industryId = $request->input('industry_id',[]);
        $query['industry_id'] = !is_array($industryId)
                                ? explode(',',$industryId)
                                : $request->industry_id;

        $employerId = $request->input('employer_id',[]);
        $query['employer_id'] = !is_array($employerId)
                                ? explode(',',$employerId)
                                : $request->employer_id;

        return $query;

    }
}