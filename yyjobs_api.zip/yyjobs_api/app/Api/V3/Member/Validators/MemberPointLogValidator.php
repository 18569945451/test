<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/20
 * Time: 14:11
 */

namespace App\Api\V3\Member\Validators;

use Illuminate\Http\Request;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\LaravelValidator;

class MemberPointLogValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'history' => [
                'by'               => 'in:month,day',
                'cur_page'         => 'numeric',
                'page_size'        => 'numeric',
                'start_timestamps' => 'numeric',
                'end_timestamps'   => 'numeric',
                'keyword'          => 'between:0,32',
            ],
        ];

    /**
     * @param Request $request
     *
     * @return array
     */
    public function listQueryParameter(Request $request)
    {

        $query = [
            'by'               => $request->input('by', 'month'),
            'cur_page'         => $request->input('cur_page', 1),
            'page_size'        => $request->input('page_size', 15),
            'start_timestamps' => $request->input('start_timestamps', 0),
            'end_timestamps'   => $request->input('end_timestamps', 1893427200),
            'keyword'          => $request->input('keyword', ''),
            'member_id'        => auth('member')->user()->member_id,
        ];


        return $query;

    }
}