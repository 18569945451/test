<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 15:41
 */

namespace App\Api\V3\Member\Criteria\Member;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class InfoCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $member = $repository->getQueryParameter();
        return $model->where('member_id',$member->member_id);
    }
}