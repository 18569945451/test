<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/6
 * Time: 14:22
 */

namespace App\Api\V3\Member\Criteria\Industry;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        return $model;
    }
}