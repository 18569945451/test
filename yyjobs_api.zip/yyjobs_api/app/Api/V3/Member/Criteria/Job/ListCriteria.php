<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/1
 * Time: 10:37
 */

namespace App\Api\V3\Member\Criteria\Job;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $queryParameter = $repository->getQueryParameter();
        $curPage        = $queryParameter['cur_page'];
        $offset         = ($queryParameter['cur_page'] - 1) * $queryParameter['page_size'];
        $pageSize       = $queryParameter['page_size'];

        $subSql = $model->leftJoin('job_schedules as js',function ($join){
            $join->on('job.job_id','js.job_id')->whereRaw(\DB::raw('js.work_status in (2, 5, 6, 8, 11)'));
        })
        ->leftJoin('employer as e','job.job_employer_admin_id','e.e_admin_id')
        ->when($queryParameter['start_time'],function ($query)use($queryParameter){
            return $query->where('job.job_start_date','>',$queryParameter['start_time']);
        })
        ->when(true,function ($query){
            return $query->where('job.job_status',4);
        })
        ->when($queryParameter['industry_id'],function ($query)use($queryParameter){
            return $query->whereIn('job.job_industry_id',$queryParameter['industry_id']);
        })
        ->when($queryParameter['employer_id'],function ($query)use($queryParameter){
            return $query->whereIn('job.job_employer_admin_id',$queryParameter['employer_id']);
        })
        ->groupBy('job.job_id')
        ->selectRaw('job.job_id, job.job_employer_company_name, job.job_title, e.e_company_logo as employer_logo,job.job_image, job.job_start_date, job.job_end_date, job.job_hour_rate, job.job_industry_id, job.job_industry_name, job.job_address, job.job_need_people_count, COUNT(js.s_id) as apply_count');

        $count = \DB::table(\DB::raw("({$subSql->toSql()}) as tb_main"))
                ->mergeBindings($subSql->getQuery())
                ->whereRaw('job_need_people_count > apply_count')
                ->orderBy('job_start_date','asc')
                ->count();

        $result = \DB::table(\DB::raw("({$subSql->toSql()}) as tb_main"))
                ->mergeBindings($subSql->getQuery())
                ->whereRaw('job_need_people_count > apply_count')
                ->orderBy('job_start_date','asc')
                ->offset($offset)
                ->limit($pageSize)
                ->get();

        $countPage = ceil($count / $pageSize);

        return compact('countPage','count','curPage','pageSize','result');



    }
}