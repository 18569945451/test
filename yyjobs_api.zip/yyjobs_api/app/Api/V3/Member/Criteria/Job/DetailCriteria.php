<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/5
 * Time: 14:27
 */

namespace App\Api\V3\Member\Criteria\Job;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class DetailCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $queryParameter = $repository->getQueryParameter();
        if ($queryParameter['member']){
            return $model->with(['schedules'=>function($query)use($queryParameter){
                return $query->where('member_id',$queryParameter['member']->member_id);
            }])->where('job_id',$queryParameter['job_id']);
        }

        return $model->where('job_id',$queryParameter['job_id']);
    }
}