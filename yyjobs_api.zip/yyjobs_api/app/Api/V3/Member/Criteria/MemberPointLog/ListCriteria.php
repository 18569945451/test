<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/20
 * Time: 14:02
 */

namespace App\Api\V3\Member\Criteria\MemberPointLog;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    /**
     * @param                     $model
     * @param RepositoryInterface $repository
     *
     * @return array
     */
    public function apply($model, RepositoryInterface $repository)
    {
        $queryParameter = $repository->getQueryParameter();
        $curPage        = $queryParameter['cur_page'];
        $offset         = ($curPage - 1) * $queryParameter['page_size'];
        $pageSize       = $queryParameter['page_size'];

        $count = $model->leftJoin('job as j','member_point_log.job_id','j.job_id')->leftJoin('merchant as mt','member_point_log.merchant_id','mt.merchant_id')->leftJoin('member as m','member_point_log.invitee_id','m.member_id')->where('member_point_log.member_id',$queryParameter['member_id'])->where('member_point_log.log_time','>',$queryParameter['start_timestamps'])->where('member_point_log.log_time','<',$queryParameter['end_timestamps'])->when($queryParameter['keyword'],function($query)use($queryParameter){return $query->where(function ($subQuery)use($queryParameter){return $subQuery->where('j.job_title','like',"%{$queryParameter['keyword']}%")->orWhere('mt.merchant_name','like',"%{$queryParameter['keyword']}%");});})->orderBy('member_point_log.log','DESC')->count();

        $resultData = $model->leftJoin('job as j','member_point_log.job_id','j.job_id')->leftJoin('merchant as mt','member_point_log.merchant_id','mt.merchant_id')->leftJoin('member as m','member_point_log.invitee_id','m.member_id')->where('member_point_log.member_id',$queryParameter['member_id'])->where('member_point_log.log_time','>',$queryParameter['start_timestamps'])->where('member_point_log.log_time','<',$queryParameter['end_timestamps'])->when($queryParameter['keyword'],function($query)use($queryParameter){return $query->where(function ($subQuery)use($queryParameter){return $subQuery->where('j.job_title','like',"%{$queryParameter['keyword']}%")->orWhere('mt.merchant_name','like',"%{$queryParameter['keyword']}%");});})->orderBy('member_point_log.id','DESC')->offset($offset)->limit($pageSize)->get(['member_point_log.id as log_id','member_point_log.change_type','member_point_log.change_value','member_point_log.log_time','j.job_title','j.job_image','mt.merchant_name','mt.merchant_logo','m.member_name as invitee_name','m.member_avatar as invitee_avatar']);

        $countPage = ceil($count / $pageSize);

        $bill = [];
        $result = [];
        if (count($resultData) > 0){
            $parseResult = $this->parseResult($model,$queryParameter,$resultData);
            $bill = $parseResult['bill'];
            $result = $parseResult['result'];
        }

        return compact('countPage','count','curPage','pageSize','bill','result');
    }

    /**
     * @param $model
     * @param $queryParameter
     * @param $resultData
     *
     * @return array
     */
    public function parseResult($model, $queryParameter,$resultData)
    {
        
        $bill = [];
        $result = [];
        $resultArray = $resultData->toArray();
        foreach ($resultData as $key=>$item) {
            if (!$queryParameter['keyword']){
                //统计时间区间的收支
                if ($queryParameter['by'] == 'month'){
                    $logKey       = date('Y-m', $item->log_time);
                    $startMonthTime = strtotime($logKey);
                    $endMonthTime   = strtotime(date('Y-m', strtotime('+1 month', strtotime($logKey))));
                }else{
                    $logKey       = date('Y-m-d', $queryParameter['start_timestamps']).' - '.date('Y-m-d', $queryParameter['end_timestamps']);
                    $startMonthTime = $queryParameter['start_timestamps'];
                    $endMonthTime   = $queryParameter['end_timestamps'];
                }
                //区间统计结果是否存在
                if (!isset($bill[$logKey]) || !in_array($logKey,array_keys($bill))){
                    $bill[$logKey]['earn']  = $this->getBill($model,$queryParameter,[$startMonthTime,$endMonthTime],[1,3]);
                    $bill[$logKey]['pay']  = $this->getBill($model,$queryParameter,[$startMonthTime,$endMonthTime],[2]);
                }
            }else{
                if (!isset($bill['search'])){
                    $bill['search']['earn'] = $this->getBill($model,$queryParameter,[],[1,3]);
                    $bill['search']['pay'] = $this->getBill($model,$queryParameter,[],[2]);
                }

            }
            
            //Null 转 ''
            foreach ($resultArray as $rKey =>$rValue) {
                foreach ($rValue as $valueKey=>$item) {
                    $result[$rKey][$valueKey] = $item != null ? $item : '';
                }

                $result[$rKey]['log_time_format'] = date('Y-m',$rValue['log_time']);
            }
        }
        
        return compact('bill','result');
    }

    /**
     * @param       $model
     * @param array $queryParameter
     * @param array $times
     * @param array $status
     *
     * @return mixed
     */
    private function getBill($model,array $queryParameter,$times = [],array $status)
    {
        if (!$queryParameter['keyword']){
            return $model->where('member_id',$queryParameter['member_id'])->whereBetween('log_time',$times)->whereIn('change_type',$status)->sum('change_value');
        }

        return $model->leftJoin('job as j','member_point_log.job_id','j.job_id')->leftJoin('merchant as mt','member_point_log.merchant_id','mt.merchant_id')->leftJoin('member as m','member_point_log.invitee_id','m.member_id')->when($queryParameter['keyword'],function($query)use($queryParameter){return $query->where(function ($subQuery)use($queryParameter){return $subQuery->where('j.job_title','like',"%{$queryParameter['keyword']}%")->orWhere('mt.merchant_name','like',"%{$queryParameter['keyword']}%");});})->where('member_point_log.member_id',$queryParameter['member_id'])->whereIn('member_point_log.change_type',$status)->sum('member_point_log.change_value');

    }

}