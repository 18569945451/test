<?php

namespace App\Api\V3\Member\Controllers;

use App\Api\V3\Member\Validators\MemberPointLogValidator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V3\Member\Criteria\MemberPointLog\ListCriteria;
use App\Api\V3\Member\Repositories\MemberPointLogRepository;


class PointController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(MemberPointLogRepository $repository, MemberPointLogValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }
    /**
     * @SWG\Get(path="/index.php/api/employee/point/history",
     *   tags={"employee/point"},
     *   summary="积分记录",
     *   description="积分记录",
     *   operationId="point/history",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="by",type="string",  description="month,day", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="query",  name="start_timestamps",type="string",  description="开始时间戳", required=false),
     *   @SWG\Parameter(in="query",  name="end_timestamps",type="string",  description="结束时间戳", required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="搜索关键字", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function history(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('history');
            
            $parameter = $this->validator->listQueryParameter($request);
            $this->repository->setQueryParameter($parameter);
            
            $this->repository->pushCriteria(ListCriteria::class);

            return apiReturn($this->repository->search());
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}
