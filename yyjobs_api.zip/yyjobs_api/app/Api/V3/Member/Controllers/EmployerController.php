<?php

namespace App\Api\V3\Member\Controllers;

use App\Api\V3\Member\Criteria\Employer\ListCriteria;
use App\Api\V3\Member\Presenters\Employer\ListPresenter;
use App\Api\V3\Member\Repositories\EmployerRepository;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class EmployerController extends Controller
{
    protected $repository;
    public function __construct(EmployerRepository $repository)
    {
        $this->repository = $repository;
    }
    /**
     * @SWG\Get(path="/index.php/api/employee/employer/list",
     *   tags={"employee/employer"},
     *   summary="雇主列表",
     *   description="雇主列表",
     *   operationId="employer/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function lists()
    {
        try {
            $this->repository->pushCriteria(ListCriteria::class);
            $this->repository->setPresenter(ListPresenter::class);
            return apiReturn($this->repository->search());
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}
