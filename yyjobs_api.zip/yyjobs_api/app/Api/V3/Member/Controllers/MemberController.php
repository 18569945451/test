<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 15:18
 */

namespace App\Api\V3\Member\Controllers;

use App\Api\V3\Member\Criteria\Member\InfoCriteria;
use App\Api\V3\Member\Presenters\Member\InfoPresenter;
use App\Api\V3\Member\Repositories\MemberRepository;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class MemberController extends Controller
{
    protected $repository;

    public function __construct(MemberRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/info",
     *   tags={"info"},
     *   summary="用户个人信息详情",
     *   description="用户个人信息详情",
     *   operationId="",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function info()
    {
        try {
            $member = auth('member')->user();
            $this->repository->setQueryParameter($member);

            $this->repository->pushCriteria(InfoCriteria::class);
            $this->repository->setPresenter(InfoPresenter::class);

            return apiReturn($this->repository->first()['data']);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

}