<?php

namespace App\Api\V3\Member\Controllers;

use App\Http\Controllers\Controller;

class EnableGuestController extends Controller
{
    public $member = null;

    public function __construct()
    {
        if(request()->header('authorization')){
            $this->member = auth()->guard('member')->user();
        }
    }
}
