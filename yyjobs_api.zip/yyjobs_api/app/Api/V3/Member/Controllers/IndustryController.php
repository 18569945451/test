<?php

namespace App\Api\V3\Member\Controllers;

use App\Api\V3\Member\Criteria\Industry\ListCriteria;
use App\Api\V3\Member\Presenters\Industry\ListPresenter;
use App\Api\V3\Member\Repositories\IndustryRepository;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;

class IndustryController extends Controller
{
    protected $repository;
    public function __construct(IndustryRepository $repository)
    {
        $this->repository = $repository;
    }
    /**
     * @SWG\Get(path="/index.php/api/employee/extra/industry/list",
     *   tags={"extra/industry"},
     *   summary="行业列表",
     *   description="行业列表",
     *   operationId="industry/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    /**
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function lists()
    {
        try {
            $this->repository->pushCriteria(ListCriteria::class);
            $this->repository->setPresenter(ListPresenter::class);
            return apiReturn($this->repository->search());
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}
