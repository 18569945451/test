<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 11:16
 */

namespace App\Api\V3\Member\Controllers;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V3\Member\Validators\MemberInfoValidator;
use App\Api\V3\Member\Repositories\MemberInfoRepository;

class MemberInfoController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(MemberInfoRepository $repository, MemberInfoValidator $validator)
    {
        $this->repository = $repository;
        $this->validator  = $validator;
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/info/industry",
     *   tags={"employee/info"},
     *   summary="保存用户喜欢的行业",
     *   description="保存用户喜欢的行业",
     *   operationId="industry",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="industry[1]",type="integer",  description="行业id", required=false),
     *   @SWG\Parameter(in="formData",  name="industry[2]",type="integer",  description="行业id", required=false),
     *   @SWG\Parameter(in="formData",  name="industry[3]",type="integer",  description="行业id", required=false),
     *   @SWG\Parameter(in="formData",  name="industry[4]",type="integer",  description="行业id", required=false),
     *   @SWG\Parameter(in="formData",  name="industry[5]",type="integer",  description="行业id", required=false),
     *   @SWG\Parameter(in="formData",  name="industry[6]",type="integer",  description="行业id", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v3+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function saveIndustry(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('saveIndustry');
            $memberId = auth('member')->user()->member_id;
            $data = $this->repository->saveIndustry($request,$memberId);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}