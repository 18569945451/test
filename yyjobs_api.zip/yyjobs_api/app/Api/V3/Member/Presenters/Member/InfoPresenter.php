<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 15:43
 */

namespace App\Api\V3\Member\Presenters\Member;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V3\Member\Transformers\Member\InfoTransformer;

class InfoPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new InfoTransformer();
    }
}