<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/20
 * Time: 14:00
 */

namespace App\Api\V3\Member\Repositories;

use App\Api\V3\Member\Entities\MemberPointLog;
use Prettus\Repository\Eloquent\BaseRepository;

class MemberPointLogRepository extends BaseRepository
{
    private $queryParameter;

    public function model()
    {
        return MemberPointLog::class;
    }

    /**
     * @param array $data
     */
    public function setQueryParameter($data = [])
    {
        $this->queryParameter = $data;
    }

    /**
     * @param string $key
     *
     * @return mixed
     */
    public function getQueryParameter($key = '')
    {
        if ($key) {
            return $this->queryParameter[$key];
        }

        return $this->queryParameter;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Model
     */
    public function search()
    {
        $this->applyCriteria();
        return $this->model;
    }

}