<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 15:19
 */

namespace App\Api\V3\Member\Repositories;

use App\Api\V3\Member\Entities\Member;
use Prettus\Repository\Eloquent\BaseRepository;

class MemberRepository extends BaseRepository
{
    private $queryParameter;

    public function model()
    {
        return Member::class;
    }

    /**
     * @param array $data
     */
    public function setQueryParameter($data = [])
    {
        $this->queryParameter = $data;
    }

    /**
     * @param string $key
     *
     * @return mixed
     */
    public function getQueryParameter($key = '')
    {
        if ($key) {
            return $this->queryParameter[$key];
        }

        return $this->queryParameter;
    }

    public function getMemberInfo()
    {
        //$this->applyCriteria();
        return $this->first();
    }

}