<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 11:22
 */

namespace App\Api\V3\Member\Repositories;

use App\Api\V3\Member\Entities\MemberInfo;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Validator\Exceptions\ValidatorException;

class MemberInfoRepository extends BaseRepository
{
    public function model()
    {
        return MemberInfo::class;
    }

    /**
     * @param Request $request
     * @param         $memberId
     *
     * @return mixed
     */
    public function saveIndustry(Request $request, $memberId)
    {
        $attributes['info_industry'] = implode(
            ',',
            $request->input('industry', [])
        );

        return $this->save($attributes, $memberId);
    }

    /**
     * @param array $attributes
     * @param       $memberId
     *
     * @return mixed
     * @throws ValidatorException
     */
    public function save(array $attributes, $memberId)
    {
        if ( ! $this->model->where('member_id', $memberId)->first(['info_id'])) {
            throw new ValidatorException(
                new MessageBag(['Please improve your personal information first.'])
            );
        }

        return $this->model->where('member_id', $memberId)->update($attributes);
    }
}