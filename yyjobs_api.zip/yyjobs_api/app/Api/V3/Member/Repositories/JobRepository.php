<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/03
 * Time: 16:10
 */

namespace App\Api\V3\Member\Repositories;

use App\Api\V3\Member\Entities\Job;
use Prettus\Repository\Eloquent\BaseRepository;


class JobRepository extends BaseRepository
{
    private $queryParameter;

    public function model()
    {
        return Job::class;
    }

    /**
     * @param array $data
     */
    public function setQueryParameter($data = [])
    {
        $this->queryParameter = $data;
    }

    /**
     * @param string $key
     *
     * @return mixed
     */
    public function getQueryParameter($key = '')
    {
        if ($key) {
            return $this->queryParameter[$key];
        }

        return $this->queryParameter;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Model
     */
    public function search()
    {
        $this->applyCriteria();
        return $this->model;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Model
     */
    public function detail()
    {
        $this->applyCriteria();
        return $this->parserResult($this->model->first());
    }

}