<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/09
 * Time: 15:28
 */

namespace App\Api\V3\Member\Repositories;

use App\Api\V3\Member\Entities\Industry;
use Prettus\Repository\Eloquent\BaseRepository;


class IndustryRepository extends BaseRepository
{

    public function model()
    {
        return Industry::class;
    }

    /**
     * @return array
     */
    public function search()
    {
        $this->applyCriteria();

        $data = $this->parserResult($this->model->get())['data'];

        return $this->handleOtherLast($data);
    }

    /**
     * @param $data
     *
     * @return array
     */
    private function handleOtherLast($data)
    {
        $other = [];
        foreach ($data as $key=>$value) {
            if ($value['industry_name'] == 'Others'){
                $other[] = $data[$key];
                unset($data[$key]);
            }
        }
        return array_merge($data,$other);
    }

}