<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/06
 * Time: 14:17
 */

namespace App\Api\V3\Member\Repositories;

use App\Api\V3\Member\Entities\Employer;
use Prettus\Repository\Eloquent\BaseRepository;


class EmployerRepository extends BaseRepository
{

    public function model()
    {
        return Employer::class;
    }

    /**
     * @return array
     */
    public function search()
    {
        $this->applyCriteria();

        $data = $this->parserResult($this->model->get(['e_admin_id','e_company_name','e_company_logo','e_industry_id']))['data'];

        return $this->handleSort($data,'e_company_name');
    }

    /**
     * @param array  $data
     * @param string $column
     *
     * @return array
     */
    public function handleSort(array $data,$column = '')
    {
        if (!$column){
            return $data;
        }
        $keys = array_column($data, $column);

        array_multisort($keys, SORT_ASC, $data);

        return $data;
    }

}