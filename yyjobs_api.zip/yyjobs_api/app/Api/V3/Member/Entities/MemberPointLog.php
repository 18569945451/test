<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/20
 * Time: 13:56
 */

namespace App\Api\V3\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class MemberPointLog extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'member_point_log';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';
    public $timestamps = false;

}