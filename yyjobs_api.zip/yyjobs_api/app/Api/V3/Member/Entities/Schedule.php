<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/03
 * Time: 16:09
 */

namespace App\Api\V3\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'job_schedules';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 's_id';

    /**
     * @var array
     */
    protected $fillable
        = [
            'member_id',
            'member_name',
            'job_id',
            'is_assigned',
            'cancel_status',
            'cancel_reason',
            'cancel_image',
            'cancel_time',
            'checkin_time',
            'checkin_address',
            'checkout_time',
            'checkout_address',
            'work_hours',
            'adjusted_hourly_rate',
            'job_salary',
            'job_rating',
            'reviews',
            'process_date',
            'payment_methods',
            'add_time',
            'member_current_lat',
            'member_current_long',
            'work_status',
        ];


    public $timestamps = false;

    public function job()
    {
        return $this->belongsTo(Job::class,'job_id','job_id');
    }

}