<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 11:24
 */

namespace App\Api\V3\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class MemberInfo extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'member_info';


    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'info_id';

    public $timestamps = false;


    public function member()
    {
        return $this->hasOne(Member::class, 'member_id', 'member_id');
    }


}