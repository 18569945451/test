<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/10
 * Time: 17:14
 */

namespace App\Api\V3\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class Availability extends Model
{
    /**
     * 表名
     * @var string
     */
    protected $table = 'availabilities';

    /**
     * 主键
     * @var string
     */
    protected $primaryKey = 'id';

    public $timestamps = false;
}