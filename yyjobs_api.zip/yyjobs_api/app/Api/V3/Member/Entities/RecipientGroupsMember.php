<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/5
 * Time: 12:56
 */

namespace App\Api\V3\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class RecipientGroupsMember extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    protected $table = 'recipient_groups_member';

    /**
     * 主键
     *
     * @var string
     */
    protected $primaryKey = 'id';

}