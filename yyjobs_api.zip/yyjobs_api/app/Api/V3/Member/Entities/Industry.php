<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/7/03
 * Time: 16:09
 */
namespace App\Api\V3\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class Industry extends Model
{
    /**
     * 表名
     * @var string
     */
    protected $table = 'industry';


    /**
     * 主键
     * @var string
     */
    protected $primaryKey = 'industry_id';

    public $timestamps = false;

    public function employers()
    {
        return $this->hasMany(Employer::class,'industry_id','e_industry_id');
    }

    public function jobs()
    {
        return $this->hasMany(Job::class,'job_industry_id','industry_id');
    }
}
