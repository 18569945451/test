<?php

namespace App\Api\V6\Member\Jobs;

use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use App\Api\V6\Member\Entities\Member;
use App\Api\V6\Member\Entities\Rewards;
use App\Api\V6\Member\Entities\RewardsExchange;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Api\V6\Member\Repositories\Rewards\MemberRewardPointRepository;
use App\Api\V6\Member\Entities\RewardsPointRecord as RewardsPointRecordModel;
use Illuminate\Support\Facades\Redis;

class RewardsPointRecord/* implements ShouldQueue*/
{
    private $model;
    private $repository;
    protected $data;
    protected $type;

    private $continuous;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * RewardsPointRecord constructor.
     *
     * @param $data
     * @param $type
     */
    public function __construct($data, $type)
    {
        $this->data = $data;
        $this->type = $type;
        $this->model = new RewardsPointRecordModel();
        $this->repository = new MemberRewardPointRepository();
        $this->continuous = config('rewardspoint.continuous');
    }

    /**
     * @return mixed|null
     */
    public function handle()
    {
        switch ($this->type) {
            case "Promotion_Apply":
                return $this->promotionApply();
                break;
            case "NewsFeed_Post":
                return $this->newsFeedPost();
                break;
            case "Daily_Check_In":
                return $this->dailyCheckIn();
                break;
            case "Item_Redemption":
                return $this->convertRewards();
                break;
            default:
                return null;
        }
    }

    /**
     * 优惠券申请
     * @return mixed
     */
    private function promotionApply()
    {
        $isObtain = $this->model->mine($this->data['member_id'])->dayForType('Promotion_Apply')->count();
        if ($isObtain){
            return null;
        }
        return $this->createData($this->data['member_id'], $this->data['member_name'], 2, $this->data['promotions_id'], 'Promotion_Apply', 'Promotion Apply');
    }

    /**
     * 发布news feed
     * @return mixed
     */
    private function newsFeedPost()
    {
        $isObtain = $this->model->mine($this->data['member_id'])->dayForType('NewsFeed_Post')->count();
        if ($isObtain){
            return null;
        }
        return $this->createData($this->data['member_id'], $this->data['member_name'], 2, $this->data['newsFeed_id'], 'NewsFeed_Post', 'NewsFeed Post');
    }

    /**
     * 每日签到
     */
    private function dailyCheckIn()
    {
        //昨天是否签到过
        $yesterdayCheckin = $this->model->mine($this->data->member_id)->yesterdayForType('Daily_Check_In')->count();

        //今天是否签到过
        $todayCheckin = $this->model->mine($this->data->member_id)->dayForType('Daily_Check_In')->count();

        //昨天签到了今天没签 + 1 days
        if ($yesterdayCheckin && !$todayCheckin){
            // +2分
            $this->createData($this->data->member_id, $this->data->member_name, 2, 0, 'Daily_Check_In', 'Daily Check In');

            //连续签到奖励
            $remainder = ($this->data->continuous_days + 1) % 30;
            $continuousDays = $remainder == 0 ? 30 : $remainder;
            if (in_array($continuousDays,array_keys($this->continuous))){
                $extraRewardPoint = $this->continuous[$continuousDays];
                $this->createData($this->data->member_id, $this->data->member_name, $extraRewardPoint, 0, 'Extra_Reward', "Continuous {$continuousDays} Days Login +$extraRewardPoint");
            }

            Member::where('member_id',$this->data->member_id)->increment('continuous_days',1);
        }

        //昨天没签 今天也没签 = 1 days
        if (!$yesterdayCheckin && !$todayCheckin){
            // +2分
            $this->createData($this->data->member_id, $this->data->member_name, 2, 0, 'Daily_Check_In', 'Daily Check In');

            Member::where('member_id',$this->data->member_id)->update(['continuous_days'=>1]);
        }
        return true;
    }

    /**
     * @param $memberID
     * @param $memberName
     * @param $point
     * @param $recordableId
     * @param $recordableType
     * @param $explain
     */
    private function createData($memberID,$memberName,$point,$recordableId,$recordableType,$explain)
    {
        $data  = [
            'member_id'       => $memberID,
            'member_name'     => $memberName,
            'point'           => $point,
            'recordable_id'   => $recordableId,
            'recordable_type' => $recordableType,
            'explain'         => $explain,
        ];
        $record = $this->model->create($data);
        Member::where('member_id',$memberID)->increment('reward_point',$point);


        //更新Redis可用积分
        $this->repository->redisMemberRewardPointAvailable($memberID,$point);

        //更新Redis历史所有积分
        $this->repository->redisMemberRewardPointTotal($memberID,$point);

        //更新Redis等级
        $this->repository->redisMemberRewardPointLevel($memberID);

        return $record;
    }


    /**
     *  积分兑换商品
     */
    public function convertRewards()
    {
        $this->InsertConvertData($this->data['member_info'], $this->data['rewards_id'], $this->data['pointsData']);
        return null;

    }



    public function InsertConvertData($memberInfo, $rewardsId, $pointsData)
    {
        \DB::transaction(function () use($memberInfo, $rewardsId, $pointsData){
            $rewardsCode = $this->createCode();
            $this->createData($memberInfo->member_id, $memberInfo->member_name,'-'.$pointsData->points,$rewardsId,'Item_Redemption',$pointsData->title);

            RewardsExchange::insert(array(
                'member_id'     => $memberInfo->member_id,
                'member_name'   => $memberInfo->member_name,
                'rewards_id'    => $rewardsId,
                'rewards_title' => $pointsData->title,
                'rewards_point' => $pointsData->points,
                'code'          => $rewardsCode,
                'created_at'    => Carbon::now(),
                'updated_at'    => Carbon::now()
            ));

            (new Rewards())->where('id',$rewardsId)->increment('convert_num',1);
        });
    }


    public function createCode()
    {
        $arr = ['0','1','2','3','4','5','6','7','8','9', 'a', 'b','c','d','e','f', 'g', 'h','i', 'j', 'k', 'l', 'm', 'n', 'o'
            ,'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A' ,'B', 'C','D','E','F','G','H','I','J','K','L','M','N','O','P'
            ,'Q','R','S','T','U','V','W','X','Y','Z'];

        $code  = implode('',array_random($arr, 4));
        return $code;
    }

}
