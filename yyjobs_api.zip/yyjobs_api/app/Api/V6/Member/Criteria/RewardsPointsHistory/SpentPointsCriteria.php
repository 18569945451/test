<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 14:23
 */
namespace App\Api\V6\Member\Criteria\RewardsPointsHistory;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class SpentPointsCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        return $model->whereNULL('deleted_at')->where('point', '<', 0)->select(
            'id','member_name','point','recordable_type','explain','remark','created_at'
        );
    }
}