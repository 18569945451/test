<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/6/19
 * Time: 14:11
 */

namespace App\Api\V6\Member\Criteria\RewardPoint;

use Carbon\Carbon;
use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class IndexCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $memberID  = auth('member')->user()->member_id;
        $status = request('status');

        return $model->mine($memberID)->when($status,function($query)use($status){
            if ($status == 1){
                return $query->where('point','>',0);
            }else{
                return $query->where('point','<',0);
            }
        });
        /*$memberID  = auth('member')->user()->member_id;
        $keyword   = request()->input('keyword');
        $startDate = request()->input('start_date');
        $endDate   = request()->input('end_date');

        return $model->with('transaction')
            ->when($keyword,function ($query)use($keyword){
                return $query->where(function($subQuery)use($keyword){
                    return $subQuery->where('transaction_name','like',"%{$keyword}%")
                        ->orWhere('search_value1','like',"%{$keyword}%")
                        ->orWhere('search_value2','like',"%{$keyword}%")
                        ->orWhere('search_value3','like',"%{$keyword}%")
                        ->orWhere('transaction_type','like',"%{$keyword}%");
                });

            })
            ->when($startDate && $endDate,function ($query)use ($startDate,$endDate){
                $between = [
                    Carbon::parse($startDate),
                    Carbon::parse($endDate)->addDay()
                ];
                return $query->whereBetween('transaction_time',$between);
            })
            ->where('member_id',$memberID);*/
    }
}