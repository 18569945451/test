<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 14:23
 */
namespace App\Api\V6\Member\Criteria\Rewards;

use Prettus\Repository\Contracts\CriteriaInterface;
use Prettus\Repository\Contracts\RepositoryInterface;

class ListCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        return $model->whereNULL('deleted_at')->select(
            'id','cate_id','title','points','stock_num','image','stock_num', 'convert_num'
        )->with(['category']);
    }
}