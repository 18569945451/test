<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 16:47
 */

namespace App\Api\V6\Member\Transformers\RewardPoint;

use App\Api\V6\Member\Entities\RewardsPointRecord;
use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class IndexTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V6\Member\Entities\RewardsPointRecord $model
     *
     * @return array
     */
    public function transform(RewardsPointRecord $model)
    {
        return [
            'id'         => $model->id,
            'member_id'  => $model->member_id,
            'explain'    => $model->explain == 'Salary' ? 'Payment' : $model->explain,
            'point'      => $model->point,
            'created_at' => $model->created_at->format('d M Y,H:i a'),
        ];
    }
}