<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 16:47
 */
namespace App\Api\V6\Member\Transformers\TemporaryEmployer;

use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ApplicationProgressTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\Promotions $v
     *
     * @return array
     */
    public function transform($arr)
    {
        $data = [];
        if($arr->isEmpty()){
            return [];
        }
        foreach($arr as $v){
            $data[] = array(
                    'id'             => $v->id,
                    'date'           => date('M d, Y',strtotime($v->job_start)),
                    'start_end'      => date('H:i',strtotime($v->job_start)) . '-'.date('H:i',strtotime($v->job_end)),
                    'job_start'      => strtotime($v->job_start),
                    'job_end'        => strtotime($v->job_end),
                    'need_num'       => $v->need_num,
                    'job_title'      => $v->job_title,
                    'status'         => ucfirst($v->status),
                    'reject_reason'  => $v->reject_reason ? $v->reject_reason :''
            );
        }
        return $data;
    }
}