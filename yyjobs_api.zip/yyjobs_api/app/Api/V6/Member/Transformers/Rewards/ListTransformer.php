<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 16:47
 */
namespace App\Api\V6\Member\Transformers\Rewards;

use League\Fractal\TransformerAbstract;

/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class ListTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\Promotions $model
     *
     * @return array
     */
    public function transform($model)
    {
        return [
            'id'             => $model->id,
            'cate_id'        => $model->cate_id,
            'title'          => $model->title,
            'image'          => $model->image,
            'points'         => $model->points,
            'stock_num'      => $model->stock_num,
            'convert_num'    => $model->convert_num,
            'icon'           => $model->category ? $model->category->icon :''
        ];
    }
}