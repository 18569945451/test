<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 16:47
 */
namespace App\Api\V6\Member\Transformers\RewardsPointsHistory;

use League\Fractal\TransformerAbstract;
use Carbon\Carbon;
/**
 * Class RoleTransformer.
 *
 * @package namespace App\Transformers;
 */
class SpentPointsTransformer extends TransformerAbstract
{
    /**
     * Transform the Role entity.
     *
     * @param \App\Api\V5\Member\Entities\Promotions $model
     *
     * @return array
     */
    public function transform($model)
    {
        return [
            'id'                => $model->id,
            'member_name'       => $model->member_name,
            'point'             => $model->point,
            'recordable_type'   => $model->recordable_type,
            'explain'           => $model->explain,
            'remark'            => $model->remark,
            'created_at'        => Carbon::parse($model->created_at)->format('d M Y, H:i a'),
            'time'              => strtotime($model->created_at)
        ];
    }
}