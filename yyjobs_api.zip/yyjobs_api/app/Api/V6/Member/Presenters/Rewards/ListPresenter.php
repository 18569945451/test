<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/1
 * Time: 16:44
 */

namespace App\Api\V6\Member\Presenters\Rewards;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V6\Member\Transformers\Rewards\ListTransformer;

class ListPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new ListTransformer();
    }
}