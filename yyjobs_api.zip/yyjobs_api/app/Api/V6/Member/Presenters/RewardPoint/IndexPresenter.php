<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/5/22
 * Time: 22:53
 */

namespace App\Api\V6\Member\Presenters\RewardPoint;

use Prettus\Repository\Presenter\FractalPresenter;
use App\Api\V6\Member\Transformers\RewardPoint\IndexTransformer;

class IndexPresenter extends FractalPresenter
{
    /**
     * Transformer
     *
     * @return \League\Fractal\TransformerAbstract
     */
    public function getTransformer()
    {
        return new IndexTransformer();
    }
}