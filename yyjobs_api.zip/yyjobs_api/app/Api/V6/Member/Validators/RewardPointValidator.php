<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/6/19
 * Time: 14:03
 */

namespace App\Api\V6\Member\Validators;

use Prettus\Validator\LaravelValidator;
use Prettus\Validator\Contracts\ValidatorInterface;

class RewardPointValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules
        = [
            'index' => [
                'status'    => 'nullable|in:-1,0,1',
                'cur_page'  => 'nullable|integer',
                'page_size' => 'nullable|integer',
            ],
            'hasCheck' => [
                'day'    => 'nullable|date',
            ],
        ];
}