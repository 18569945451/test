<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/6/4
 * Time: 18:17
 */

namespace App\Api\V6\Member\Validators;

use \Prettus\Validator\LaravelValidator;
use Illuminate\Validation\Rule;
use \Prettus\Validator\Contracts\ValidatorInterface;
class ReleaseWorkValidator extends LaravelValidator implements ValidatorInterface
{
    protected $rules = [
        'releaseWork'=>[
            'remark'                => 'nullable|max:255',
            'signature'             => 'required',
            'date'                  => 'required|date',
            'start_time'            => ['required'],
            'end_time'              => 'required',
            'job_title'             => 'required|max:255',
            'need_num'              => ['required','numeric','regex:/[1-9]\d*(\.\d*[1-9])?/'],
            'from'                  => 'nullable|in:h5,app'
        ]
    ];
}