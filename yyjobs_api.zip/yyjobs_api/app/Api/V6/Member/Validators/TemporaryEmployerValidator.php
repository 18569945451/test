<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/6/4
 * Time: 13:55
 */

namespace App\Api\V6\Member\Validators;

use \Prettus\Validator\LaravelValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;
class TemporaryEmployerValidator extends LaravelValidator implements ValidatorInterface
{

    protected $rules = [
        'registration'=>[
            'apply_name'            => 'required',
            'apply_business_name'   => 'required',
            'apply_email'           => 'nullable|email|max:255',
            'apply_contact_no'      => ['required', 'max:20', 'regex:/^[+][0-9]*$/'],
            'request_job_date'      => 'required|date',
            'request_job_title'     => 'required|max:255',
            'staff_required'        => ['required','numeric','regex:/[1-9]\d*(\.\d*[1-9])?/'],
            'from'                  => 'nullable|in:h5,app'
        ]
    ];
}