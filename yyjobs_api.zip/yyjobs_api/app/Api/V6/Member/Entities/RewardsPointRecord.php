<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/6/17
 * Time: 16:36
 */

namespace App\Api\V6\Member\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RewardsPointRecord extends Model
{
    use SoftDeletes;
    //表名
    protected $table = 'rewards_point_record';

    //主键
    protected $primaryKey = 'id';

    //fillable
    protected $fillable = [
            'member_id',
            'member_name',
            'point',
            'recordable_id',
            'recordable_type',
            'explain',
            'remark',
            'created_at',
            'updated_at',
            'deleted_at',
        ];

    public function scopeMine($query, $memberID)
    {
        return $query->where('member_id',$memberID);
    }

    public function scopeToday($query)
    {
        $between = [Carbon::today(),Carbon::tomorrow()];
        return $query->whereBetween('created_at',$between);
    }

    public function scopeYesterdayForType($query,$type)
    {
        $between = [Carbon::yesterday(),Carbon::today()];
        return $query->where('recordable_type',$type)->whereBetween('created_at',$between);
    }

    public function scopeDayForType($query,$type,$day = null)
    {
        if ($day){
            $between = [Carbon::parse($day),Carbon::parse($day)->addDay()];
        }else{
            //today
            $between = [Carbon::today(),Carbon::tomorrow()];
        }
        return $query->where('recordable_type',$type)->whereBetween('created_at',$between);
    }

    public function getMemberPoints($memberId)
    {
        return $this->where('member_id', $memberId)->whereNULL('deleted_at')->sum('point');
    }
}