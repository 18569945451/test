<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2018/6/4
 * Time: 18:00
 */

namespace App\Api\V6\Member\Entities;


use Illuminate\Database\Eloquent\Model;

class LabourRequisitionRemark extends Model
{
    /**
     * 表名
     *
     * @var string
     */
    //protected $table = 'labour_requisition_remarks';


    /**
     * @var array
     */
    protected $fillable = ['remark', 'signature',];


    public $timestamps = false;

    public function requisition()
    {
        return $this->hasMany(LabourRequisition::class, 'remark_id', 'id');
    }


}