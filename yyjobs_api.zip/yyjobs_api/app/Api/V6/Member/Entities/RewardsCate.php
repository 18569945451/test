<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/2/25
 * Time: 14:46
 */
namespace App\Api\V6\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class RewardsCate extends Model
{
    protected $table = 'rewards_cate';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = ['id', 'title', 'icon', 'sort', 'created_at', 'updated_at'];
}