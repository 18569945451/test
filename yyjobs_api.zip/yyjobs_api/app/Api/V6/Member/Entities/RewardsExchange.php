<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/3/4
 * Time: 13:52
 */
namespace App\Api\V6\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class RewardsExchange extends Model
{
    protected $table = 'rewards_exchange';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = ['id', 'member_id', 'member_name', 'rewards_id',
                            'rewards_title', 'rewards_point', 'code', 'status', 'created_at', 'updated_at', 'deleted_at'];


    public function member_has_convert($member_id, $id)
    {
        return $this->where('member_id', $member_id)->where('rewards_id', $id)->count();
    }


    public function getUnCompletedCode()
    {
        return $this->where('status', 'UnCompleted')->pluck('code')->toArray();
    }

}