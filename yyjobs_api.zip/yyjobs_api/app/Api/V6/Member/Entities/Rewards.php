<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/2/25
 * Time: 12:40
 */
namespace App\Api\V6\Member\Entities;

use Illuminate\Database\Eloquent\Model;

class Rewards extends Model
{
    protected $table = 'rewards';
    protected $primaryKey = 'id';
    public    $timestamps = false;
    protected $fillable  = ['id', 'title', 'points', 'stock_num','start_time', 'end_time', 'cate_id', 'image', 'convert_num', 'terms_condition'
                            , 'address', 'contact_no', 'sort', 'created_at', 'updated_at', 'deleted_at'];

    public function category()
    {
        return $this->hasOne(RewardsCate::class, 'id', 'cate_id');
    }

}