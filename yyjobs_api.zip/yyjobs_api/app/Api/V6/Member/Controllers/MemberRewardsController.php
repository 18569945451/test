<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/6/17
 * Time: 18:45
 */

namespace App\Api\V6\Member\Controllers;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Api\V6\Member\Repositories\RewardsExchangeRepository;
use Illuminate\Validation\Rule;
use Prettus\Validator\Exceptions\ValidatorException;
class MemberRewardsController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(RewardsExchangeRepository $repository)
    {
        $this->repository           = $repository;
    }


    /**
     * @SWG\Post(path="/index.php/api/employee/memberRewards/convert_rewards",
     *   tags={"memberRewards/convert_rewards"},
     *   summary="积分商城之用户积分兑换商品",
     *   description="积分商城之用户积分兑换商品",
     *   operationId="memberRewards_convert_rewards",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="id",type="integer",  description="rewards兑换", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function convert_rewards(Request $request)
    {
        $code = 200;
        try {
            $data = array();
            $this->validate($request,
                [
                    'id' => 'required',
                ]
            );
            $this->repository->convertRewards($code);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], $code, $e->getMessageBag()->first());
        }
    }



    /**
     * @SWG\Post(path="/index.php/api/employee/memberRewards/receive_rewards",
     *   tags={"memberRewards/receive_rewards"},
     *   summary="积分商城用户领取rewards",
     *   description="积分商城用户领取的rewards",
     *   operationId="memberRewards_receive_rewards",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="id",type="integer",  description="rewards Id", required=true),
     *   @SWG\Parameter(in="query",  name="code",type="string",  description="4位rewards兑换码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function receive_rewards(Request $request)
    {
        try {
            $data = array();
            $this->repository->receive_rewards();
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }




    /**
     * @SWG\Get(path="/index.php/api/employee/memberRewards/my_rewards",
     *   tags={"memberRewards/my_rewards"},
     *   summary="积分商城用户兑换的rewards",
     *   description="积分商城用户兑换的rewards",
     *   operationId="memberRewards_my_rewards",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function my_rewards(Request $request)
    {
        try {
            $data = $this->repository->myRewards();
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }


}