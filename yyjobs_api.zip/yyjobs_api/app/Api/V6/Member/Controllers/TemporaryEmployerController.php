<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/6/3
 * Time: 16:30
 */

namespace App\Api\V6\Member\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V6\Member\Repositories\TemporaryEmployerRepository;
use App\Api\V6\Member\Validators\TemporaryEmployerValidator;
use App\Api\V6\Member\Validators\ReleaseWorkValidator;
use Illuminate\Support\MessageBag;
class TemporaryEmployerController extends Controller
{
    protected $repository;
    protected $validator;
    protected $releaseWorkValidator;

    public function __construct(TemporaryEmployerRepository $repository, TemporaryEmployerValidator $validator, ReleaseWorkValidator $releaseWorkValidator)
    {
        $this->repository           = $repository;
        $this->validator            = $validator;
        $this->releaseWorkValidator = $releaseWorkValidator;
    }


    /**
     * @SWG\Post(path="/index.php/api/employee/temporaryEmployer/registration",
     *   tags={"temporaryEmployer/registration"},
     *   summary="temporaryEmployer registration",
     *   description="temporaryEmployer registration",
     *   operationId="temporaryEmployer registration",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="apply_name",type="string",  description="申请人名称", required=true),
     *   @SWG\Parameter(in="formData",  name="apply_business_name",type="string",  description="公司名称", required=true),
     *   @SWG\Parameter(in="formData",  name="apply_email",type="string",  description="邮箱", required=false),
     *   @SWG\Parameter(in="formData",  name="apply_contact_no",type="string",  description="电话号码包含区号和加号", required=true),
     *   @SWG\Parameter(in="formData",  name="request_job_date",type="string",  description="申请日期", required=true),
     *   @SWG\Parameter(in="formData",  name="request_job_title",  type="string",description="工作标题", required=true),
     *   @SWG\Parameter(in="formData",  name="staff_required",type="number",  description="需要的职工数", required=true),
     *   @SWG\Parameter(in="formData",  name="from",type="string",  description="来自哪个渠道app,h5两种.默认app", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function registration(Request $request)
    {
        $data = [];
        try{
            if(date('Y-m-d',strtotime($request->request_job_date)) < date('Y-m-d', time())){
                throw new ValidatorException(new MessageBag(['request_job_date' =>'request_job_date must more than or equal current date']));
            }
            $this->validator->with($request->all())->passesOrFail('registration');

            (new TemporaryEmployerRepository())->apply();

            return apiReturn($data);
        }catch(ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/temporaryEmployer/releaseWork",
     *   tags={"temporaryEmployer/releaseWork"},
     *   summary="雇主发布工作需求",
     *   description="雇主发布工作需求",
     *   operationId="temporaryEmployer_releaseWork",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData",  name="remark",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="formData",  name="signature",type="string",  description="签名", required=true),
     *   @SWG\Parameter(in="formData",  name="employer_admin_id",type="integer",  description="账号ID", required=true),
     *   @SWG\Parameter(in="formData",  name="date",type="string",  description="日期（2018-10-14）", required=true),
     *   @SWG\Parameter(in="formData",  name="start_time",type="string",  description="开始时间（09:00）", required=true),
     *   @SWG\Parameter(in="formData",  name="end_time",type="string",  description="结束时间（09:00）", required=true),
     *   @SWG\Parameter(in="formData",  name="job_title",type="string",  description="工作名称", required=true),
     *   @SWG\Parameter(in="formData",  name="need_num",type="string",  description="需要人数", required=true),
     *   @SWG\Parameter(in="formData",  name="banquet",type="integer",  description="部门", required=true),
     *   @SWG\Parameter(in="formData",  name="from",type="string",  description="h5,app.默认app", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */

    public function releaseWork(Request $request)
    {
        $data = [];
        try{
            if(date('Y-m-d',strtotime($request->date)) < date('Y-m-d', time())){
                throw new ValidatorException(new MessageBag(['date'=>'date must more than  or equal current date']));
            }
            if(!preg_match('/^(data:\s*image\/(\w+);base64,)/', $request->signature)){
                throw new ValidatorException(new MessageBag(['signature'=>'you should put base64 pic!']));
            }
            $startTime = $request->start_time;
            $endTime   = $request->end_time;
            if($startTime > $endTime){
                throw new ValidatorException(new MessageBag(['start_time'=>'start_time must less than end_time']));
            }
            $this->releaseWorkValidator->with($request->all())->passesOrFail('releaseWork');

            $this->repository->releaseWork($request);
            return apiReturn($data);
        }catch(ValidatorException $e){
            return apiReturn([], 403, $e->getMessageBag()->first());
        }

    }


    /**
     * @SWG\Get(path="/index.php/api/employee/temporaryEmployer/application_progress",
     *   tags={"temporaryEmployer/application_progress"},
     *   summary="雇主发布工作的进度",
     *   description="雇主发布工作的进度",
     *   operationId="temporaryEmployer_application_progress",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页(无需分页不用传)", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10无需分页不用传)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function application_progress(Request $request)
    {
        try{
            $data = $this->repository->application_progress();

            return apiReturn($data);
        }catch(ValidatorException $e){
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}