<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/6/17
 * Time: 18:45
 */

namespace App\Api\V6\Member\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Api\V6\Member\Criteria\Rewards\ListCriteria;
use App\Api\V6\Member\Presenters\Rewards\ListPresenter;
use App\Api\V6\Member\Repositories\RewardsRepository;
use Prettus\Validator\Exceptions\ValidatorException;
use Illuminate\Validation\Rule;
class RewardsController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(RewardsRepository $repository)
    {
        $this->repository           = $repository;
    }


    /**
     * @SWG\Get(path="/index.php/api/employee/rewards/rewardsList",
     *   tags={"rewards/rewardsList"},
     *   summary="积分商城列表",
     *   description="积分商城列表",
     *   operationId="rewards_index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="integer",  description="当前页(无需分页不用传)", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="integer",  description="每页条数(无需分页不用传)", required=false),
     *   @SWG\Parameter(in="query",  name="cate_id",type="integer",  description="分类id", required=false),
     *   @SWG\Parameter(in="query",  name="start_point",type="integer",  description="开始查询积分点", required=false),
     *   @SWG\Parameter(in="query",  name="end_point",type="integer",  description="结束查询积分点", required=false),
     *   @SWG\Parameter(in="query",  name="sort",type="integer",  description="1:Latest 2:Popularity 3:Low to High 4:High to Low", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function rewardsList(Request $request)
    {
        try {
            $this->repository->pushCriteria(ListCriteria::class);
            $this->repository->setPresenter(ListPresenter::class);
            $data = $this->repository->rewardsList();

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }



    /**
     * @SWG\Get(path="/index.php/api/employee/rewards/detail",
     *   tags={"rewards/detail"},
     *   summary="积分商城详情页",
     *   description="积分商城详情",
     *   operationId="rewards_index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="id",type="integer",  description="rewards Id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(Request $request)
    {
        try {
            $this->validate($request,
            [
                'id'=>'required',
            ]);

            $data = $this->repository->rewardsDetail($request->id);
            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

}