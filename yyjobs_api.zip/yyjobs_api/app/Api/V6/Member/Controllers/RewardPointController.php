<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/6/18
 * Time: 15:29
 */

namespace App\Api\V6\Member\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Prettus\Validator\Exceptions\ValidatorException;
use App\Api\V6\Member\Validators\RewardPointValidator;
use App\Api\V6\Member\Criteria\RewardPoint\IndexCriteria;
use App\Api\V6\Member\Presenters\RewardPoint\IndexPresenter;
use App\Api\V6\Member\Repositories\Rewards\RewardsPointRecordRepository;

class RewardPointController extends Controller
{
    protected $repository;
    protected $validator;

    public function __construct(RewardsPointRecordRepository $repository,RewardPointValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/reward-point/list",
     *   tags={"reward-point"},
     *   summary="积分列表",
     *   description="积分列表",
     *   operationId="reward-point-list",
     *   @SWG\Parameter(in="query",  name="status",type="integer",  description="状态（-1：消耗的，0：全部，1：赚取的）", required=false),
     *   @SWG\Parameter(in="query",  name="cur_page",type="integer",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="integer",  description="每页条数", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('index');
            $this->repository->pushCriteria(IndexCriteria::class);
            $this->repository->setPresenter(IndexPresenter::class);
            $data = $this->repository->rewardPointList($request);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/reward-point/checkin",
     *   tags={"reward-point"},
     *   summary="签到",
     *   description="签到",
     *   operationId="reward-point checkin",
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function checkin(Request $request)
    {
        $data = $this->repository->checkin(auth('member')->user());
        return apiReturn($data);
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/reward-point/level",
     *   tags={"reward-point"},
     *   summary="我的等级以及积分",
     *   description="我的等级以及积分",
     *   operationId="reward-point-level",
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function level(Request $request)
    {
        $data = $this->repository->myLevel();
        return apiReturn($data);
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/reward-point/has-checkin",
     *   tags={"reward-point"},
     *   summary="通过传入日期检查该天是否签到过",
     *   description="通过传入日期检查该天是否签到过",
     *   operationId="reward-point-has-checkin",
     *   @SWG\Parameter(in="query",  name="day",type="string",  description="需要检查的日期(2019-07-01，默认今天)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v6+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function hasCheck(Request $request)
    {
        try {
            $this->validator->with($request->all())->passesOrFail('hasCheck');

            $member = auth('member')->user();
            $day    = $request->input('day');

            $data = $this->repository->hasCheck($member->member_id,$day);

            return apiReturn($data);
        } catch (ValidatorException $e) {
            return apiReturn([], 403, $e->getMessageBag()->first());
        }
    }
}