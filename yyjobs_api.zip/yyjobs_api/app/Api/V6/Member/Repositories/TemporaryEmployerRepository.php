<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/6/4
 * Time: 15:52
 */

namespace App\Api\V6\Member\Repositories;

use App\Api\V4\Employer\Repositories\RecruiterNotificationsRepository;
use App\Api\V6\Employer\Entities\Admin;
use App\Api\V6\Member\Entities\EmployerApply;
use App\Traits\Admin\Jpush;
use Carbon\Carbon;
use App\Api\V6\Member\Entities\LabourRequisition;
use App\Api\V6\Member\Entities\LabourRequisitionRemark;
use App\Api\V6\Member\Transformers\TemporaryEmployer\ApplicationProgressTransformer;
use Storage;
class TemporaryEmployerRepository
{
    use Jpush;
    protected $model;
    protected $requisitionsModel;
    public function __construct()
    {
        $this->model             = new EmployerApply();
        $this->requisitionsModel = new LabourRequisition();
    }

    public function apply()
    {
        $data = request()->all();
        $data['apply_time'] = time();
        $data['request_job_date'] = date('Y-m-d',strtotime(request()->request_job_date));
        $this->model->create($data);
    }


    public function releaseWork($request)
    {
        //新增remark
        \DB::transaction(function () use($request){
            $remark['signature'] = $this->putBase64Pic();
            $remark['remark']    = $request->remark;
            $remarkData = (new LabourRequisitionRemark())->create($remark);

            $jobStart = date('Y-m-d H:i:s', strtotime($request->date.' '.$request->start_time.':00'));
            $jobEnd   = date('Y-m-d H:i:s', strtotime($request->date.' '.$request->end_time.':00'));
            $releaseArr = $request->except('_token', 'remark','signature', 'date', 'start_time', 'end_time');
            $releaseArr['remark_id'] = $remarkData->id;
            $releaseArr['job_start'] = $jobStart;
            $releaseArr['job_end']   = $jobEnd;
            $releaseArr['add_time']  =  Carbon::now()->toDateTimeString();

            $requisition = (new LabourRequisition())->create($releaseArr);

            //通知
            $recruiter = Admin::whereRaw("FIND_IN_SET('{$request->employer_admin_id}',has_employer)")->first();
            $employer = Admin::find($request->employer_admin_id);
            if ($recruiter){
                $requisitionRepository = app(RecruiterNotificationsRepository::class);
                $data = $requisitionRepository->saveNewRequisition($recruiter,$employer,$requisition);
                if ($recruiter->registration_id != ''){
                    $this->notifyNewRequisitionToRecruiter($data,$recruiter->registration_id);
                }
            }


        });
    }

    public function releaseWork_bak()
    {
        //新增remark
        \DB::transaction(function () {
            $remark_insert['signature'] = $this->putBase64Pic();
            $remark_insert['remark']    = request('remark');
            $remark_data = (new LabourRequisitionRemark())->create($remark_insert);

            $remark_id = $remark_data->id;
            $job_start = date('Y-m-d H:i:s', strtotime(request('date').' '.request('start_time').':00'));
            $job_end   = date('Y-m-d H:i:s', strtotime(request('date').' '.request('end_time').':00'));
            $releaseArr = request()->except('_token', 'remark','signature', 'date', 'start_time', 'end_time');

            $releaseArr['remark_id'] = $remark_id;
            $releaseArr['job_start'] = $job_start;
            $releaseArr['job_end']   = $job_end;
            $releaseArr['add_time']  =  Carbon::now()->toDateTimeString();
            (new LabourRequisition())->create($releaseArr);

        });
    }



    public function putBase64Pic()
    {
        $imgstr = request()->signature;
        preg_match('/^(data:\s*image\/(\w+);base64,)/', $imgstr, $result);
        $type = $result[2];

        $imgdata = substr($imgstr,strpos($imgstr,",") + 1);
        $decodedData = base64_decode($imgdata);
        $path = generateFilePath().time().'.'.$type;
        Storage::put($path, $decodedData, 'public');
        return generateFileUrl($path);
    }


    public function application_progress()
    {
        $curPage  =  request()->input('cur_page');
        $pageSize =  request()->input('page_size');

        $mark = ($curPage && $pageSize) ? true : false;

        $employerId = auth('employer')->user()->id;
        $obj = $this->requisitionsModel->where('employer_admin_id', $employerId);

        $data['count']       = $obj->count();

        $data['curPage']     = $curPage ? $curPage :1;
        $data['pageSize']    = $pageSize ? $pageSize :10;
        $data['countPage']   = ceil($data['count'] / $data['pageSize']);

        $results = $obj ->when($mark,function($q) use($curPage,$pageSize){
            $q->offset(($curPage - 1) * $pageSize);
            $q->limit($pageSize);
        })->orderBy('id', 'desc')->get();

        
        $data['list'] = (new ApplicationProgressTransformer())->transform($results);

        return $data;
    }
}