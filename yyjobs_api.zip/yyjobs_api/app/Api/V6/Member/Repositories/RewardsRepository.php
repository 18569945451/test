<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/6/18
 * Time: 9:40
 */

namespace App\Api\V6\Member\Repositories;

use App\Api\V6\Member\Entities\Rewards;
use App\Api\V6\Member\Entities\RewardsCate;
use App\Api\V6\Member\Entities\RewardsExchange;
use App\Api\V6\Member\Entities\RewardsPointRecord;
use Carbon\Carbon;
use Illuminate\Support\MessageBag;
use Prettus\Validator\Exceptions\ValidatorException;
use Prettus\Repository\Eloquent\BaseRepository;

class RewardsRepository  extends BaseRepository
{
    public function model()
    {
        return Rewards::class;
    }

    public function rewardsList()
    {
        $member_id = auth('member')->user()->member_id;
//        $member_id = 1;
        $this->applyCriteria();
        $currentTime = Carbon::today();

        $cateId      = request('cate_id');
        $sort        = request('sort');

        $startPoint  = request('start_point');
        $endPoint    = request('end_point');

        $curPage     =  request()->input('cur_page');
        $pageSize    =  request()->input('page_size');
        $mark        =  ($curPage && $pageSize) ? true : false;

        $condition   =  $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage ? $curPage :1;
        $data['pageSize']    = $pageSize ? $pageSize :10;
        $data['countPage']   = ceil($data['count'] / $data['pageSize']);

        $obj = $condition->when($cateId,function($q) use($cateId){
                            $q->where('cate_id',$cateId);
                        })
                        ->when($mark,function($q) use($curPage,$pageSize){
                            $q->offset(($curPage - 1) * $pageSize);
                            $q->limit($pageSize);
                        })
                        ->when($startPoint, function($q) use($startPoint){
                            $q->where('points', '>=', $startPoint);
                        })
                        ->when($endPoint, function($q) use($endPoint){
                            $q->where('points', '<=', $endPoint);
                        })
                        ->where('start_time', '<=', $currentTime)
                        ->where('end_time','>=',$currentTime);

        switch($sort){
            //最新的
            case 1:
                $obj->orderBy('id', 'desc');
                break;
            case 2:
              //最受欢迎的
                $obj->orderBy('convert_num', 'desc');
                break;
            case 3:
                //积分需要从小到大
                $obj->orderBy('points', 'asc');
                break;
            case 4:
                //积分需要从大到小
                $obj->orderBy('points', 'desc');
                break;
            default:
        }
        $result =  $obj->get();

        $data['list']       = $this->parserResult($result)['data'];
        $data['category']   = RewardsCate::select('id', 'title', 'icon')->orderBy('sort', 'asc')->get();
        return $data;


    }



    public function rewardsDetail($id)
    {
        $member_id = auth('member')->user()->member_id;
        if(!$this->model->where('id', $id)->first()){
            throw new ValidatorException(new MessageBag(['id'=>['Id Field invalid']]));
        }
        $data = $this->find($id,
            [
                'id',
                'title',
                'points',
                'stock_num',
                'start_time',
                'end_time',
                'image',
                'convert_num',
                'terms_condition',
                'address',
                'contact_no',
                'cate_id',
                'highlight'
            ]
        );
        $data->icon        = RewardsCate::where('id', $data->cate_id)->value('icon');
        $data->start_time  = Carbon::parse($data->start_time)->format('d M Y');
        $data->end_time    = Carbon::parse($data->end_time)->format('d M Y');
        $data->has_convert = ((new RewardsExchange())->member_has_convert($member_id, $id)) >0 ? 1 : 0;
        return $data;
    }

}