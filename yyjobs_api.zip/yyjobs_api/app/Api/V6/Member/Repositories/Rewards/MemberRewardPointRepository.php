<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/6/19
 * Time: 16:43
 */

namespace App\Api\V6\Member\Repositories\Rewards;

use Carbon\Carbon;
use Illuminate\Support\Facades\Redis;
use App\Api\V6\Member\Entities\Member;
use App\Api\V6\Member\Entities\RewardsPointRecord as RewardsPointRecordModel;

class MemberRewardPointRepository
{
    private $model;

    private $todayFinished;

    public function __construct()
    {
        $this->model = new RewardsPointRecordModel();
        $this->todayFinished = Carbon::tomorrow()->getTimestamp();
        //$this->todayFinished = Carbon::parse('2020-01-01 00:00:00')->getTimestamp();
    }

    /**
     * 获取用户的可用积分
     * @param     $memberID
     * @param int $point
     *
     * @return int|mixed
     */
    public function redisMemberRewardPointAvailable($memberID,$point = 0)
    {
        $key = "yyjobs:member_reward_points_available:{$this->todayFinished}";

        $rank = Redis::zrank($key,$memberID);

        if ($rank === null){
            $memberAvailablePoint = $this->model->mine($memberID)->sum('point');
            Redis::zadd($key,$memberAvailablePoint,$memberID);
        }else{
            $scores = Redis::zrange($key,$rank,$rank,['withscores'=>true]);
            $memberAvailablePoint = array_first($scores);
            Redis::zincrby($key,$point,$memberID);
        }

        Redis::expireat($key, $this->todayFinished);

        return $rank === null ? $memberAvailablePoint : $memberAvailablePoint + $point;
    }

    /**
     * 获取用户的历史获得总积分
     * @param     $memberID
     * @param int $point
     *
     * @return int|mixed
     */
    public function redisMemberRewardPointTotal($memberID,$point = 0)
    {
        $key = "yyjobs:member_reward_points_total:{$this->todayFinished}";

        //获取用户总的历史得分
        $rank = Redis::zrank($key,$memberID);

        //如果集合中没有这个用户总的历史得分，那么就从数据库取出来存入Redis
        if ($rank === null){
            $memberPoint = $this->model->mine($memberID)->where('point','>',0)->sum('point');
            Redis::zadd($key,$memberPoint,$memberID);
        }else{
            $scores = Redis::zrange($key,$rank,$rank,['withscores'=>true]);
            $memberPoint = array_first($scores);

            //历史获得总积分只增不减
            if ($point > 0){
                Redis::zincrby($key,$point,$memberID);
            }
        }

        Redis::expireat($key, $this->todayFinished);

        return $rank === null ? $memberPoint : $memberPoint + $point;
    }


    /**
     * 获取用户积分等级
     * @param     $memberID
     *
     * @return int|mixed
     */
    public function redisMemberRewardPointLevel($memberID)
    {
        $memberPointTotal = $this->redisMemberRewardPointTotal($memberID);

        $levelSetting = config('rewardspoint.level');

        $latestLevel = 1;
        foreach ($levelSetting as $key => $value) {
            if ($memberPointTotal >= $value['min'] && $memberPointTotal <= $value['max']) {
                $latestLevel = $key;
            }
        }

        $key = "yyjobs:member_reward_points_level:{$this->todayFinished}";

        $rank = Redis::zrank($key,$memberID);
        if ($rank === null){
            $memberPointLevel = array_first(Member::find($memberID,['reward_point_level'])->toArray());
        }else{
            $scores = Redis::zrange($key,$rank,$rank,['withscores'=>true]);
            $memberPointLevel = array_first($scores);
        }

        //如果最新计算出来的等级大于上一次的等级，那么就用更新数据库
        if($latestLevel > $memberPointLevel){
            $upLevel = $latestLevel;
            Member::where('member_id',$memberID)->update(['reward_point_level'=>$latestLevel]);
        }else{
            $upLevel = $memberPointLevel;
        }

        Redis::zadd($key,$upLevel,$memberID);
        Redis::expireat($key, $this->todayFinished);

        //因为计算倍率需要实际达到相关等级，本次增加的积分数不参与计算，所以返回上一次的等级
        return $memberPointLevel;
    }

    /**
     * 取记号
     * @param $memberID
     *
     * @return array
     */
    public function getHasType($memberID)
    {
        $types = ['Daily_Check_In','Promotion_Apply','NewsFeed_Post'];
        $typesData = $this->model->mine($memberID)->today()
                          ->whereIn('recordable_type',$types)
                          ->groupBy('recordable_type')->get(['id','recordable_type']);

        $typesDataArray = array_column($typesData->toArray(),null,'recordable_type');
        $returnData = [];
        foreach ($types as $type) {
            $returnData[$type] = isset($typesDataArray[$type])  ? true : false;
        }

        return $returnData;
    }

    /**
     * 取记号
     * @param $memberID
     * @param $type
     *
     * @return bool
     */
    public function getHasType_bak($memberID, $type)
    {
        $key = "yyjobs:member_has_type:{$type}:{$this->todayFinished}";
        return !!Redis::getbit($key,$memberID);
    }
}