<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/6/17
 * Time: 16:35
 */

namespace App\Api\V6\Member\Repositories\Rewards;

use Illuminate\Http\Request;
use App\Api\V6\Member\Jobs\RewardsPointRecord;
use Prettus\Repository\Eloquent\BaseRepository;
use App\Api\V6\Member\Entities\RewardsPointRecord as RewardsPointRecordModel;

class RewardsPointRecordRepository extends BaseRepository
{
    public function model()
    {
        return RewardsPointRecordModel::class;
    }

    /**
     * @param \App\Models\Member $member
     * @return bool
     */
    public function checkin($member)
    {
        //rewards 积分
        RewardsPointRecord::dispatch($member,'Daily_Check_In');
        return true;
    }

    /**
     * 积分列表
     * @param Request $request
     *
     * @return mixed
     */
    public function rewardPointList(Request $request)
    {
        $this->applyCriteria();

        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 10);
        $offset   = ($curPage - 1) * $pageSize;

        $condition = $this->model;

        $data['count']       = $condition->count();
        $data['curPage']     = $curPage;
        $data['pageSize']    = $pageSize;
        $data['countPage']   = ceil($data['count'] / $pageSize);

        $result = $condition->orderBy('id','DESC')->offset($offset)->limit($pageSize)->get();

        $data['list']        = $this->parserResult($result)['data'];

        return $data;
    }

    /**
     * @return array
     */
    public function myLevel()
    {
        $member = auth('member')->user();
        $repository = new MemberRewardPointRepository();

        $total     = $repository->redisMemberRewardPointTotal($member->member_id);
        $available = $repository->redisMemberRewardPointAvailable($member->member_id);
        $level     = $repository->redisMemberRewardPointLevel($member->member_id);
        $hasTypes  = $repository->getHasType($member->member_id);

        return [
            'total'           => $total,
            'level'           => $level,
            'available'       => $available,
            'level_alias'     => config('rewardspoint.level')[$level]['alias'],
            'daily_check_in'  => $hasTypes['Daily_Check_In'],
            'promotion_apply' => $hasTypes['Promotion_Apply'],
            'news_feed_post'  => $hasTypes['NewsFeed_Post'],
            'continuous_days' => $member->continuous_days,
        ];
    }

    /**
     * 今天是否签到
     * @param $memberID
     * @param string $day
     * @return bool
     */
    public function hasCheck($memberID,$day)
    {
        return !!$this->model->mine($memberID)->dayForType('Daily_Check_In',$day)->first();
    }
}