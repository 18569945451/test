<?php
/**
 * Created by PhpStorm.
 * User: XiaoAiLing
 * Date: 2019/6/18
 * Time: 9:40
 */

namespace App\Api\V6\Member\Repositories;

use App\Api\V6\Member\Entities\RewardsExchange;
use App\Api\V6\Member\Entities\Rewards;
use App\Api\V6\Member\Entities\RewardsPointRecord;
use App\Api\V6\Member\Jobs\RewardsPointRecord as RewardsPointRecordJobs;
use Carbon\Carbon;
use Illuminate\Support\MessageBag;
use Illuminate\Validation\ValidationException;
use Prettus\Validator\Exceptions\ValidatorException;
use Prettus\Repository\Eloquent\BaseRepository;

class RewardsExchangeRepository  extends BaseRepository
{
    public function model()
    {
        return RewardsExchange::class;
    }


    public function convertRewards(&$code)
    {
        $user        = auth('member')->user();
        $memberId    = $user->member_id;
        $rewardsId   = request('id');
        $currentDate = Carbon::today();
        if(!Rewards::where('id', request('id'))->where('start_time', '<=', $currentDate)->where('end_time', '>=', $currentDate)->first())
        {
            $code = -3;
            throw new ValidatorException(new MessageBag(['id'=>['Id Field invalid']]));
        }

        //积分是否足够
        $memberPoints    =  (new RewardsPointRecord())->getMemberPoints($memberId);
        $pointsData      =  Rewards::where('id', $rewardsId)->first();

        if($memberPoints < $pointsData->points){
            $code = -2;
            throw new ValidatorException(new MessageBag(['id'=>['You do not have enough Points!']]));
        }

        if($pointsData->convert_num >= $pointsData->stock_num){
            $code = -5;
            throw new ValidatorException(new MessageBag(['id'=>['This item is sold out']]));
        }
        $data = array(
            'member_info' => $user,
            'rewards_id'  => $rewardsId,
            'pointsData'  => $pointsData
        );

        return RewardsPointRecordJobs::dispatch($data,'Item_Redemption');
    }




    public function myRewards()
    {
        $memberId  = auth('member')->user()->member_id;
        return $this->model->where('status', 'UnCompleted')->where('member_id', $memberId)
            ->join('rewards', 'rewards.id', 'rewards_exchange.rewards_id')
            ->join('rewards_cate', 'rewards_cate.id', 'rewards.cate_id')
            ->orderBy('rewards_exchange.id', 'desc')
            ->get(['rewards.id', 'rewards_exchange.rewards_title' ,'rewards_exchange.rewards_point', 'rewards_exchange.status', 'rewards_cate.icon_square as icon']);
    }


    public function receive_rewards()
    {
        $memberId  = auth('member')->user()->member_id;
        $code      = request('code');
        /**
         * 如果一个商品在同一个用户上面有多条兑换记录，且都是未完成，输入时code有重复也没有关系，避免code有重复
         */
        $data      = $this->model->where('member_id', $memberId)
                                 ->where('status', 'UnCompleted')
                                 ->where('rewards_id', request('id'))
                                 ->whereRaw( ("binary code = '$code'"))
                                 ->first();
        if(!$data){
            throw new ValidatorException(new MessageBag(['code'=>['Invalid Code']]));
        }
        $rewards_exchange_id = $data->id;
        $this->model->where('id', $rewards_exchange_id)->update(array('status'=>'Completed', 'updated_at'=>Carbon::now()));
    }


}