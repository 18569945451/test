<?php
/**
 * Created by PhpStorm.
 * User: wangxiao
 * Date: 2019/2/20
 * Time: 16:13
 */
namespace App\Api\V6\Employer\Entities;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    /**
     * 表名
     * @var string
     */
    protected $table = 'admins';


    /**
     * 主键
     * @var string
     */
    protected $primaryKey = 'id';


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        //'password',
    ];

    /**
     * @var array
     */
    protected $fillable = ['name', 'email', 'password', 'remember_token', 'created_at', 'updated_at', 'type', 'has_employer', 'registration_id','status'];


    public $timestamps = false;
}
