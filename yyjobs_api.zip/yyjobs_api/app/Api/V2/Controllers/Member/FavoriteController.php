<?php

namespace App\Api\V2\Controllers\Member;

use App\Api\V2\Repositories\FavoriteRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class FavoriteController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/employee/favorite/favorite",
     *   tags={"employee/favorite"},
     *   summary="点赞、取消点赞",
     *   description="点赞、取消点赞",
     *   operationId="favorite",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="merchant_id",type="string",  description="商户id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function favorite(Request $request)
    {
        $favRep     = app(FavoriteRepository::class);

        $memberId   = auth('member')->user()->member_id;
        $merchantId = $request->input('merchant_id');

        $res = $favRep->favorite($memberId, $merchantId);

        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/favorite/list",
     *   tags={"employee/favorite"},
     *   summary="商户点赞列表",
     *   description="商户点赞列表",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="query",  name="start_time",type="string",  description="开始时间(时间戳)", required=false),
     *   @SWG\Parameter(in="query",  name="end_time",type="string",  description="结束时间(时间戳)", required=false),
     *   @SWG\Parameter(in="query",  name="merchant_id",type="string",  description="商户id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function lists(Request $request)
    {
        $favRep = app(FavoriteRepository::class);

        $curPage    = $request->input('cur_page', 1);
        $pageSize   = $request->input('page_size', 10);
        $startTime  = $request->input('start_time', 1);
        $endTime    = $request->input('end_time', 1830268800);
        $merchantId = $request->input('merchant_id');

        $res = $favRep->search($curPage, $pageSize, $startTime, $endTime,$merchantId);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }
}