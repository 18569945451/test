<?php

namespace App\Api\V2\Controllers\Member;

use App\Api\V2\Jobs\Merchant\SendReceivePointEmail;
use App\Api\V2\Repositories\MemberPointRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PointController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/employee/point/history",
     *   tags={"employee/point"},
     *   summary="积分记录",
     *   description="积分记录",
     *   operationId="history",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="by",type="string",  description="month,day", required=false),
     *   @SWG\Parameter(in="query",  name="start_timestamps",type="string",  description="开始时间戳", required=false),
     *   @SWG\Parameter(in="query",  name="end_timestamps",type="string",  description="结束时间戳", required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="<table>
    <tr>请求成功</tr>
    <tr><td>log_id</td><td>记录id</td></tr>
    <tr><td>change_type</td><td>变更类型（1：completed job 完成工作 + ，2：consume 消费 - ）</td></tr>
    <tr><td>change_value</td><td>变更值（正、负数）</td></tr>
    <tr><td>log_time</td><td>变更时间戳</td></tr>
    <tr><td>job_title</td><td>工作名称</td></tr>
    <tr><td>job_image</td><td>工作图片</td></tr>
    <tr><td>merchant_name</td><td>商户名称</td></tr>
    <tr><td>merchant_logo</td><td>商户logo</td></tr>
    </table>"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function history(Request $request)
    {
        $pointRep = app(MemberPointRepository::class);

        $by              = $request->input('by', 'month');
        $keyword         = $request->input('keyword');
        $memberId        = auth('member')->user()->member_id;
        $startTimestamps = $request->input('start_timestamps');
        $endTimestamps   = $request->input('end_timestamps');

        /*if ($by == 'month'){
            if(!$startDate){
                $startDate = 0;
                $endDate = 1830268800;
            }else{
                $endDate = date(strtotime("+1 months", strtotime($startDate)));
                $startDate = strtotime($startDate);
            }
        }else{
            $startDate = strtotime($startDate);
            $endDate = strtotime($endDate);
        }

        $res = $pointRep->search($by, $startDate, $endDate,$keyword, $memberId);*/
        $res = $pointRep->search($by, $startTimestamps, $endTimestamps,$keyword, $memberId);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/payment/point/pay",
     *   tags={"employee/payment"},
     *   summary="积分购买",
     *   description="积分购买",
     *   operationId="buy",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="money",type="string",  description="消费多少‘钱’", required=true),
     *   @SWG\Parameter(in="formData",  name="merchant_id",type="string",  description="商户id", required=true),
     *   @SWG\Parameter(in="formData",  name="payment_password",type="string",  description="支付密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function pay(Request $request)
    {
        $pointRep = app(MemberPointRepository::class);

        $money           = $request->input('money');
        $merchantId      = $request->input('merchant_id');
        $paymentPassword = $request->input('payment_password');
        $memberId        = auth('member')->user()->member_id;

        $res = $pointRep->pay($memberId, $merchantId, $money, $paymentPassword);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        //支付给商家时，商家收到一个邮件
        $this->dispatch(new SendReceivePointEmail($res['data']))->onQueue('api');

        return apiReturn($res['data']);
    }


    public function history_bak(Request $request)
    {
        $pointRep = app(MemberPointRepository::class);

        $curPage   = $request->input('cur_page', 1);
        $pageSize  = $request->input('page_size', 10);
        $startTime = $request->input('start_time', 1);
        $endTime   = $request->input('end_time', 1830268800);
        $keyword   = $request->input('keyword');
        $memberId  = auth('member')->user()->member_id;

        $res = $pointRep->search($curPage, $pageSize, $startTime, $endTime, $memberId,$keyword);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }
}