<?php

namespace App\Api\V2\Controllers\Member;

use App\Api\V2\Repositories\MemberNotificationsRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class NotificationController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/employee/notification/list",
     *   tags={"employee/notification"},
     *   summary="通知列表",
     *   description="通知列表",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认30)", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function lists(Request $request)
    {
        $notifyRep = app(MemberNotificationsRepository::class);

        $curPage    = $request->input('cur_page', 1);
        $pageSize   = $request->input('page_size', 30);
        $memberId   = auth('member')->user()->member_id;

        $res = $notifyRep->search($curPage, $pageSize, $memberId);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/notification/remove",
     *   tags={"employee/notification"},
     *   summary="删除通知",
     *   description="删除通知",
     *   operationId="remove",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="msg_id",type="string",  description="0:全部删除", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function remove(Request $request)
    {
        $notifyRep = app(MemberNotificationsRepository::class);

        $msgId    = $request->input('msg_id', 0);
        $memberId = auth('member')->user()->member_id;

        $res = $notifyRep->remove($msgId,$memberId);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/notification/read",
     *   tags={"employee/notification"},
     *   summary="已读通知",
     *   description="已读通知",
     *   operationId="read",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="msg_id",type="string",  description="0:全部已读", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function read(Request $request)
    {
        $notifyRep = app(MemberNotificationsRepository::class);

        $msgId    = $request->input('msg_id', 0);
        $memberId = auth('member')->user()->member_id;

        $res = $notifyRep->read($msgId,$memberId);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }
}