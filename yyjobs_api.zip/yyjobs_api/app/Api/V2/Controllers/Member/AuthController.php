<?php

namespace App\Api\V2\Controllers\Member;

use Illuminate\Http\Request;
use App\Models\Member;
use App\Http\Controllers\Controller;
use App\Api\V2\Repositories\EmployeeRepository;
use Tymon\JWTAuth\JWTAuth;

class AuthController extends Controller
{

    /**
     * @SWG\Post(path="/index.php/api/employee/auth/register",
     *   tags={"employee/auth"},
     *   summary="普通注册",
     *   description="普通注册",
     *   operationId="register",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="name",type="string",  description="姓名", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=false),
     *   @SWG\Parameter(in="formData",  name="nric_no",type="string",  description="身份证号", required=true),
     *   @SWG\Parameter(in="formData",  name="mobile_no",type="string",  description="电话号码", required=true),
     *   @SWG\Parameter(in="formData",  name="school",type="integer",  description="学校id", required=false),
     *   @SWG\Parameter(in="formData",  name="registration_id",type="string",  description="设备id", required=true),
     *   @SWG\Parameter(in="formData",  name="invite_code",type="string",  description="邀请码", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function register()
    {
        $employeeRep = app(EmployeeRepository::class);
        $res = $employeeRep->registerForMobile(request()->all());
        if ($res['error']){
            $code = empty($res['code']) ? 403 : $res['code'];
            return apiReturn([], $code, $res['msg']);
        }
        return apiReturn($res['data']);

    }

    /**
     * @SWG\Post(path="/index.php/api/employee/auth/register/fb",
     *   tags={"employee/auth"},
     *   summary="Facebook注册",
     *   description="Facebook注册",
     *   operationId="register/fb",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="name",type="string",  description="姓名", required=true),
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=false),
     *   @SWG\Parameter(in="formData",  name="nric_no",type="string",  description="身份证号", required=true),
     *   @SWG\Parameter(in="formData",  name="mobile_no",type="string",  description="电话号码", required=true),
     *   @SWG\Parameter(in="formData",  name="school",type="integer",  description="学校id", required=false),
     *   @SWG\Parameter(in="formData",  name="social_access_token",type="string",  description="第三方Token", required=true),
     *   @SWG\Parameter(in="formData",  name="social_fb_id",type="string",  description="第三方id", required=true),
     *   @SWG\Parameter(in="formData",  name="registration_id",type="string",  description="设备id", required=true),
     *   @SWG\Parameter(in="formData",  name="platform",type="string",  description="注册平台（1：ios，2：android，3：web）", required=true),
     *   @SWG\Parameter(in="formData",  name="invite_code",type="string",  description="邀请码", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function registerForFacebook()
    {
        $employeeRep = app(EmployeeRepository::class);
        $res = $employeeRep->registerForFacebook(request()->all());
        if ($res['error']){
            $code = empty($res['code']) ? 403 : $res['code'];
            return apiReturn([], $code, $res['msg']);
        }
        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/auth/register/google",
     *   tags={"employee/auth"},
     *   summary="google注册",
     *   description="google注册",
     *   operationId="register/google",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="name",type="string",  description="姓名", required=true),
     *   @SWG\Parameter(in="formData",  name="email",type="string",  description="邮箱", required=false),
     *   @SWG\Parameter(in="formData",  name="nric_no",type="string",  description="身份证号", required=true),
     *   @SWG\Parameter(in="formData",  name="mobile_no",type="string",  description="电话号码", required=true),
     *   @SWG\Parameter(in="formData",  name="school",type="integer",  description="学校id", required=false),
     *   @SWG\Parameter(in="formData",  name="social_access_token",type="string",  description="第三方Token", required=true),
     *   @SWG\Parameter(in="formData",  name="social_google_id",type="string",  description="第三方id", required=true),
     *   @SWG\Parameter(in="formData",  name="registration_id",type="string",  description="设备id", required=true),
     *   @SWG\Parameter(in="formData",  name="platform",type="string",  description="注册平台（1：ios，2：android，3：web）", required=true),
     *   @SWG\Parameter(in="formData",  name="invite_code",type="string",  description="邀请码", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function registerForGoogle()
    {
        $employeeRep = app(EmployeeRepository::class);
        $res = $employeeRep->registerForGoogle(request()->all());
        if ($res['error']){
            $code = empty($res['code']) ? 403 : $res['code'];
            return apiReturn([], $code, $res['msg']);
        }
        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/auth/refresh/token",
     *   tags={"employee/auth"},
     *   summary="刷新Token",
     *   description="刷新Token",
     *   operationId="auth/refresh/token",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function refreshToken()
    {
        $member = auth('member')->user();
        $jwt = app(JWTAuth::class);
        $data['member_id'] = $member->member_id;
        //$data['token'] = auth('member')->refresh(false,true);
        $data['token'] = $jwt->fromUser($member);
        return apiReturn($data);
    }
}