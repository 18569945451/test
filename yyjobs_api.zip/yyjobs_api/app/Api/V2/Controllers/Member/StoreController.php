<?php

namespace App\Api\V2\Controllers\Member;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V2\Repositories\MerchantRepository;

class StoreController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/employee/merchant/list",
     *   tags={"employee/merchant"},
     *   summary="商户列表",
     *   description="商户列表",
     *   operationId="list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认10)", required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="query",  name="latitude",  type="string",  description="用户纬度(默认新加坡市中心1.2897036993)",required=false),
     *   @SWG\Parameter(in="query",  name="longitude",  type="string",  description="用户经度(默认新加坡市中心103.8512840867)",required=false),
     *   @SWG\Parameter(in="query",  name="type",  type="string",  description="列表类型(list：所有（默认） ，favorite：喜欢，nearby：附近)",required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="<table>
    <tr>请求成功</tr>
    <tr><td>merchant_id</td><td>商户id</td></tr>
    <tr><td>merchant_name</td><td>商户名称</td></tr>
    <tr><td>merchant_operation_hours</td><td>商户营业时间</td></tr>
    <tr><td>merchant_logo</td><td>商户图片</td></tr>
    <tr><td>class_name</td><td>商户分类名称</td></tr>
    <tr><td>favorite</td><td>本人是否点赞（1：是，0：否）</td></tr>
    <tr><td>merchant_latitude</td><td>商户纬度</td></tr>
    <tr><td>merchant_longitude</td><td>商户经度</td></tr>
    <tr><td>meter</td><td>距离本人距离（单位：米）</td></tr>
    </table>"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function lists(Request $request)
    {
        $merchantRep = app(MerchantRepository::class);

        $curPage   = $request->input('cur_page', 1);
        $pageSize  = $request->input('page_size', 10);
        $keyword   = $request->input('keyword');
        $latitude  = $request->input('latitude','1.2897036993');
        $longitude = $request->input('longitude','103.8512840867');
        $memberId  = auth('member')->user()->member_id;
        $type      = $request->input('type','list');

        $res = $merchantRep->search($type,$curPage, $pageSize,$memberId,$keyword,$latitude,$longitude);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/merchant/detail",
     *   tags={"employee/merchant"},
     *   summary="商户详情",
     *   description="商户详情",
     *   operationId="detail",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="merchant_id",type="string",  description="商户id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function detail(Request $request)
    {
        $merchantRep = app(MerchantRepository::class);

        $merchantId   = $request->input('merchant_id');

        $res = $merchantRep->detail($merchantId);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }
}