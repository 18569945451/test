<?php

namespace App\Api\V2\Controllers\Member;

use App\Api\V2\Repositories\EmployeeRepository;
use App\Api\V2\Repositories\MemberInviteRepository;
use App\Api\V2\Repositories\MemberRepository;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    /**
     * @SWG\Post(path="/index.php/api/employee/payment/password/set",
     *   tags={"employee/payment"},
     *   summary="设置支付密码",
     *   description="设置支付密码",
     *   operationId="payment/password",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="payment_password",type="string",  description="支付密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function setPaymentPassword(Request $request)
    {
        $password = $request->input('payment_password');

        $memberId = auth('member')->user()->member_id;

        if (strlen($password) != 6 ||  !is_numeric($password)){
            return apiReturn([], 403, 'Parameter error.');
        }

        $memberRep = app(MemberRepository::class);
        $data['member_payment_password'] = bcrypt($password);
        if ($res = $memberRep->update($data,$memberId) !== false){
            return apiReturn($res);
        }

        return apiReturn([],500,'Server Error.');
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/profile/invite/code",
     *   tags={"employee/profile"},
     *   summary="邀请码页面",
     *   description="邀请码页面",
     *   operationId="invite/code",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function inviteCode(Request $request)
    {
        $memberRep = app(MemberRepository::class);
        $memberId  = auth('member')->user()->member_id;

        $res = $memberRep->inviteCode($memberId);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * @SWG\Get(path="/index.php/api/employee/profile/invite/list",
     *   tags={"employee/profile"},
     *   summary="邀请人的列表",
     *   description="邀请人的列表",
     *   operationId="invite/list",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数(默认30)", required=false),
     *   @SWG\Parameter(in="query",  name="status",type="string",  description="邀请状态（0:所有（默认），1：邀请了，但是受邀人没有完成工作，2：受邀人成功完成了一份工作）", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function inviteList(Request $request)
    {
        $curPage  = $request->input('cur_page', 1);
        $pageSize = $request->input('page_size', 30);
        $status   = $request->input('status', 0);
        $memberId = auth('member')->user()->member_id;

        $inviteRep = app(MemberInviteRepository::class);
        $res = $inviteRep->inviteList($memberId,$status,$curPage,$pageSize);
        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/payment/password/forget",
     *   tags={"employee/payment"},
     *   summary="忘记支付密码",
     *   description="忘记支付密码",
     *   operationId="payment/password/forget",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="member_nric",type="string",  description="身份证号", required=true),
     *   @SWG\Parameter(in="formData",  name="member_mobile",type="string",  description="手机号", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="formData",  name="password_confirmation",type="string",  description="确认密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function forgetPaymentPassword(Request $request)
    {
        $infoRep = app(EmployeeRepository::class);
        $member = auth('member')->user();
        $info = $infoRep->forgetPaymentPassword($request->all(),$member);
        if ($info['error']){
            return apiReturn([], 403, $info['msg']);
        }
        return apiReturn($info['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/employee/payment/password/valid",
     *   tags={"employee/payment"},
     *   summary="验证旧支付密码",
     *   description="验证旧支付密码",
     *   operationId="payment/password/valid",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function validPaymentPassword(Request $request)
    {
        $infoRep = app(EmployeeRepository::class);
        $member = auth('member')->user();
        $info = $infoRep->validPaymentPassword($request->all(),$member);
        if ($info['error']){
            return apiReturn([], 403, $info['msg']);
        }
        return apiReturn($info['data']);
    }
}
