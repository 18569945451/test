<?php

namespace App\Api\V2\Controllers\Member;

use App\Api\V2\Repositories\SliderRepository;
use App\Http\Controllers\Controller;

class SliderController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/employee/slider/list",
     *   tags={"employee/slider"},
     *   summary="轮播列表",
     *   description="轮播列表",
     *   operationId="employee/slider",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="200", description="<table>
    <tr>请求成功</tr>
    <tr><td>id</td><td>轮播id</td></tr>
    <tr><td>title</td><td>轮播名称</td></tr>
    <tr><td>image</td><td>图片地址</td></tr>
    <tr><td>type</td><td>轮播类型</td></tr>
    <tr><td>href</td><td>点击链接（type为1时才有）</td></tr>
    <tr><td>job_id</td><td>相关的工作id（type为2时才有）</td></tr>
    </table>"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function lists()
    {
        $sliderRep = app(SliderRepository::class);
        $res       = $sliderRep->getSlider();

        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }
}