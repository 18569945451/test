<?php

namespace App\Api\V2\Controllers\Merchant;

use App\Api\V2\Repositories\MerchantRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/merchant/home/index",
     *   tags={"merchant/home"},
     *   summary="首页",
     *   description="首页",
     *   operationId="index",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function index(Request $request)
    {
        $merchantRep = app(MerchantRepository::class);

        $merchantId = auth('merchant')->user()->merchant_id;

        $res = $merchantRep->index($merchantId);

        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }
}