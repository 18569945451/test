<?php

namespace App\Api\V2\Controllers\Merchant;

use App\Api\V2\Repositories\MerchantPointRepository;
use App\Api\V2\Repositories\MerchantWithdrawRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PointController extends Controller
{
    /**
     * @SWG\Get(path="/index.php/api/merchant/point/history",
     *   tags={"merchant/point"},
     *   summary="积分记录",
     *   description="积分记录",
     *   operationId="history",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="by",type="string",  description="month,day", required=false),
     *   @SWG\Parameter(in="query",  name="start_timestamps",type="string",  description="开始时间戳", required=false),
     *   @SWG\Parameter(in="query",  name="end_timestamps",type="string",  description="结束时间戳", required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function history(Request $request)
    {
        $pointRep = app(MerchantPointRepository::class);

        $by              = $request->input('by', 'month');
        $keyword         = $request->input('keyword');
        $merchantId      = auth('merchant')->user()->merchant_id;
        $startTimestamps = $request->input('start_timestamps');
        $endTimestamps   = $request->input('end_timestamps');

        $res = $pointRep->search($by,$startTimestamps,$endTimestamps,$keyword,$merchantId);

        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * SWG\Get(path="/index.php/api/merchant/point/history/recent",
     *   tags={"merchant/point"},
     *   summary="近期积分记录",
     *   description="近期积分记录",
     *   operationId="recent",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function recent(Request $request)
    {
        $pointRep = app(MerchantPointRepository::class);

        $merchantId = auth('merchant')->user()->merchant_id;
        $res = $pointRep->recent($merchantId);

        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }

    /**
     * @SWG\Get(path="/index.php/api/merchant/point/history/withdraw",
     *   tags={"merchant/point"},
     *   summary="提现记录",
     *   description="提现记录",
     *   operationId="withdraw",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="query",  name="cur_page",type="string",  description="当前页", required=false),
     *   @SWG\Parameter(in="query",  name="page_size",type="string",  description="每页条数", required=false),
     *   @SWG\Parameter(in="query",  name="by",type="string",  description="month,day", required=false),
     *   @SWG\Parameter(in="query",  name="start_date",type="string",  description="日：例2018-04-25，月：例2018-05、2018-04）", required=false),
     *   @SWG\Parameter(in="query",  name="end_date",type="string",  description="结束时间（2018-04-28）只有by day 才有", required=false),
     *   @SWG\Parameter(in="query",  name="keyword",type="string",  description="关键字", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description="<table>
    <tr>请求成功</tr>
    <tr><td>status</td><td>提现状态（1、申请中、2：已同意(待支付)，3、已完成(已支付)）</td></tr>
    </table>"),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function withdraw(Request $request)
    {
        $pointRep = app(MerchantWithdrawRepository::class);

        $curPage    = $request->input('cur_page',1);
        $pageSize   = $request->input('page_size',15);
        $by         = $request->input('by', 'month');
        $startDate  = $request->input('start_date');
        $endDate    = $request->input('end_date');
        if ($by == 'month'){
            if(!$startDate){
                $startDate = 0;
                $endDate = 1830268800;
            }else{
                $endDate = date(strtotime("+1 months", strtotime($startDate)));
                $startDate = strtotime($startDate);
            }
        }else{
            //$endDate = date(strtotime("+1 day", strtotime($startDate)));
            $endDate = strtotime($endDate);
            $startDate = strtotime($startDate);
        }
        

        $keyword    = $request->input('keyword');
        $merchantId = auth('merchant')->user()->merchant_id;

        $res = $pointRep->withdrawList($by,$curPage,$pageSize,$startDate,$endDate,$keyword,$merchantId);

        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }
}