<?php

namespace App\Api\V2\Controllers\Merchant;

use App\Api\V1\Repositories\FileRepository;
use App\Api\V2\Repositories\MerchantRepository;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProfileController extends Controller
{
    /**
     * @SWG\Post(path="/index.php/api/merchant/profile/edit",
     *   tags={"merchant/profile"},
     *   summary="修改商户信息",
     *   description="修改商户信息",
     *   operationId="edit",
     *   consumes={"multipart/form-data"},
     *   @SWG\Parameter(in="formData", name="merchant_uen",type="string",  description="uen", required=true),
     *   @SWG\Parameter(in="formData", name="merchant_logo",type="file",  description="商户logo", required=false),
     *   @SWG\Parameter(in="formData", name="merchant_contact_name",type="string",  description="联系人", required=true),
     *   @SWG\Parameter(in="formData", name="merchant_contact_no",type="string",  description="联系号码", required=true),
     *   @SWG\Parameter(in="formData", name="Wed_fri",type="string",  description="周一到周五营业时间（09:00:00 - 20:00:00）", required=true),
     *   @SWG\Parameter(in="formData", name="Sat_Sun",type="string",  description="周末营业时间（09:00:00 - 20:00:00）", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="200", description=""),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function edit(Request $request)
    {
        $merchantRep = app(MerchantRepository::class);

        $data['merchant_uen']                        = $request->input('merchant_uen');
        $data['merchant_contact_name']               = $request->input('merchant_contact_name');
        $data['merchant_contact_no']                 = $request->input('merchant_contact_no');
        $data['merchant_operation_hours']['Wed_fri'] = $request->input('Wed_fri');
        $data['merchant_operation_hours']['Sat_Sun'] = $request->input('Sat_Sun');

        $merchantId = auth('merchant')->user()->merchant_id;
        $fileRepository = app(FileRepository::class);
        if ($request->file('merchant_logo')){
            $data['merchant_logo'] = $fileRepository->imageReSize( request()->file('merchant_logo'),generateFilePath());
        }
        $res = $merchantRep->edit($data,$merchantId);

        if ($res['error']) {
            $code = empty($res['code']) ? 403 : $res['code'];

            return apiReturn([], $code, $res['msg']);
        }

        return apiReturn($res['data']);
    }
}