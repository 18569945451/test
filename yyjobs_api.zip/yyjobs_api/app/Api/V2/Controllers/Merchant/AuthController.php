<?php

namespace App\Api\V2\Controllers\Merchant;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Api\V2\Repositories\MerchantRepository;
use App\Api\V2\Repositories\MerchantApplyRepository;
use Tymon\JWTAuth\JWTAuth;

class AuthController extends Controller
{
    /**
     * @SWG\Post(path="/index.php/api/merchant/auth/apply",
     *   tags={"merchant/auth"},
     *   summary="申请",
     *   description="申请",
     *   operationId="apply",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="apply_name",type="string",  description="商户名称", required=true),
     *   @SWG\Parameter(in="formData",  name="apply_uen",type="string",  description="UEN号码", required=true),
     *   @SWG\Parameter(in="formData",  name="apply_contact_name",type="string",  description="联系人", required=true),
     *   @SWG\Parameter(in="formData",  name="apply_contact_no",type="string",  description="联系号码", required=true),
     *   @SWG\Parameter(in="formData",  name="apply_remark",type="string",  description="备注", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function apply(Request $request)
    {
        $applyRep = app(MerchantApplyRepository::class);
        $res = $applyRep->apply($request->all());
        if ($res['error']){
            $code = empty($res['code']) ? 403 : $res['code'];
            return apiReturn([], $code, $res['msg']);
        }
        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/merchant/auth/login",
     *   tags={"merchant/auth"},
     *   summary="登录",
     *   description="登录",
     *   operationId="login",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="merchant_no",type="string",  description="商户编号", required=false),
     *   @SWG\Parameter(in="formData",  name="merchant_uen",type="string",  description="UEN号码", required=true),
     *   @SWG\Parameter(in="formData",  name="merchant_password",type="string",  description="密码", required=true),
     *   @SWG\Parameter(in="formData",  name="registration_id",type="string",  description="设备id", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function login(Request $request)
    {
        $merchantRep = app(MerchantRepository::class);
        $res = $merchantRep->signIn($request->all());
        if ($res['error']){
            $code = empty($res['code']) ? 403 : $res['code'];
            return apiReturn([], $code, $res['msg']);
        }
        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/merchant/auth/password/reset",
     *   tags={"merchant/auth"},
     *   summary="重置密码",
     *   description="重置密码",
     *   operationId="reset",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="cur_password",type="string",  description="当前密码", required=false),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="新密码", required=true),
     *   @SWG\Parameter(in="formData",  name="password_confirmation",type="string",  description="确认密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function reset(Request $request)
    {
        $merchantRep = app(MerchantRepository::class);
        $merchantId = auth('merchant')->user()->merchant_id;
        $res = $merchantRep->resetPassword($request->all(),$merchantId);
        if ($res['error']){
            $code = empty($res['code']) ? 403 : $res['code'];
            return apiReturn([], $code, $res['msg']);
        }
        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/merchant/auth/password/forget/email",
     *   tags={"merchant/auth"},
     *   summary="忘记密码发送验证码邮件",
     *   description="忘记密码发送验证码邮件",
     *   operationId="password/forget/email",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="merchant_email",type="string",  description="雇主邮箱", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function forgetPasswordBySendMail(Request $request)
    {
        $merchantRep = app(MerchantRepository::class);
        $res = $merchantRep->forgetPasswordBySendMail($request->all());
        if ($res['error']){
            $code = empty($res['code']) ? 403 : $res['code'];
            return apiReturn([], $code, $res['msg']);
        }
        return apiReturn([]);
    }

    /**
     * @SWG\Post(path="/index.php/api/merchant/auth/password/forget",
     *   tags={"merchant/auth"},
     *   summary="忘记密码",
     *   description="忘记密码",
     *   operationId="password/forget",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="merchant_email",type="string",  description="雇主邮箱", required=true),
     *   @SWG\Parameter(in="formData",  name="code",type="string",  description="验证码", required=true),
     *   @SWG\Parameter(in="formData",  name="password",type="string",  description="新密码", required=true),
     *   @SWG\Parameter(in="formData",  name="password_confirmation",type="string",  description="确认新密码", required=true),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function forgetPassword(Request $request)
    {
        $merchantRep = app(MerchantRepository::class);
        $res = $merchantRep->forgetPassword($request->all());
        if ($res['error']){
            $code = empty($res['code']) ? 403 : $res['code'];
            return apiReturn([], $code, $res['msg']);
        }
        return apiReturn($res['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/merchant/auth/registration",
     *   tags={"merchant/auth"},
     *   summary="设备ID更新",
     *   description="设备ID更新",
     *   operationId="registration/remove",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="formData",  name="registration_id",type="string",  description="极光设备id", required=false),
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function registration(Request $request)
    {
        $infoRep = app(MerchantRepository::class);

        $registrationId = $request->input('registration_id', '');
        $merchantId       = auth('merchant')->user()->merchant_id;
        $info           = $infoRep->registration($merchantId, $registrationId);
        if ($info['error']) {
            return apiReturn([], 403, $info['msg']);
        }

        return apiReturn($info['data']);
    }

    /**
     * @SWG\Post(path="/index.php/api/merchant/auth/refresh/token",
     *   tags={"merchant/auth"},
     *   summary="刷新Token",
     *   description="刷新Token",
     *   operationId="auth/refresh/token",
     *   consumes={"application/x-www-form-urlencoded"},
     *   @SWG\Parameter(in="header",  name="Content-Type",  type="string",  description="application/x-www-form-urlencoded", default="application/x-www-form-urlencoded",required=true),
     *   @SWG\Parameter(in="header",  name="Accept",  type="string",  description="版本号", default="application/x.yyjobs-api.v2+json",required=true),
     *   @SWG\Parameter(in="header",  name="Authorization",  type="string",  description="Token 前面需要加：'bearer '",required=true),
     *   @SWG\Response(response="403", description="无权限"),
     *   @SWG\Response(response="500", description=""),
     * )
     */
    public function refreshToken()
    {
        $merchant = auth('merchant')->user();
        $jwt = app(JWTAuth::class);
        $data['merchant_id'] = $merchant->merchant_id;
        //$data['token'] = auth('merchant')->refresh(false,true);
        $data['token'] = $jwt->fromUser($merchant);
        return apiReturn($data);
    }
}