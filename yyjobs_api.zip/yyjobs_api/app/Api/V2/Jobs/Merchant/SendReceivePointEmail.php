<?php

namespace App\Api\V2\Jobs\Merchant;

use App\Models\Member;
use App\Models\Merchant;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Api\V2\Mail\Merchant\SendReceivePointEmail as ReceivePointEmail;
class SendReceivePointEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $pointLog;

    /**
     * SendOTPCodeEmail constructor.
     *
     * @param $pointLog
     */
    public function __construct($pointLog)
    {
        $this->pointLog = $pointLog;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $data = $this->getDetail($this->pointLog['member_id'],$this->pointLog['merchant_id']);
        \Mail::to($data['merchant_email'])->send(new ReceivePointEmail($data));
    }

    /**
     * @param $memberId
     * @param $merchantId
     *
     * @return array
     */
    private function getDetail($memberId, $merchantId)
    {
        $member   = Member::find($memberId, ['member_name']);
        $merchant = Merchant::find($merchantId, ['merchant_name', 'merchant_email']);

        return [
            'member_name'    => $member->member_name,
            'merchant_name'  => $merchant->merchant_name,
            'merchant_email' => $merchant->merchant_email,
            'points'         => $this->pointLog['change_value'],
            'log_time'       => $this->pointLog['log_time'],
        ];
    }


}
