<?php

namespace App\Api\V2\Repositories;

use Hash;
use Validator;
use App\Models\Member;
use Prettus\Repository\Eloquent\BaseRepository;

class MemberRepository extends BaseRepository
{

    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Member::class;
    }

    /**
     * 登录
     * @param $request
     *
     * @return array
     */
    public function signIn($request)
    {
        $valid = $this->valid($request,'login');
        if ($valid->fails()) {
            return ['error' => 1, 'msg' => 'Parameter error.'];
        }

        $merchant = $this->findWhere(['merchant_uen'=>$request['merchant_uen']])->first();

        if ($request['merchant_password'] && !Hash::check($request['merchant_password'], $merchant->merchant_password)) {
            return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
        }

        //更新设备id
        if ($request['registration_id']){
            $this->updateRegistration($request['registration_id'],$merchant->merchant_id);
        }

        if($token = auth()->guard('merchant')->attempt(['merchant_id'=>$merchant->merchant_id])){
            return ['error' => 0, 'data'=>['merchant_id'=>$merchant->merchant_id,'token'=>$token],'msg' => 'Login successful'];
        }

    }

    /**
     * 邀请码页面
     * @param $memberId
     *
     * @return array
     */
    public function inviteCode($memberId)
    {
        $member = $this->find($memberId);
        if ( ! $member->member_invite_code) {
            $code = strtoupper(uniqid());
            $this->update(['member_invite_code' => $code], $memberId);
            return ['error'=>0,'data'=>['invite_code'=>$code,'invite_total'=>0,'invite_success'=>0,'invite_point'=>0]];
        }
        $memberInviteRep = app(MemberInviteRepository::class);
        $memberInvite = $memberInviteRep->getInviteCount($memberId);

        return [
            'error' => 0,
            'data'  => [
                'invite_code'    => $member->member_invite_code,
                'invite_total'   => $memberInvite['total'],
                'invite_success' => $memberInvite['success'],
                'invite_point'   => $memberInvite['point'],
            ],
        ];
    }
}