<?php

namespace App\Api\V2\Repositories;

use App\Traits\Admin\Jpush;
use DB;
use App\Models\MemberInvite;
use Prettus\Repository\Eloquent\BaseRepository;

class MemberInviteRepository extends BaseRepository
{
    use Jpush;
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return MemberInvite::class;
    }

    /**
     * 添加邀请关系
     * @param string    $inviteCode       邀请码
     * @param object    $inviteeMember    被邀请人
     * @return bool|array
     */
    public function invite($inviteCode,$inviteeMember)
    {
        $memberRep = app(MemberRepository::class);
        $interMember = $memberRep->model->where('member_invite_code',$inviteCode)->first(['member_id']);
        if ($interMember){
            $inviteData['inviter_member_id'] = $interMember->member_id;
            $inviteData['invitee_member_id'] = $inviteeMember->member_id;
            $inviteData['point'] = 0;
            $inviteData['status'] = 1;
            $inviteData['add_time'] = time();
            //notify 邀请的朋友成功加入
            $notifyRep = app(MemberNotificationsRepository::class);
            $data = $notifyRep->saveNotifyForInviteFriend($interMember->member_id,$inviteeMember);
            $registrationIds = $this->getRegistrationIdsFromMember([$interMember->member_id]);
            if ($registrationIds){
                $this->notifyForInviteFriend($data,$registrationIds);
            }
            return $this->create($inviteData);
        }
        return false;
    }

    /**
     * 获取邀请情况
     * @param $memberId
     *
     * @return mixed
     */
    public function getInviteCount($memberId)
    {
        $res = DB::table('member_invite')->where('inviter_member_id', $memberId)->select(
            DB::raw('count(*) as total,sum(point) as point')
        )->first();

        $success = $this->model->where(['inviter_member_id' => $memberId, 'status' => 2])->count();

        $data['total'] = $res->total ?? 0;
        $data['point'] = $res->point ?? 0;
        $data['success'] = $success ?? 0;

        return $data;
    }

    /**
     * 邀请人的列表
     * @param $memberId
     * @param $status
     * @param $curPage
     * @param $pageSize
     *
     * @return array
     */
    public function inviteList($memberId,$status,$curPage,$pageSize)
    {
        //开始位置
        $offset = ($curPage - 1) * $pageSize;

        //固定条件
        $this->model = $this->model->leftJoin('member as m', 'member_invite.invitee_member_id', 'm.member_id')
            ->where('member_invite.inviter_member_id',$memberId);

        //状态
        if ($status){
            $this->model = $this->model->where('member_invite.status',$status);
        }

        //总数
        $count = $this->model->count();

        //总页数
        $countPage = ceil($count / $pageSize);

        //列表数据
        $list = $this->model->offset($offset)->limit($pageSize)->orderBy('member_invite.add_time', 'desc')->get(
            ['member_invite.id as member_invite_id','m.member_id','m.member_name','m.member_avatar','member_invite.status','member_invite.add_time']
        )->toArray();

        //格式化
        if ($list){
            foreach ($list as $key=>$value) {
                $list[$key]['member_avatar'] = $value['member_avatar'] ? $value['member_avatar'] : '';
            }
        }

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'list'),
        ];
    }

}