<?php

namespace App\Api\V2\Repositories;

use App\Models\Slider;
use Prettus\Repository\Eloquent\BaseRepository;

class SliderRepository extends BaseRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Slider::class;
    }

    public function getSlider()
    {
        $slider = $this->model->where('status',1)->orderBy('sort','asc')->limit(6)->get();
        $data = [];
        foreach ($slider as $key=>$value) {
            $data[$key]['id'] = $value->id;
            $data[$key]['title'] = $value->title;
            $data[$key]['image'] = $value->image;
            $data[$key]['type'] = $value->type;
            if ($value->type == 1){
                $data[$key]['href'] = $value->href;
            }else{
                $data[$key]['job_id'] = $value->job_id;
            }
        }
        return [
            'error' => 0,
            'data'  => $data
        ];
    }

}