<?php

namespace App\Api\V2\Repositories;

use App\Traits\Admin\Jpush;
use DB;
use Hash;
use Validator;
use App\Models\MemberPointLog;
use Prettus\Repository\Eloquent\BaseRepository;

class MemberPointRepository extends BaseRepository
{
    use Jpush;
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return MemberPointLog::class;
    }

    public function search($by, $startTimestamps, $endTimestamps,$keyword, $memberId)
    {
        //没有传时间默认去最近有记录的一条数据的月份
        if (!$startTimestamps && !$endTimestamps){
            $firstData = $this->model->where('member_id',$memberId)->orderBy('log_time','desc')->first();
            if (!$firstData){
                return ['error' => 0, 'data'  => []];
            }
            $startTimestamps = strtotime(date('Y-m',$firstData->log_time));
            $endTimestamps = date(strtotime("+1 months", $startTimestamps));
        }elseif ($startTimestamps && !$endTimestamps){
            $endTimestamps = date(strtotime("+1 months", $startTimestamps));
        }

        //固定条件
        $this->model = $this->model->leftJoin('job as j', 'member_point_log.job_id', 'j.job_id')
            ->leftJoin('merchant as mt', 'member_point_log.merchant_id', 'mt.merchant_id')
            ->leftJoin('member as m', 'member_point_log.invitee_id', 'm.member_id')
            ->where('member_point_log.member_id', $memberId);


        //关键字
        if ($keyword){
            $this->model = $this->model->
            where(function($query)use($keyword){
                return $query->where('j.job_title', 'like', "%{$keyword}%")
                    ->orWhere('mt.merchant_name', 'like', "%{$keyword}%");
            });
        }else{
            $this->model = $this->model
                ->where('member_point_log.log_time','>',$startTimestamps)
                ->where('member_point_log.log_time','<',$endTimestamps);
        }

        //数据
        $list = $this->model->orderBy('member_point_log.log_time','desc')->get(
            ['member_point_log.id as log_id','member_point_log.change_type','member_point_log.change_value','member_point_log.log_time', 'j.job_title','j.job_image','mt.merchant_name','mt.merchant_logo','m.member_name as invitee_name','m.member_avatar as invitee_avatar']
        )->toArray();

        $data = [];
        foreach ($list as $key => $value) {
            foreach ($value as $vk=>$vv) {
                if ($vv == null){
                    $value[$vk] = '';
                }
            }
            $value['change_value']        = sprintf('%.2f', $value['change_value']);
            $newKey                       = date('Y-m', $value['log_time']);
            $data[$newKey]['date']        = $newKey;
            $data[$newKey]['date_format'] = date('M Y', $value['log_time']);;
            $data[$newKey]['expense'] = 0;
            $data[$newKey]['income']  = 0;
            $data[$newKey]['list'][]  = $value;
        }


        foreach ($data as $dk => $v) {
            foreach ($v['list'] as $lk=>$lv) {
                if($lv['change_value'] <= 0){
                    $data[$dk]['expense'] += abs($lv['change_value']);
                }else{
                    $data[$dk]['income'] += abs($lv['change_value']);
                }
            }
        }

        rsort($data);

        return [
            'error' => 0,
            'data'  => $data,
        ];
    }

    public function search_bak2($by, $startTimestamps, $endTimestamps,$keyword, $memberId)
    {
        //固定条件
        $this->model = $this->model->leftJoin('job as j', 'member_point_log.job_id', 'j.job_id')
            ->leftJoin('merchant as mt', 'member_point_log.merchant_id', 'mt.merchant_id')
            ->leftJoin('member as m', 'member_point_log.member_id', 'm.member_id')
            ->where('member_point_log.member_id', $memberId)
            ->where('member_point_log.log_time','>',$startTimestamps)
            ->where('member_point_log.log_time','<',$endTimestamps);

        //关键字
        if ($keyword) {
            $this->model = $this->model->where('j.job_title', 'like', "%{$keyword}%")
                ->orWhere('mt.merchant_name', 'like', "%{$keyword}%");
        }

        //数据
        $list = $this->model->orderBy('member_point_log.log_time','desc')->get(
            ['member_point_log.id as log_id','member_point_log.change_type','member_point_log.change_value','member_point_log.log_time', 'j.job_title','j.job_image','mt.merchant_name','mt.merchant_logo']
        )->toArray();

        $data = [];
        foreach ($list as $key => $value) {
            foreach ($value as $vk=>$vv) {
                if ($vv == null){
                    $value[$vk] = '';
                }
            }
            $value['change_value'] = sprintf('%.2f',$value['change_value']);
            $newKey = date('Ym', $value['log_time']);
            $data[$newKey]['date']    = date('Ym', $value['log_time']);
            $data[$newKey]['expense'] = 0;
            $data[$newKey]['income']  = 0;
            $data[$newKey]['list'][]  = $value;
        }

        foreach ($data as $dk => $v) {
            foreach ($v['list'] as $lk=>$lv) {
                if($lv['change_value'] <= 0){
                    $data[$dk]['expense'] += abs($lv['change_value']);
                }else{
                    $data[$dk]['income'] += abs($lv['change_value']);
                }
            }
        }

        rsort($data);

        return [
            'error' => 0,
            'data'  => $data,
        ];
    }

    public function pay($memberId, $merchantId, $money, $paymentPassword)
    {
        $valid = Validator::make(
            ['member_id' => $memberId, 'merchant_id' => $merchantId, 'money' => $money, 'member_payment_password' => $paymentPassword],
            ['member_id' => 'required', 'merchant_id' => 'required', 'money' => 'required|numeric|min:0.01|regex:/^\d*(\.\d{1,2})?$/', 'member_payment_password' => 'required|numeric|digits:6']
        );

        //验证参数
        if ($valid->fails()) {
            return ['error' => 1, 'msg' => 'Parameter error,'.$valid->errors()->all()[0]];
        }

        $memberRep = app(MemberRepository::class);
        $member = $memberRep->find($memberId);

        //未设置支付密码
        if (!$member->member_payment_password){
            return ['error'=>1,'msg'=>'You have not set a payment password. Please set a payment password before paying.'];
        }

        //验证支付密码
        if (!$this->validPaymentPassword($paymentPassword,$member->member_payment_password)){
            return ['error'=>1,'msg'=>'Incorrect payment password.','code'=>411];
        }
        
        //验证积分是否足够（1:100）
        if ($member->member_point < $money * 100) {
            return ['error'=>1,'msg'=>'Your points are not enough for this payment. Go and finish more work to earn points.'];
        }
        
        //验证积分是否存在异常
        if (!$this->validPointLegal($memberId,$member->member_point)){
            return ['error'=>1,'msg'=>'There is an abnormality in your points that cannot be paid for this time. Please contact customer service.'];
        }

        //进行事务操作
        if (!$data = $this->consume($memberId,$merchantId,$money)){
            return ['error'=>1,'msg'=>'Server Error.'];
        }

        return ['error' => 0, 'data' => $data];

    }

    /**
     * 验证支付密码
     * @param $requestPassword
     * @param $paymentPassword
     *
     * @return bool
     */
    private function validPaymentPassword($requestPassword,$paymentPassword)
    {
        if ($requestPassword && !Hash::check($requestPassword, $paymentPassword)) {
            return false;
        }
        return true;
    }

    /**
     * 验证积分是否存在异常
     * @param      $memberId
     * @param bool $currentPoint
     *
     * @return bool
     */
    private function validPointLegal($memberId, $currentPoint = false)
    {
        if ( ! $currentPoint) {
            $memberRep    = app(MemberRepository::class);
            $member       = $memberRep->find($memberId, ['member_point']);
            $currentPoint = $member->member_point;
        }

        $validPoint = $this->model->where('member_id', $memberId)->sum('change_value');

        if ($currentPoint != $validPoint) {
            return false;
        }

        return true;
    }

    /**
     * @param $by
     * @param $date
     *
     * @return array
     */
    private function formatDateTime($by, $date)
    {
        $dateTimestamps = [];
        if ($by == 'year') {
            $dateTimestamps['start'] = strtotime($date.'-01');
            $dateTimestamps['end']   = strtotime(($date + 1).'-01');
        }
        if ($by == 'month') {
            $year                    = substr($date, 0, 4);
            $month                   = substr($date, 4, 2);
            $dateTimestamps['start'] = strtotime($year.'-'.$month);
            if ($month >= 12) {
                $dateTimestamps['end'] = strtotime(($year + 1).'-01');
            } else {
                $dateTimestamps['end'] = strtotime($year.'-'.($month + 1));
            }
        }

        return $dateTimestamps;
    }

    public function search_bak($curPage, $pageSize, $startTime, $endTime, $memberId,$keyword)
    {
        //开始位置
        $offset = ($curPage - 1) * $pageSize;

        //固定条件
        $this->model = $this->model->leftJoin('job as j', 'member_point_log.job_id', 'j.job_id')
            ->leftJoin('merchant as mt', 'member_point_log.merchant_id', 'mt.merchant_id')
            ->leftJoin('member as m', 'member_point_log.member_id', 'm.member_id')
            ->where('member_point_log.member_id', $memberId)
            ->where('member_point_log.log_time','>',$startTime)
            ->where('member_point_log.log_time','<',$endTime);

        //关键字
        if ($keyword) {
            $this->model = $this->model->where('j.job_title', 'like', "%{$keyword}%")
                ->orWhere('mt.merchant_name', 'like', "%{$keyword}%");
        }

        //总数
        $count = $this->model->count();

        //总页数
        $countPage = ceil($count / $pageSize);

        //列表数据
        $list = $this->model->offset($offset)->limit($pageSize)->orderBy('member_point_log.log_time', 'desc')->get(
            ['member_point_log.id as log_id','member_point_log.change_type','member_point_log.change_value','member_point_log.log_time', 'j.job_title','j.job_image','mt.merchant_name','mt.merchant_logo']
        )->toArray();

        //格式化
        if ($list){
            foreach ($list as $key=>$value) {
                $list[$key]['merchant_name'] = $value['merchant_name'] ? $value['merchant_name'] : '';
                $list[$key]['merchant_logo'] = $value['merchant_logo'] ? $value['merchant_logo'] : '';
                $list[$key]['job_title'] = $value['job_title'] ? $value['job_title'] : '';
                $list[$key]['job_image'] = $value['job_image'] ? $value['job_image'] : '';
            }
        }

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'list'),
        ];
    }

    /**
     * 用户消费
     * \App\Api\V2\Repositories\MerchantPointRepository::receive
     *
     * @param $memberId
     * @param $merchantId
     * @param $money
     *
     * @return bool
     */
    public function consume($memberId, $merchantId, $money)
    {
        $memberRep = app(MemberRepository::class);
        $member    = $memberRep->find($memberId, ['member_id','member_name','member_point']);

        $memberPointData['member_id']         = $memberId;
        $memberPointData['change_type']       = 2;
        $memberPointData['change_pre_point']  = $member->member_point;
        $memberPointData['change_next_point'] = $member->member_point - ($money * 100);
        $memberPointData['change_value']      = $money * 100 * -1;
        $memberPointData['job_id']            = 0;
        $memberPointData['merchant_id']       = $merchantId;
        $memberPointData['log_desc']          = 'Consume';
        $memberPointData['log_time']          = time();
        
        DB::beginTransaction();
        if ( ! $this->create($memberPointData)) {
            DB::rollBack();

            return false;
        }

        $memberPoint = $memberRep->update(
            ['member_point' => $member->member_point - ($money * 100)],
            $memberId
        );

        if ($memberPoint === false) {
            DB::rollBack();

            return false;
        }

        $merchantPointRep = app(MerchantPointRepository::class);
        $receive = $merchantPointRep->receive($memberId, $merchantId, $money);
        if ($receive === false) {
            DB::rollBack();

            return false;
        }

        DB::commit();

        //notify 商户收到支付的积分
        $notifyRep = app(MerchantNotificationsRepository::class);
        $merchantRep = app(MerchantRepository::class);
        $merchant = $merchantRep->find($merchantId);
        $data = $notifyRep->saveNotifyForTransactionSuccess($merchant,$member,$money);
        $registrationIds = $this->getRegistrationIdsFromMerchant([$merchantId]);
        if ($registrationIds){
            $this->notifyForTransactionSuccess($data,$registrationIds);
        }

        return $memberPointData;
    }

}