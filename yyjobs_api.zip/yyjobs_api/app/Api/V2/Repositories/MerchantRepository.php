<?php

namespace App\Api\V2\Repositories;

use App\Mail\MerchantForgetPassword;
use Hash;
use Validator;
use Illuminate\Validation\Rule;
use App\Models\Merchant;
use Prettus\Repository\Eloquent\BaseRepository;

class MerchantRepository extends BaseRepository
{

    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Merchant::class;
    }

    public function index($merchantId)
    {
        $pointRep = app(MerchantPointRepository::class);
        $merchant = $this->find($merchantId)->toArray();
        foreach ($merchant as $key=>$value) {
            if ($merchant[$key] === null){
                $merchant[$key] = '';
            }
        }
        $data['merchant'] = $merchant;
        $data['recent'] = $pointRep->recent($merchantId)['data'];

        return ['error'=>0,'data'=>$data];
    }

    /**
     * 申请注册
     * @param $request
     *
     * @return array
     */
    public function signUp($request)
    {
        $valid = $this->valid($request,'register');
        if ($valid->fails()) {
            return ['error' => 1, 'msg' => 'Parameter error.'];
        }

        $exist = $this->isExist($request);
        if ($exist->fails()) {
            return ['error' => 1, 'msg' => 'This information has been registered.'];
        }
        $request['merchant_password']     = bcrypt('123456');
        $request['merchant_mobile']       = '';
        $request['merchant_apply_status'] = 0;
        $request['merchant_add_time']     = time();

        if ($merchant = $this->create($request)) {
            return [
                'error' => 0,
                'data'  => $merchant,
                'msg'   => 'The application is successful, please wait for the administrator to review.',
            ];
        }

        return ['error' => 1, 'msg' => 'Service error', 'code' => 500];
    }

    /**
     * 登录
     * @param $request
     *
     * @return array
     */
    public function signIn($request)
    {
        $valid = $this->valid($request,'login');
        if ($valid->fails()) {
            return ['error' => 1, 'msg' => 'Parameter error.'];
        }

        $merchantCount = ($this->makeModel())->where(['merchant_uen'=>$request['merchant_uen']])->count();
        
        if ($merchantCount > 1 && empty($request['merchant_no'])){
            return ['error' => 1, 'msg' => 'You must fill in your merchant No.'];
        }elseif($merchantCount > 1 && !empty($request['merchant_no'])){
            $merchant = $this->findWhere(['merchant_uen'=>$request['merchant_uen'],'merchant_custom_id'=>$request['merchant_no']])->first();
        }else{
            $merchant = $this->findWhere(['merchant_uen'=>$request['merchant_uen']])->first();
        }

        if (!$merchant){
            return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
        }

        if ($request['merchant_password'] && !Hash::check($request['merchant_password'], $merchant->merchant_password)) {
            return ['error' => 1, 'msg' => 'Please check your credentials or sign up.'];
        }

        //更新设备id
        if ($request['registration_id']){
            $this->updateRegistration($request['registration_id'],$merchant->merchant_id);
        }
        //更新设备id
        $this->updateMerchantRegistration($request['registration_id'],$merchant->merchant_id);

        if($token = auth()->guard('merchant')->attempt(['merchant_id'=>$merchant->merchant_id])){
            return ['error' => 0, 'data'=>['merchant_id'=>$merchant->merchant_id,'token'=>$token],'msg' => 'Login successful'];
        }
    }

    public function resetPassword($request, $merchantId)
    {
        $valid = $this->valid($request,'reset-password');
        if ($valid->fails()) {
            return ['error' => 1, 'msg' => $valid->errors()->all()[0]];
        }

        $merchant = $this->findWhere(['merchant_id'=>$merchantId])->first();

        if (!Hash::check($request['cur_password'], $merchant->merchant_password)) {
            return ['error' => 1, 'msg' => 'The current password is incorrect.'];
        }

        if($this->update(['merchant_password'=>bcrypt($request['password'])],$merchantId)){
            return ['error' => 0, 'data'=>['merchant_id'=>$merchantId]];
        }

        return ['error' => 1, 'msg' => 'Server Error.'];
    }

    /**
     * 是否存在
     * @param $request
     *
     * @return mixed
     */
    private function isExist($request)
    {
        return Validator::make(
            $request,
            [
                'merchant_uen'        => 'unique:merchant',
                'merchant_name'       => 'unique:merchant',
                'merchant_contact_no' => 'unique:merchant',
            ]
        );
    }

    private function valid($request,$type)
    {
        switch ($type){
            case 'register':
                return Validator::make($request, ['merchant_uen' => 'required', 'merchant_name' => 'required', 'merchant_contact_no' => 'required',]);
                break;
            case 'login':
                return Validator::make($request, ['merchant_uen' => 'required', 'merchant_password' => 'required']);
                break;
            case 'reset-password':
                return Validator::make($request, ['cur_password' => 'required', 'password' => 'required|min:8|max:32|confirmed','password_confirmation'=>'required|min:8|max:32']);
                break;
        }
    }

    private function updateRegistration($registrationId,$merchantId)
    {
        $registrationForMerchant = $this->findWhere(['registration_id'=>$registrationId])->first();
        if (isset($registrationForMerchant->merchant_id) && $registrationForMerchant->merchant_id != $merchantId){
            $this->update(['registration_id'=>''],$registrationForMerchant->merchant_id);
        }
        $this->update(['registration_id'=>$registrationId],$merchantId);
    }

    /**
     * @param        $curPage
     * @param        $pageSize
     * @param        $memberId
     * @param string $keyword
     * @param string $latitude
     * @param string $longitude
     *
     * @return array
     */
    public function search($type,$curPage, $pageSize, $memberId,$keyword = '',$latitude = '',$longitude = '')
    {
        //开始位置
        $offset = ($curPage - 1) * $pageSize;

        //计算距离的
        $distanceSql = "ROUND( 6378.138 * 2 * asin( sqrt( cos( {$latitude} * 3.1415926 / 180 ) * cos( m.merchant_latitude * 3.1415926 / 180 ) * pow( sin( ( {$longitude} * 3.1415926 / 180 - m.merchant_longitude * 3.1415926 / 180 ) / 2 ), 2 ) + pow( sin( ( {$latitude} * 3.1415926 / 180 - m.merchant_latitude * 3.1415926 / 180 ) / 2 ), 2 ) ) ), 5 ) * 1000 AS meter";

        //按查找类型拼接（list：所有 ，favorite：喜欢，nearby：附近）
        $sql = '';
        switch ($type) {
            case 'list':
            case 'nearby':
                $sql .= "SELECT %s FROM (SELECT m.merchant_id, m.merchant_name, m.merchant_operation_hours, m.merchant_logo, mc.c_name AS class_name,mc.c_icon AS class_icon, mc.c_icon_invert AS class_icon_invert, f.id AS favorite, m.merchant_latitude, m.merchant_longitude,{$distanceSql} FROM merchant AS m LEFT JOIN merchant_class AS mc ON m.merchant_class_id = mc.c_id LEFT JOIN favorite AS f ON m.merchant_id = f.merchant_id AND f.member_id={$memberId}";
                break;
            case 'favorite':
                $sql .= "SELECT %s FROM (SELECT m.merchant_id, m.merchant_name, m.merchant_operation_hours, m.merchant_logo, mc.c_name AS class_name,mc.c_icon AS class_icon, mc.c_icon_invert AS class_icon_invert, f.id AS favorite, m.merchant_latitude, m.merchant_longitude,{$distanceSql} FROM merchant AS m INNER JOIN merchant_class AS mc ON m.merchant_class_id = mc.c_id INNER JOIN favorite AS f ON m.merchant_id = f.merchant_id AND f.member_id={$memberId}";
                break;
        }

        //按会员查找
        $sql .= " WHERE f.member_id = {$memberId} OR f.id IS NULL) as a ";

        //按关键字查找
        if ($keyword){
            $sql .= " WHERE merchant_name LIKE '%%{$keyword}%%'";
            if ($type == 'nearby'){
                $sql .= " AND meter<1000";
            }
        }

        //默认只显示附加1000米的商户
        if ($type == 'nearby'){
            $sql .= " WHERE meter<1000";
        }


        //总条数
        $countSql = sprintf($sql,'count(*) as total');
        $countNum = \DB::select($countSql);
        $count = $countNum[0]->total;

        //总页数
        $countPage = ceil($count / $pageSize);

        //分页
        $sql .= " ORDER BY meter asc LIMIT {$offset},{$pageSize}";

        //列表数据
        $listSql = sprintf($sql,' * ');

        $list = \DB::select($listSql);

        if ($count > 0){
            foreach ($list as $key=>$value) {
                $operationHours = $this->operationHours($value->merchant_operation_hours);
                $list[$key]->merchant_operation_hours = $operationHours['format'];
                $list[$key]->open = $operationHours['open'];
                $list[$key]->favorite = $value->favorite ? 1 : 0;
                $list[$key]->meter = $value->meter ? round($value->meter,2) : 0;
            }
        }

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'list'),
        ];
    }

    /**
     * @param $data
     * @param $merchantId
     *
     * @return array
     */
    public function edit($data, $merchantId)
    {
        $data['merchant_operation_hours'] = json_encode($data['merchant_operation_hours']);
        $res = $this->update($data,$merchantId);
        if ($res !== false){
            return ['error'=>0,'data'=>$this->find($merchantId)];
        }
        return ['error'=>1,'msg'=>'Server Error.'];
    }

    /**
     * @param $merchantId
     *
     * @return array
     */
    public function detail($merchantId)
    {
        $data = $this->model->leftJoin('merchant_class as mc', 'merchant.merchant_class_id', 'mc.c_id')
            ->where('merchant.merchant_id', $merchantId)->first(
                ['merchant.merchant_id', 'merchant.merchant_uen', 'merchant.merchant_class_id', 'mc.c_name as merchant_class_name', 'mc.c_icon as merchant_class_icon', 'mc.c_icon_invert as merchant_class_icon_invert', 'merchant.merchant_name', 'merchant.merchant_contact_name', 'merchant.merchant_contact_no', 'merchant.merchant_logo', 'merchant.merchant_address', 'merchant.merchant_operation_hours', 'merchant.merchant_note', 'merchant.merchant_terms', 'merchant.merchant_brand_description', 'merchant.merchant_add_time', 'merchant.merchant_status', 'merchant.merchant_zip_code', 'merchant.merchant_latitude', 'merchant.merchant_longitude',]
            );
        $favRep = app(FavoriteRepository::class);
        $favorite = $favRep->search(1, 10, 1, 1830268800, $merchantId);

        $data['fav_count']                  = $favorite['data']['count'];
        $data['fav_list']                   = $favorite['data']['list'];
        $data['merchant_note']              = $data['merchant_note'] ?? '';
        $data['merchant_terms']             = $data['merchant_terms'] ?? '';
        $data['merchant_brand_description'] = $data['merchant_brand_description'] ?? '';
        //$data['merchant_operation_hours']   = json_decode($data['merchant_operation_hours']);
        $data['merchant_operation_hours']   = $this->operationHoursFormat($data['merchant_operation_hours']);

        return [
            'error' => 0,
            'data'  => $data,
        ];

    }

    /**
     * @param $operationHours
     *
     * @return array
     */
    public function operationHoursFormat($operationHours)
    {
        $format  = json_decode($operationHours);
        $Wed_fri = $this->operationHoursFilterSec($format->Wed_fri);
        $Sat_Sun = $this->operationHoursFilterSec($format->Sat_Sun);

        return compact('Wed_fri', 'Sat_Sun');

    }

    /**
     * @param $string
     *
     * @return string
     */
    private function operationHoursFilterSec($string)
    {
        $res  = explode('-', $string);
        $data = [];
        foreach ($res as $key => $item) {
            $data[$key] = substr(trim($item), 0, -3);
        }

        return implode(' - ', $data);
    }

    public function operationHours($operationHours)
    {
        $format        = json_decode($operationHours);
        $weekDay       = date('w');
        $operationTime = $weekDay <= 5 ? $format->Wed_fri : $format->Sat_Sun;

        $time      = explode('-', $operationTime);
        $startTime = strtotime(date('Y').'-'.date('m').'-'.date('d').' '.trim($time[0]));
        $endTime   = strtotime(date('Y').'-'.date('m').'-'.date('d').' '.trim($time[1]));

        $now = time();

        $open = ($now < $startTime || $now > $endTime) ? 0 : 1;

        return ['format' => date('H:i',$startTime).' - '.date('H:i',$endTime), 'open' => $open];
    }

    public function forgetPasswordBySendMail($request)
    {
        $valid = Validator::make(
            $request,
            ['merchant_email' => ['required', 'email', Rule::exists('merchant'),],]
        );

        if ($valid->fails()) {
            return ['error' => 1, 'msg' => $valid->errors()->all()[0]];
        }
        $code = substr(strtoupper(uniqid()), -6);

        cache()->forget($request['merchant_email']);
        cache()->put($request['merchant_email'], $code, 5);

        //todo 雇主重置密码的邮件目前发不了，待aws 邮件能发了就打开
        /*\Mail::send('tools.forget-password',['data' => ['code'=>$code]],function ($message)use($request){
            $message->from('wendy.wang@guadoutech.com', 'GuaDouTech');
            $message->to($request['merchant_email']);//固定发送给公司
            $message->subject('guadoutech website message');
        });*/
        \Mail::to($request['merchant_email'])->send(new MerchantForgetPassword(['code'=>$code]));
        /*try{
            \Mail::send(
                'tools.forget-password',
                ['data' => ['code'=>$code]],
                function ($message) use ($request) {
                    $message->from('wendy.wang@guadoutech.com', 'GuaDouTech');
                    $message->to($request['merchant_email']);
                    $message->subject('guadoutech website message');
                }
            );
        }catch (\Exception $e){
            return [
                'error' => 1,
                'code'=>500,
                'msg'  => $e->getMessage(),
            ];
        }*/

        return [
            'error' => 0,
            'data'=>['code'=>$code],
            'msg'=>'The verification code has been sent to your email, please check.'
        ];
    }


    public function forgetPassword($request)
    {
        $valid = Validator::make(
            $request,
            [
                'merchant_email' => ['required', 'email', Rule::exists('merchant'),],
                'code'=>'required|min:6|max:6',
                'password'=>'required|min:8|max:20|confirmed',
                'password_confirmation'=>'required|min:8|max:20',
            ]
        );

        if ($valid->fails()) {
            return ['error' => 1, 'msg' => $valid->errors()->all()[0]];
        }

        if ($request['code'] != cache($request['merchant_email'])){
            return ['error' => 1, 'msg' => 'Incorrect verification code.'];
        }

        $res = $this->model->where('merchant_email',$request['merchant_email'])->update(['merchant_password'=>bcrypt($request['password'])]);
        if ($res !== false){
            return ['error' => 0, 'data'=>$res];
        }

        return ['error' => 1, 'msg' => 'Server Error'];

    }

    private function updateMerchantRegistration($registrationId,$merchantId)
    {
        $registrationForMember = $this->findWhere(['registration_id'=>$registrationId])->first();
        if (isset($registrationForMember->merchant_id) && $registrationForMember->merchant_id != $merchantId){
            $this->update(['registration_id'=>''],$registrationForMember->merchant_id);
        }

        $this->update(['registration_id'=>$registrationId],$merchantId);
    }

    /**
     * 关闭接收通知（删除或添加设备id）
     * @param $memberId
     * @param $registrationId
     * @return array
     */
    public function registration($memberId,$registrationId)
    {
        if ($registrationId){
            $res = $this->updateMerchantRegistration($registrationId,$memberId);
        }else{
            $res = $this->update(['registration_id'=>''],$memberId);
        }

        if ($res !== false){
            return ['error' => 0,'data'=>[]];
        }

        return ['error' => 1, 'msg' => 'Server Error.'];
    }
}