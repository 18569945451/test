<?php

namespace App\Api\V2\Repositories;

use App\Models\MerchantWithdraw;
use Prettus\Repository\Eloquent\BaseRepository;

class MerchantWithdrawRepository extends BaseRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return MerchantWithdraw::class;
    }

    /**
     * 提现记录
     * @param $by
     * @param $curPage
     * @param $pageSize
     * @param $startDate
     * @param $endDate
     * @param $keyword
     * @param $merchantId
     *
     * @return array
     */
    public function withdrawList($by,$curPage,$pageSize,$startDate,$endDate,$keyword,$merchantId)
    {
        $offset = ($curPage - 1) * $pageSize;

        //固定条件
        $this->model = $this->model->where('merchant_id', $merchantId)
            ->where('add_time', '>', $startDate)
            ->where('add_time', '<', $endDate);

        //关键字
        if ($keyword) {
            $this->model = $this->model->where('value', 'like', "%{$keyword}%");
        }

        //总数
        $count = $this->model->count();

        //总页数
        $countPage = ceil($count / $pageSize);

        //数据
        $list = $this->model->offset($offset)->limit($pageSize)->orderBy('add_time', 'desc')->get()->toArray();

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'list'),
        ];

    }
}