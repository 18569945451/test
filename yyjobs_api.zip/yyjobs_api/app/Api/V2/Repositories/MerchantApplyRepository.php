<?php

namespace App\Api\V2\Repositories;

use Validator;
use App\Models\MerchantApply;
use Prettus\Repository\Eloquent\BaseRepository;

class MerchantApplyRepository extends BaseRepository
{

    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return MerchantApply::class;
    }

    /**
     * 申请
     *
     * @param $request
     *
     * @return array
     */
    public function apply($request)
    {
        $valid = $this->valid($request);
        if ($valid->fails()) {
            return ['error' => 1, 'msg' => 'Parameter error.'];
        }

        $exist = $this->isExist($request);
        if ($exist->fails()) {
            return ['error' => 1, 'msg' => 'This information has already been applied.'];
        }

        $request['apply_add_time'] = time();

        if ($apply = $this->create($request)) {
            return [
                'error' => 0,
                'data'  => $apply,
                'msg'   => 'The application is successful, please wait for the administrator to review.',
            ];
        }

        return ['error' => 1, 'msg' => 'Service error', 'code' => 500];
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    private function valid($request)
    {
        return Validator::make(
            $request,
            ['apply_uen' => 'required', 'apply_name' => 'required', 'apply_contact_no' => 'required',]
        );
    }

    /**
     * @param $request
     *
     * @return mixed
     */
    private function isExist($request)
    {
        return Validator::make(
            $request,
            [
                'apply_uen'        => 'unique:merchant_apply',
                'apply_name'       => 'unique:merchant_apply',
                'apply_contact_no' => 'unique:merchant_apply',
            ]
        );
    }
}