<?php

namespace App\Api\V2\Repositories;

use App\Models\Favorite;
use Prettus\Repository\Eloquent\BaseRepository;

class FavoriteRepository extends BaseRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Favorite::class;
    }


    public function favorite($memberId, $merchantId)
    {
        $res = $this->findWhere(['member_id'=>$memberId,'merchant_id'=>$merchantId])->first();
        if ($res){
            $this->delete($res->id);
            return ['error'=>0,'data'=>[],'msg'=>'Cancel like'];
        }else{
            $data = $this->create(['member_id'=>$memberId,'merchant_id'=>$merchantId,'add_time'=>time()]);
            return ['error'=>0,'data'=>$data];
        }
    }

    public function search($curPage, $pageSize, $startTime, $endTime,$merchantId)
    {
        //开始位置
        $offset = ($curPage - 1) * $pageSize;

        //固定条件
        $this->model = $this->model->join('member as m', 'favorite.member_id', 'm.member_id')
            ->where('favorite.merchant_id',$merchantId)
            ->where('favorite.add_time','>',$startTime)
            ->where('favorite.add_time','<',$endTime);

        //总数
        $count = $this->model->count();

        //总页数
        $countPage = ceil($count / $pageSize);

        //列表数据
        $list = $this->model->offset($offset)->limit($pageSize)->orderBy('favorite.add_time', 'desc')->get(
            ['favorite.id','m.member_id','m.member_name','m.member_avatar','favorite.add_time']
        )->toArray();

        //格式化
        if ($list){
            foreach ($list as $key=>$value) {
                $list[$key]['member_avatar'] = $value['member_avatar'] ? $value['member_avatar'] : '';
            }
        }

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'curPage', 'pageSize', 'list'),
        ];
    }


}