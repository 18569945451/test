<?php

namespace App\Api\V2\Repositories;

use App\Models\MerchantNotifications;
use Prettus\Repository\Eloquent\BaseRepository;

class MerchantNotificationsRepository extends BaseRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return MerchantNotifications::class;
    }

    public function search($curPage, $pageSize, $merchantId)
    {
        //开始位置
        $offset = ($curPage - 1) * $pageSize;

        //固定条件
        $this->model = $this->model->where('merchant_id',$merchantId);

        //总数
        $count = $this->model->count();

        //总页数
        $countPage = ceil($count / $pageSize);

        //列表数据
        $list = $this->model->offset($offset)->limit($pageSize)->orderBy('id', 'desc')->get();

        //未读数
        $unreadCount = ($this->model())::where('is_read',0)->where('merchant_id',$merchantId)->count();

        //格式化数据
        if ($list){
            foreach ($list as $key => $value) {
                if ($list[$key]['data']){
                    $list[$key]['data'] = json_decode($list[$key]['data'],true);
                }else{
                    unset($list[$key]['data']);
                }
            }
        }

        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'unreadCount','curPage', 'pageSize', 'list'),
        ];
    }

    /**
     * 删除通知
     * @param $msgId
     * @param $memberId
     *
     * @return array
     */
    public function remove($msgId, $memberId)
    {
        if ($msgId == 0){
            $this->model->where('merchant_id',$memberId)->delete();
            return ['error'=>0,'data'=>[]];
        }else{
            $this->model->where('merchant_id',$memberId)->where('id',$msgId)->delete();
            return ['error'=>0,'data'=>[]];
        }
    }

    /**
     * 已读通知
     * @param $msgId
     * @param $memberId
     *
     * @return array
     */
    public function read($msgId, $memberId)
    {
        if ($msgId == 0){
            $this->model->where('merchant_id',$memberId)->update(['is_read'=>1]);
            return ['error'=>0,'data'=>[]];
        }else{
            $this->model->where('merchant_id',$memberId)->where('id',$msgId)->update(['is_read'=>1]);
            return ['error'=>0,'data'=>[]];
        }
    }


    public function saveNotifyForTransactionSuccess($merchant, $member, $money)
    {
        $point = $money * 100;
        $data['type'] = 'transaction_success';
        $data['merchant_id'] = $merchant->merchant_id;
        $data['title'] = 'Transaction Successful!';
        $data['content'] = "Hello {$merchant->merchant_name}, {$member->member_name} has made a transaction of {$point} points at ".date('Y-m-d H:i:s',time()).". ";
        $data['member_id'] = $member->member_id;
        $data['time'] = time();

        if ($data){
            $this->model->insert($data);
            return [
                'content' => $data['content'],
                'data'    => ['msg_type' => $data['type']],
            ];
        }
    }
}