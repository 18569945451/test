<?php

namespace App\Api\V2\Repositories;

use App\Models\MemberNotifications;
use Prettus\Repository\Eloquent\BaseRepository;

class MemberNotificationsRepository extends BaseRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return MemberNotifications::class;
    }

    public function search($curPage, $pageSize, $memberId)
    {
        //开始位置
        $offset = ($curPage - 1) * $pageSize;

        //固定条件
        $this->model = $this->model->where('member_id',$memberId);

        //总数
        $count = $this->model->count();

        //总页数
        $countPage = ceil($count / $pageSize);

        //列表数据
        $list = $this->model->offset($offset)->limit($pageSize)->orderBy('id', 'desc')->get();

        //未读数
        $unreadCount = ($this->model())::where('is_read',0)->where('member_id',$memberId)->count();
        
        //格式化数据
        if ($list){
            foreach ($list as $key => $value) {
                if ($list[$key]['data']){
                    $list[$key]['data'] = json_decode($list[$key]['data'],true);
                }else{
                    unset($list[$key]['data']);
                }
            }
        }
        
        return [
            'error' => 0,
            'data'  => compact('countPage', 'count', 'unreadCount','curPage', 'pageSize', 'list'),
        ];
    }

    /**
     * 删除通知
     * @param $msgId
     * @param $memberId
     *
     * @return array
     */
    public function remove($msgId, $memberId)
    {
        if ($msgId == 0){
            $this->model->where('member_id',$memberId)->delete();
            return ['error'=>0,'data'=>[]];
        }else{
            $this->model->where('member_id',$memberId)->where('id',$msgId)->delete();
            return ['error'=>0,'data'=>[]];
        }
    }

    /**
     * 已读通知
     * @param $msgId
     * @param $memberId
     *
     * @return array
     */
    public function read($msgId, $memberId)
    {
        if ($msgId == 0){
            $this->model->where('member_id',$memberId)->update(['is_read'=>1]);
            return ['error'=>0,'data'=>[]];
        }else{
            $this->model->where('member_id',$memberId)->where('id',$msgId)->update(['is_read'=>1]);
            return ['error'=>0,'data'=>[]];
        }
    }

    /**
     * 邀请的朋友成功加入通知保存
     * @param int    $inviterMemberId
     * @param object $inviteeMember   受邀人对象
     *
     * @return array
     */
    public function saveNotifyForInviteFriend($inviterMemberId,$inviteeMember)
    {
        $data['type'] = 'invite_friend';
        $data['member_id'] = $inviterMemberId;
        $data['title'] = 'Friends Join YY';
        $data['content'] = "Hello, {$inviteeMember->member_name} has joined YY through your invitation. Once he completed his first job, you will be earned 1000 points. ";
        $data['time'] = time();
        $data['is_read'] = '0';

        if ($data){
            $this->model->insert($data);
            return [
                'content' => $data['content'],
                'data'    => ['msg_type' => $data['type']],
            ];
        }
    }

    /**
     * 用户信用值低于70分申请工作通知保存
     * @param $memberId
     * @param $jobId
     *
     * @return array
     */
    public function saveNotifyApplyJobForCreditsLow($memberId,$jobId)
    {
        $data['type'] = 'credit_too_low';
        $data['member_id'] = $memberId;
        $data['title'] = 'Thank you for your application';
        $data['content'] = "Thank you for your application. As your credits is under 70, your recruiter will check if you are qualified for the job.";
        $data['time'] = time();
        $data['is_read'] = '0';
        $data['data'] = json_encode(['job_id'=>$jobId]);

        if ($data){
            $this->model->insert($data);
            return [
                'content' => $data['content'],
                'data'    => ['msg_type' => $data['type']],
            ];
        }
    }

}