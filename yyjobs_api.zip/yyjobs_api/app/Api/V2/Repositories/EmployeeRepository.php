<?php

namespace App\Api\V2\Repositories;

use App\Api\V1\Services\TimApi;
use App\Traits\Admin\Jpush;
use Hash;
use Validator;
use App\Models\Member;
use Prettus\Repository\Eloquent\BaseRepository;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
class EmployeeRepository extends BaseRepository
{

    use Jpush;
    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return Member::class;
    }

    public function validateMember($request)
    {
        $data['member_name'] = $request['name'];
        $data['member_email'] = $request['email'];
        $data['member_nric'] = $request['nric_no'];
        $data['member_mobile'] = $request['mobile_no'];
        return Validator::make(
            $data,
            ['member_name'      => 'unique:member',
             'member_email'     => 'unique:member',
             'member_nric'   => 'unique:member',
             'member_mobile' => 'unique:member',
            ]
        );
    }

    /**
     * 手机号注册
     * @param $request
     *
     * @return array
     */
    public function registerForMobile($request)
    {
        //$this->test('test',['key'=>'value']);return;
        $validator = $this->validate($request);
        if ($validator->fails()) {
            return ['error' => 1, 'msg' => 'Invalid Data'];
        }
        if ($this->isExist($request)) {
            return ['error' => 1, 'msg' => 'It\'s Exist' ,'code'=>402];
        }

        $data = [
            'member_name'      => $request['name'],
            'member_password'  => bcrypt($request['password']),
            'member_email'     => $request['email'] ?? '',
            'member_nric'      => $request['nric_no'],
            'member_mobile'    => $request['mobile_no'],
            'member_school_id' => $request['school'],
            'member_add_time'  => time(),
        ];

        if ($res = $this->create($data)) {
            $token = auth('member')->attempt(['member_id' => $res->member_id]);

            //处理邀请关系
            if (isset($request['invite_code']) && $request['invite_code']){
                $inviteRep = app(MemberInviteRepository::class);
                $inviteRep->invite($request['invite_code'],$res);
            }

            //更新设备id
            $this->updateMemberRegistration($request['registration_id'],$res->member_id);

            //notify 发送注册成功通知
            $this->register($res,$request['registration_id']);
            $identifier = 'm'.$res->member_id;
            return [
                'error' => 0,
                'data'  => [
                    'member_id' => $res->member_id,
                    'token' => $token,
                    'signature'  => $this->getSignature($identifier),
                    'identifier' => $identifier,
                ],
                'msg'   => 'Registration Success!',
            ];
        }

        return ['error' => 1, 'msg' => 'Invalid Data'];

    }

    /**
     * 脸书注册
     * @param $request
     *
     * @return array
     */
    public function registerForFacebook($request)
    {
        $validator = $this->validate($request);
        if ($validator->fails()) {
            return ['error' => 1, 'msg' => 'Invalid Data'];
        }
        if ($this->isExist($request)) {
            return ['error' => 1, 'msg' => 'It\'s Exist' ,'code'=>402];
        }

        $fbUser = $this->getFacebookUser($request['social_access_token']);

        if (!empty($request['social_fb_id']) && $fbUser['status_code'] == 200) {
            $userData = [
                'member_name'      => $request['name'],
                'member_email'     => $request['email'] ?? '',
                'member_nric'      => $request['nric_no'],
                'member_mobile'    => $request['mobile_no'],
                'member_school_id' => $request['school'],
                'social_access_token' => bcrypt($request['social_access_token']),
                'social_fb_id'     => $request['social_fb_id'],
                'member_platform'  => $request['platform'],
                'member_add_time'  => time(),
            ];
            if ($res = $this->create($userData)) {
                $token = auth('member')->attempt(['member_id' => $res->member_id]);

                //处理邀请关系
                if (isset($request['invite_code']) && $request['invite_code']){
                    $inviteRep = app(MemberInviteRepository::class);
                    $inviteRep->invite($request['invite_code'],$res);
                }

                //更新设备id
                $this->updateMemberRegistration($request['registration_id'],$res->member_id);

                //notify 发送注册成功通知
                $this->register($res,$request['registration_id']);

                $identifier = 'm'.$res->member_id;
                return [
                    'error' => 0,
                    'data'  => [
                        'member_id' => $res->member_id,
                        'token' => $token,
                        'signature'  => $this->getSignature($identifier),
                        'identifier' => $identifier,
                    ],
                    'msg'   => 'Registration Success!',
                ];
            }

            return ['error' => 1, 'msg' => 'Invalid Data'];
        }

        return ['error' => 1, 'msg' => 'Invalid Social Account'];
    }

    /**
     * 谷歌注册
     * @param $request
     *
     * @return array
     */
    public function registerForGoogle($request)
    {
        $validator = $this->validate($request);
        if ($validator->fails()) {
            return ['error' => 1, 'msg' => 'Invalid Data'];
        }
        if ($this->isExist($request)) {
            return ['error' => 1, 'msg' => 'It\'s Exist' ,'code'=>402];
        }

        $fbUser = $this->getGoogleUser($request['social_access_token']);

        if (!empty($request['social_google_id']) && $fbUser['status_code'] == 200) {
            $userData = [
                'member_name'         => $request['name'],
                'member_email'        => $request['email'] ?? '',
                'member_nric'         => $request['nric_no'],
                'member_mobile'       => $request['mobile_no'],
                'member_school_id'    => $request['school'],
                'social_access_token' => bcrypt($request['social_access_token']),
                'social_google_id'    => $request['social_google_id'],
                'member_platform'     => $request['platform'],
                'member_add_time'     => time(),
            ];
            if ($res = $this->create($userData)) {
                $token = auth('member')->attempt(['member_id' => $res->member_id]);

                //处理邀请关系
                if (isset($request['invite_code']) && $request['invite_code']){
                    $inviteRep = app(MemberInviteRepository::class);
                    $inviteRep->invite($request['invite_code'],$res);
                }

                //更新设备id
                $this->updateMemberRegistration($request['registration_id'],$res->member_id);

                //notify 发送注册成功通知
                $this->register($res,$request['registration_id']);

                $identifier = 'm'.$res->member_id;
                return [
                    'error' => 0,
                    'data'  => [
                        'member_id' => $res->member_id,
                        'token' => $token,
                        'signature'  => $this->getSignature($identifier),
                        'identifier' => $identifier,
                    ],
                    'msg'   => 'Registration Success!',
                ];
            }

            return ['error' => 1, 'msg' => 'Invalid Data'];
        }

        return ['error' => 1, 'msg' => 'Invalid Social Account'];
    }

    /**
     * 是否存在
     * @param $data
     *
     * @return mixed
     */
    public function isExist($data)
    {
        return $this->model->where('member_nric', $data['nric_no'])
            ->orWhere('member_mobile', $data['mobile_no'])->first();
    }

    /**
     * 验证请求数据
     * @param $request
     *
     * @return mixed
     */
    private function validate($request)
    {
        if (isset($request['password'])) {
            return Validator::make(
                $request,
                [
                    'name'      => 'required',
                    'password'  => 'required',
                    //'email'     => 'required',
                    'nric_no'   => 'required',
                    'mobile_no' => 'required',
                ]
            );
        }

        return Validator::make(
            $request,
            ['name' => 'required',/* 'email' => 'required',*/ 'nric_no' => 'required', 'mobile_no' => 'required']
        );
    }


    /**
     * 获取脸书用户
     * @param $token
     *
     * @return array
     */
    private function getFacebookUser($token)
    {
        $client = new Client(['defaults' => ['verify' => false]]);
        try {
            $response = $client->request(
                'GET',
                config('custom.facebook_endpoint').'/v2.10/me?field=id,name,email&&access_token='.$token
            );

            return [
                'status_code' => $response->getStatusCode(),
                'body'        => $response->getBody(),
            ];


        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                $body = $e->getResponse()->getBody();
                $status = $e->getResponse()->getStatusCode();

                return [
                    'status_code' => $status,
                    'body'        => $body,
                ];

            }
        }
    }

    /**
     * 获取谷歌用户
     * @param $token
     *
     * @return array
     */
    private function getGoogleUser($token)
    {
        $client = new Client(['defaults' => ['verify' => false]]);
        try {
            $response = $client->request(
                'GET',
                config('custom.google_endpoint').'/oauth2/v3/tokeninfo?id_token='.$token
            );

            return [
                'status_code' => $response->getStatusCode(),
                'body'        => $response->getBody(),
            ];

        } catch (RequestException $e) {

            if ($e->hasResponse()) {
                $body = $e->getResponse()->getBody();
                $status = $e->getResponse()->getStatusCode();

                return [
                    'status_code' => $status,
                    'body'        => $body,
                ];

            }
        }
    }

    private function updateMemberRegistration($registrationId,$memberId)
    {
        $registrationForMember = $this->findWhere(['registration_id'=>$registrationId])->first();
        if (isset($registrationForMember->member_id) && $registrationForMember->member_id != $memberId){
            $this->update(['registration_id'=>''],$registrationForMember->member_id);
        }

        $this->update(['registration_id'=>$registrationId],$memberId);
    }

    /**
     * 忘记支付密码
     * @param $request
     * @param $member
     *
     * @return array
     */
    public function forgetPaymentPassword($request,$member)
    {
        $valid = Validator::make(
            $request,
            [
                'member_mobile'      => 'required',
                'member_nric'  => 'required',
                'password' => 'required|min:6|max:6|confirmed',
            ]
        );
        
        if ($valid->fails()){
            return ['error'=>1,'msg'=>$valid->errors()->all()[0]];
        }

        if ($request['member_mobile']!= $member->member_mobile ){
            return ['error'=>1,'msg'=>'Verify that the phone number is incorrect.'];
        }

        if ($request['member_nric']!= $member->member_nric ){
            return ['error'=>1,'msg'=>'Verify that the NRIC is incorrect.'];
        }

        $this->update(['member_payment_password'=>bcrypt($request['password'])],$member->member_id);

        return ['error'=>0,'data'=>[]];

    }

    /**
     * 验证支付密码
     * @param $request
     * @param $member
     *
     * @return array
     */
    public function validPaymentPassword($request,$member)
    {
        $valid = Validator::make(
            $request,
            [
                'password' => 'required|min:6|max:6',
            ]
        );

        if ($valid->fails()){
            return ['error'=>1,'msg'=>$valid->errors()->all()[0]];
        }

        if (!Hash::check($request['password'], $member->member_payment_password)){
            return ['error'=>1,'msg'=>'Incorrect payment password.'];
        }

        return ['error'=>0,'data'=>[]];

    }

    /**
     * @param $identifier
     *
     * @return bool|mixed
     */
    private function getSignature($identifier){

        $tim = new TimApi();
        return $tim->setIdentifier($identifier)->signature();
    }
}