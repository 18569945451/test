<?php

namespace App\Api\V2\Repositories;

use DB;
use App\Models\MerchantPointLog;
use Prettus\Repository\Eloquent\BaseRepository;

class MerchantPointRepository extends BaseRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return MerchantPointLog::class;
    }

    public function search($by,$startTimestamps,$endTimestamps,$keyword,$merchantId)
    {
        //没有传时间默认去最近有记录的一条数据的月份
        if (!$startTimestamps && !$endTimestamps){
            $firstData = $this->model->where('merchant_id',$merchantId)->orderBy('log_time','desc')->first();
            if (!$firstData){
                return ['error' => 0, 'data'  => []];
            }
            $startTimestamps = strtotime(date('Y-m',$firstData->log_time));
            $endTimestamps = date(strtotime("+1 months", $startTimestamps));
        }elseif ($startTimestamps && !$endTimestamps){
            $endTimestamps = date(strtotime("+1 months", $startTimestamps));
        }
        
        //固定条件
        $this->model = $this->model->leftJoin('member as m', 'merchant_point_log.member_id', 'm.member_id')
            ->leftJoin('merchant_withdraw as mw', 'merchant_point_log.withdraw_id', 'mw.w_id')
            ->where('merchant_point_log.merchant_id', $merchantId)
            ->where('merchant_point_log.log_time','>',$startTimestamps)
            ->where('merchant_point_log.log_time','<',$endTimestamps);

        //关键字
        if ($keyword) {
            $this->model = $this->model->where('m.member_name', 'like', "%{$keyword}%");
        }

        //数据
        $list = $this->model->orderBy('merchant_point_log.log_time', 'desc')->get(
            [
                'merchant_point_log.id as log_id',
                'merchant_point_log.change_value',
                'merchant_point_log.log_time',
                'merchant_point_log.withdraw_id',
                'merchant_point_log.member_id',
                'm.member_name',
                'm.member_avatar',
                'mw.start_time as withdraw_cycle_start_time',
                'mw.end_time as withdraw_cycle_end_time',
                'mw.add_time as withdraw_time',
                'mw.status as withdraw_status',
            ]
        )->toArray();

        $data = [];
        foreach ($list as $key => $value) {
            foreach ($value as $vk=>$vv) {
                if ($value[$vk] === null){
                    $value[$vk] = '';
                }
            }
            $newKey = date('Y-m', $value['log_time']);
            $data[$newKey]['date']    = $newKey;
            $data[$newKey]['expense'] = 0;
            $data[$newKey]['income']  = 0;
            $data[$newKey]['list'][]  = $value;
        }

        foreach ($data as $dk => $v) {
            foreach ($v['list'] as $lk=>$lv) {
                if($lv['change_value'] <= 0){
                    $data[$dk]['expense'] += abs($lv['change_value']);
                }else{
                    $data[$dk]['income'] += abs($lv['change_value']);
                }
            }
            $data[$dk]['income'] = floatval(sprintf("%.2f",$data[$dk]['income']));
        }

        rsort($data);

        return [
            'error' => 0,
            'data'  => $data,
        ];
    }

    public function recent($merchantId)
    {
        $list = $this->model->leftJoin('member as m', 'merchant_point_log.member_id', 'm.member_id')
            ->leftJoin('merchant_withdraw as mw', 'merchant_point_log.withdraw_id', 'mw.w_id')
            ->where('merchant_point_log.merchant_id', $merchantId)->orderBy('merchant_point_log.log_time', 'desc')->get(
                [
                    'merchant_point_log.id as log_id',
                    'merchant_point_log.change_value',
                    'merchant_point_log.log_time',
                    'merchant_point_log.withdraw_id',
                    'merchant_point_log.member_id',
                    'm.member_name',
                    'm.member_avatar',
                    'mw.start_time as withdraw_cycle_start_time',
                    'mw.end_time as withdraw_cycle_end_time',
                    'mw.add_time as withdraw_time',
                    'mw.status as withdraw_status',
                ]
            )->toArray();

        if ($list){
            foreach ($list as $key => $value) {
                $list[$key]['member_name'] = $value['member_name'] ?? '';
                $list[$key]['member_avatar'] = $value['member_avatar'] ?? '';
                $list[$key]['withdraw_cycle_start_time'] = $value['withdraw_cycle_start_time'] ?? '';
                $list[$key]['withdraw_cycle_end_time'] = $value['withdraw_cycle_end_time'] ?? '';
                $list[$key]['withdraw_time'] = $value['withdraw_time'] ?? '';
                $list[$key]['withdraw_status'] = $value['withdraw_status'] ?? '';
            }
        }

        return ['error'=>0,'data'=>$list];
    }

    
    private function formatDateTime($by, $start,$end)
    {
        $dateTimestamps['start'] = strtotime($start);
        $dateTimestamps['end'] = strtotime($end);

        return $dateTimestamps;
    }

    /**
     * 接收用户消费 \App\Api\V2\Repositories\MemberPointRepository::consume
     * @param $memberId
     * @param $merchantId
     * @param $money
     * @return bool
     */
    public function receive($memberId, $merchantId, $money)
    {
        $merchantRep = app(MerchantRepository::class);
        $merchant    = $merchantRep->find($merchantId, ['merchant_point']);
        
        $merchantPointData['merchant_id']       = $merchantId;
        $merchantPointData['change_type']       = 1;
        $merchantPointData['change_pre_point']  = $merchant->merchant_point;
        $merchantPointData['change_next_point'] = $merchant->merchant_point + ($money * 100);
        $merchantPointData['change_value']      = $money * 100;
        $merchantPointData['withdraw_id']       = 0;
        $merchantPointData['member_id']         = $memberId;
        $merchantPointData['log_desc']          = 'Employee consumption';
        $merchantPointData['log_time']          = time();

        if(!$this->create($merchantPointData)){
            return false;
        }

        $merchantPoint = $merchantRep->update(['merchant_point'=>$merchant->merchant_point + ($money * 100)],$merchantId);

        if ($merchantPoint === false){
            return false;
        }

        return true;

    }
}